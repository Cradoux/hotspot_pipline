
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.8150005341":[], "17.8150005341_arrows":[]}

cluster_dict["17.8150005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-12.0), float(41.0), float(158.5), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-12.0,41.0,158.5], [-11.48,37.458,156.62], color="blue red", name="Arrows_17.8150005341_1")

cluster_dict["17.8150005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-8.5), float(46.5), float(156.5), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-8.5,46.5,156.5], [-10.598,46.675,158.06], color="blue red", name="Arrows_17.8150005341_2")

cluster_dict["17.8150005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-8.5), float(41.5), float(154.0), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-8.5,41.5,154.0], [-8.173,39.85,150.66], color="blue red", name="Arrows_17.8150005341_3")

cluster_dict["17.8150005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-7.0), float(41.0), float(160.0), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-7.0,41.0,160.0], [-7.778,42.957,160.58], color="blue red", name="Arrows_17.8150005341_4")

cluster_dict["17.8150005341"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-9.00595043816), float(42.0601414295), float(155.911439435), float(1.0)]


cluster_dict["17.8150005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(41.5), float(154.5), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-13.5,41.5,154.5], [-14.571,39.376,151.707], color="red blue", name="Arrows_17.8150005341_5")

cluster_dict["17.8150005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(41.5), float(154.5), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-13.5,41.5,154.5], [-14.571,39.376,151.707], color="red blue", name="Arrows_17.8150005341_6")

cluster_dict["17.8150005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.0), float(43.0), float(151.5), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-9.0,43.0,151.5], [-8.173,39.85,150.66], color="red blue", name="Arrows_17.8150005341_7")

cluster_dict["17.8150005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-8.5), float(38.5), float(158.0), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-8.5,38.5,158.0], [-10.046,35.926,155.801], color="red blue", name="Arrows_17.8150005341_8")

cluster_dict["17.8150005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.0), float(43.0), float(151.5), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-9.0,43.0,151.5], [-8.173,39.85,150.66], color="red blue", name="Arrows_17.8150005341_9")

cluster_dict["17.8150005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.0), float(43.0), float(151.5), float(1.0)]

cluster_dict["17.8150005341_arrows"] += cgo_arrow([-9.0,43.0,151.5], [-8.173,39.85,150.66], color="red blue", name="Arrows_17.8150005341_10")

cmd.load_cgo(cluster_dict["17.8150005341"], "Features_17.8150005341", 1)
cmd.load_cgo(cluster_dict["17.8150005341_arrows"], "Arrows_17.8150005341")
cmd.set("transparency", 0.2,"Features_17.8150005341")
cmd.group("Pharmacophore_17.8150005341", members="Features_17.8150005341")
cmd.group("Pharmacophore_17.8150005341", members="Arrows_17.8150005341")

if dirpath:
    f = join(dirpath, "label_threshold_17.8150005341.mol2")
else:
    f = "label_threshold_17.8150005341.mol2"

cmd.load(f, 'label_threshold_17.8150005341')
cmd.hide('everything', 'label_threshold_17.8150005341')
cmd.label("label_threshold_17.8150005341", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.8150005341', members= 'label_threshold_17.8150005341')
