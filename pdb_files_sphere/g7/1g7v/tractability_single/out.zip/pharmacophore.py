
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.4379997253":[], "17.4379997253_arrows":[]}

cluster_dict["17.4379997253"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(3.5), float(110.5), float(76.0), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([3.5,110.5,76.0], [3.349,110.592,79.034], color="blue red", name="Arrows_17.4379997253_1")

cluster_dict["17.4379997253"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(7.5), float(112.0), float(76.0), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([7.5,112.0,76.0], [8.211,114.102,72.329], color="blue red", name="Arrows_17.4379997253_2")

cluster_dict["17.4379997253"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(10.0), float(105.5), float(76.5), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([10.0,105.5,76.5], [11.141,102.835,76.967], color="blue red", name="Arrows_17.4379997253_3")

cluster_dict["17.4379997253"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(7.32349908707), float(106.685576723), float(78.2961721328), float(1.0)]


cluster_dict["17.4379997253"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(10.0), float(113.0), float(78.0), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([10.0,113.0,78.0], [10.22,111.0,74.632], color="red blue", name="Arrows_17.4379997253_4")

cluster_dict["17.4379997253"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(6.5), float(106.5), float(73.0), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([6.5,106.5,73.0], [7.061,106.617,70.657], color="red blue", name="Arrows_17.4379997253_5")

cluster_dict["17.4379997253"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(7.5), float(111.5), float(81.0), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([7.5,111.5,81.0], [5.021,110.73,80.529], color="red blue", name="Arrows_17.4379997253_6")

cluster_dict["17.4379997253"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(7.0), float(109.0), float(73.0), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([7.0,109.0,73.0], [7.061,106.617,70.657], color="red blue", name="Arrows_17.4379997253_7")

cluster_dict["17.4379997253"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(9.5), float(108.5), float(78.0), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([9.5,108.5,78.0], [11.883,106.786,77.978], color="red blue", name="Arrows_17.4379997253_8")

cluster_dict["17.4379997253"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(10.0), float(113.0), float(78.0), float(1.0)]

cluster_dict["17.4379997253_arrows"] += cgo_arrow([10.0,113.0,78.0], [10.22,111.0,74.632], color="red blue", name="Arrows_17.4379997253_9")

cmd.load_cgo(cluster_dict["17.4379997253"], "Features_17.4379997253", 1)
cmd.load_cgo(cluster_dict["17.4379997253_arrows"], "Arrows_17.4379997253")
cmd.set("transparency", 0.2,"Features_17.4379997253")
cmd.group("Pharmacophore_17.4379997253", members="Features_17.4379997253")
cmd.group("Pharmacophore_17.4379997253", members="Arrows_17.4379997253")

if dirpath:
    f = join(dirpath, "label_threshold_17.4379997253.mol2")
else:
    f = "label_threshold_17.4379997253.mol2"

cmd.load(f, 'label_threshold_17.4379997253')
cmd.hide('everything', 'label_threshold_17.4379997253')
cmd.label("label_threshold_17.4379997253", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.4379997253', members= 'label_threshold_17.4379997253')
