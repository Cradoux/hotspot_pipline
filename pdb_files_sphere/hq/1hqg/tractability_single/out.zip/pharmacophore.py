
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.0544996262":[], "15.0544996262_arrows":[]}

cluster_dict["15.0544996262"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-3.5), float(2.0), float(-2.5), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([-3.5,2.0,-2.5], [-4.108,0.895,-4.77], color="blue red", name="Arrows_15.0544996262_1")

cluster_dict["15.0544996262"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-0.5), float(6.0), float(-0.5), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([-0.5,6.0,-0.5], [-2.213,5.516,2.563], color="blue red", name="Arrows_15.0544996262_2")

cluster_dict["15.0544996262"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-1.0), float(3.0), float(-3.5), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([-1.0,3.0,-3.5], [-4.108,0.895,-4.77], color="blue red", name="Arrows_15.0544996262_3")

cluster_dict["15.0544996262"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-1.0), float(3.0), float(-3.5), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([-1.0,3.0,-3.5], [-4.108,0.895,-4.77], color="blue red", name="Arrows_15.0544996262_4")

cluster_dict["15.0544996262"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(4.0), float(4.0), float(-4.5), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([4.0,4.0,-4.5], [2.407,6.6,-6.714], color="blue red", name="Arrows_15.0544996262_5")

cluster_dict["15.0544996262"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(4.0), float(4.0), float(-4.5), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([4.0,4.0,-4.5], [2.407,6.6,-6.714], color="blue red", name="Arrows_15.0544996262_6")

cluster_dict["15.0544996262"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(0.849179412125), float(3.58946195755), float(-5.46682891859), float(1.0)]


cluster_dict["15.0544996262"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-1.5), float(3.5), float(-5.5), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([-1.5,3.5,-5.5], [-2.489,0.624,-7.47], color="red blue", name="Arrows_15.0544996262_7")

cluster_dict["15.0544996262"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-1.0), float(3.0), float(-2.0), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([-1.0,3.0,-2.0], [1.438,-0.211,-2.105], color="red blue", name="Arrows_15.0544996262_8")

cluster_dict["15.0544996262"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-1.5), float(3.5), float(-5.5), float(1.0)]

cluster_dict["15.0544996262_arrows"] += cgo_arrow([-1.5,3.5,-5.5], [-2.489,0.624,-7.47], color="red blue", name="Arrows_15.0544996262_9")

cmd.load_cgo(cluster_dict["15.0544996262"], "Features_15.0544996262", 1)
cmd.load_cgo(cluster_dict["15.0544996262_arrows"], "Arrows_15.0544996262")
cmd.set("transparency", 0.2,"Features_15.0544996262")
cmd.group("Pharmacophore_15.0544996262", members="Features_15.0544996262")
cmd.group("Pharmacophore_15.0544996262", members="Arrows_15.0544996262")

if dirpath:
    f = join(dirpath, "label_threshold_15.0544996262.mol2")
else:
    f = "label_threshold_15.0544996262.mol2"

cmd.load(f, 'label_threshold_15.0544996262')
cmd.hide('everything', 'label_threshold_15.0544996262')
cmd.label("label_threshold_15.0544996262", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.0544996262', members= 'label_threshold_15.0544996262')
