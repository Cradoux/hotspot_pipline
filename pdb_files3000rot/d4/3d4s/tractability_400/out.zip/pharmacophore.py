
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"19.1900005341":[], "19.1900005341_arrows":[]}

cluster_dict["19.1900005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(-0.5), float(51.0), float(1.0)]

cluster_dict["19.1900005341_arrows"] += cgo_arrow([2.5,-0.5,51.0], [3.679,-3.063,51.053], color="blue red", name="Arrows_19.1900005341_1")

cluster_dict["19.1900005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(3.0), float(0.0), float(56.0), float(1.0)]

cluster_dict["19.1900005341_arrows"] += cgo_arrow([3.0,0.0,56.0], [1.634,-0.789,58.458], color="blue red", name="Arrows_19.1900005341_2")

cluster_dict["19.1900005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(3.5), float(8.0), float(51.5), float(1.0)]

cluster_dict["19.1900005341_arrows"] += cgo_arrow([3.5,8.0,51.5], [5.801,8.342,51.904], color="blue red", name="Arrows_19.1900005341_3")

cluster_dict["19.1900005341"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(2.4507151989), float(4.44619269946), float(52.1715618896), float(1.0)]


cluster_dict["19.1900005341"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(0.3), float(1.7), float(47.0), float(1.0)]


cluster_dict["19.1900005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-0.5), float(2.0), float(52.0), float(1.0)]

cluster_dict["19.1900005341_arrows"] += cgo_arrow([-0.5,2.0,52.0], [-3.129,0.857,52.996], color="red blue", name="Arrows_19.1900005341_4")

cluster_dict["19.1900005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-0.5), float(2.0), float(52.0), float(1.0)]

cluster_dict["19.1900005341_arrows"] += cgo_arrow([-0.5,2.0,52.0], [-3.129,0.857,52.996], color="red blue", name="Arrows_19.1900005341_5")

cluster_dict["19.1900005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(0.0), float(9.0), float(54.5), float(1.0)]

cluster_dict["19.1900005341_arrows"] += cgo_arrow([0.0,9.0,54.5], [-2.404,8.941,55.424], color="red blue", name="Arrows_19.1900005341_6")

cluster_dict["19.1900005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(3.0), float(3.5), float(52.5), float(1.0)]

cluster_dict["19.1900005341_arrows"] += cgo_arrow([3.0,3.5,52.5], [5.463,3.291,54.968], color="red blue", name="Arrows_19.1900005341_7")

cluster_dict["19.1900005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(3.0), float(7.5), float(49.5), float(1.0)]

cluster_dict["19.1900005341_arrows"] += cgo_arrow([3.0,7.5,49.5], [1.32,8.775,48.413], color="red blue", name="Arrows_19.1900005341_8")

cluster_dict["19.1900005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(3.5), float(4.0), float(48.0), float(1.0)]


cmd.load_cgo(cluster_dict["19.1900005341"], "Features_19.1900005341", 1)
cmd.load_cgo(cluster_dict["19.1900005341_arrows"], "Arrows_19.1900005341")
cmd.set("transparency", 0.2,"Features_19.1900005341")
cmd.group("Pharmacophore_19.1900005341", members="Features_19.1900005341")
cmd.group("Pharmacophore_19.1900005341", members="Arrows_19.1900005341")

if dirpath:
    f = join(dirpath, "label_threshold_19.1900005341.mol2")
else:
    f = "label_threshold_19.1900005341.mol2"

cmd.load(f, 'label_threshold_19.1900005341')
cmd.hide('everything', 'label_threshold_19.1900005341')
cmd.label("label_threshold_19.1900005341", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_19.1900005341', members= 'label_threshold_19.1900005341')
