
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.843000412":[], "17.843000412_arrows":[]}

cluster_dict["17.843000412"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-3.5), float(58.0), float(81.0), float(1.0)]

cluster_dict["17.843000412_arrows"] += cgo_arrow([-3.5,58.0,81.0], [-3.493,55.183,80.502], color="blue red", name="Arrows_17.843000412_1")

cluster_dict["17.843000412"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-0.5), float(69.5), float(79.5), float(1.0)]

cluster_dict["17.843000412_arrows"] += cgo_arrow([-0.5,69.5,79.5], [0.416,68.189,76.694], color="blue red", name="Arrows_17.843000412_2")

cluster_dict["17.843000412"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(0.0), float(65.0), float(86.0), float(1.0)]

cluster_dict["17.843000412_arrows"] += cgo_arrow([0.0,65.0,86.0], [2.164,67.176,87.736], color="blue red", name="Arrows_17.843000412_3")

cluster_dict["17.843000412"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(0.43327800959), float(65.3782531099), float(82.0799613871), float(1.0)]


cluster_dict["17.843000412"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-4.5), float(61.5), float(76.5), float(1.0)]

cluster_dict["17.843000412_arrows"] += cgo_arrow([-4.5,61.5,76.5], [-6.412,63.546,76.067], color="red blue", name="Arrows_17.843000412_4")

cluster_dict["17.843000412"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-1.0), float(63.0), float(89.5), float(1.0)]

cluster_dict["17.843000412_arrows"] += cgo_arrow([-1.0,63.0,89.5], [-0.829,63.238,92.424], color="red blue", name="Arrows_17.843000412_5")

cluster_dict["17.843000412"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-2.5), float(60.5), float(83.0), float(1.0)]

cluster_dict["17.843000412_arrows"] += cgo_arrow([-2.5,60.5,83.0], [-1.978,58.881,85.643], color="red blue", name="Arrows_17.843000412_6")

cluster_dict["17.843000412"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-1.0), float(70.5), float(81.5), float(1.0)]

cluster_dict["17.843000412_arrows"] += cgo_arrow([-1.0,70.5,81.5], [-0.351,72.07,85.578], color="red blue", name="Arrows_17.843000412_7")

cluster_dict["17.843000412"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(1.0), float(63.5), float(80.0), float(1.0)]


cluster_dict["17.843000412"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(72.0), float(80.0), float(1.0)]

cluster_dict["17.843000412_arrows"] += cgo_arrow([2.5,72.0,80.0], [2.986,72.519,77.302], color="red blue", name="Arrows_17.843000412_8")

cmd.load_cgo(cluster_dict["17.843000412"], "Features_17.843000412", 1)
cmd.load_cgo(cluster_dict["17.843000412_arrows"], "Arrows_17.843000412")
cmd.set("transparency", 0.2,"Features_17.843000412")
cmd.group("Pharmacophore_17.843000412", members="Features_17.843000412")
cmd.group("Pharmacophore_17.843000412", members="Arrows_17.843000412")

if dirpath:
    f = join(dirpath, "label_threshold_17.843000412.mol2")
else:
    f = "label_threshold_17.843000412.mol2"

cmd.load(f, 'label_threshold_17.843000412')
cmd.hide('everything', 'label_threshold_17.843000412')
cmd.label("label_threshold_17.843000412", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.843000412', members= 'label_threshold_17.843000412')
