
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.1770000458":[], "16.1770000458_arrows":[]}

cluster_dict["16.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(47.5), float(40.0), float(-10.5), float(1.0)]

cluster_dict["16.1770000458_arrows"] += cgo_arrow([47.5,40.0,-10.5], [49.122,39.952,-12.916], color="blue red", name="Arrows_16.1770000458_1")

cluster_dict["16.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(39.5), float(-4.0), float(1.0)]

cluster_dict["16.1770000458_arrows"] += cgo_arrow([48.0,39.5,-4.0], [49.526,37.349,-2.499], color="blue red", name="Arrows_16.1770000458_2")

cluster_dict["16.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(49.0), float(48.5), float(-4.5), float(1.0)]

cluster_dict["16.1770000458_arrows"] += cgo_arrow([49.0,48.5,-4.5], [50.269,47.32,-1.869], color="blue red", name="Arrows_16.1770000458_3")

cluster_dict["16.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(50.0), float(45.5), float(-9.0), float(1.0)]

cluster_dict["16.1770000458_arrows"] += cgo_arrow([50.0,45.5,-9.0], [51.031,46.692,-11.391], color="blue red", name="Arrows_16.1770000458_4")

cluster_dict["16.1770000458"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(46.7101002179), float(42.5077621164), float(-6.6259360961), float(1.0)]


cluster_dict["16.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(46.0), float(36.0), float(-8.0), float(1.0)]

cluster_dict["16.1770000458_arrows"] += cgo_arrow([46.0,36.0,-8.0], [46.987,34.745,-6.017], color="red blue", name="Arrows_16.1770000458_5")

cluster_dict["16.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(47.5), float(47.0), float(-4.0), float(1.0)]

cluster_dict["16.1770000458_arrows"] += cgo_arrow([47.5,47.0,-4.0], [50.217,45.377,-0.741], color="red blue", name="Arrows_16.1770000458_6")

cluster_dict["16.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(42.5), float(-11.5), float(1.0)]

cluster_dict["16.1770000458_arrows"] += cgo_arrow([48.0,42.5,-11.5], [50.337,42.875,-12.964], color="red blue", name="Arrows_16.1770000458_7")

cluster_dict["16.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.5), float(49.0), float(-7.0), float(1.0)]

cluster_dict["16.1770000458_arrows"] += cgo_arrow([48.5,49.0,-7.0], [50.304,48.873,-9.129], color="red blue", name="Arrows_16.1770000458_8")

cmd.load_cgo(cluster_dict["16.1770000458"], "Features_16.1770000458", 1)
cmd.load_cgo(cluster_dict["16.1770000458_arrows"], "Arrows_16.1770000458")
cmd.set("transparency", 0.2,"Features_16.1770000458")
cmd.group("Pharmacophore_16.1770000458", members="Features_16.1770000458")
cmd.group("Pharmacophore_16.1770000458", members="Arrows_16.1770000458")

if dirpath:
    f = join(dirpath, "label_threshold_16.1770000458.mol2")
else:
    f = "label_threshold_16.1770000458.mol2"

cmd.load(f, 'label_threshold_16.1770000458')
cmd.hide('everything', 'label_threshold_16.1770000458')
cmd.label("label_threshold_16.1770000458", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.1770000458', members= 'label_threshold_16.1770000458')
