
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.3209991455":[], "16.3209991455_arrows":[]}

cluster_dict["16.3209991455"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(97.0), float(58.0), float(51.5), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([97.0,58.0,51.5], [96.892,59.428,54.314], color="blue red", name="Arrows_16.3209991455_1")

cluster_dict["16.3209991455"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(99.0), float(54.0), float(52.5), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([99.0,54.0,52.5], [98.986,52.588,55.005], color="blue red", name="Arrows_16.3209991455_2")

cluster_dict["16.3209991455"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(98.5), float(64.5), float(52.5), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([98.5,64.5,52.5], [100.719,65.589,53.902], color="blue red", name="Arrows_16.3209991455_3")

cluster_dict["16.3209991455"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(102.5), float(53.0), float(53.0), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([102.5,53.0,53.0], [100.549,51.341,51.975], color="blue red", name="Arrows_16.3209991455_4")

cluster_dict["16.3209991455"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(103.0), float(57.0), float(53.0), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([103.0,57.0,53.0], [104.159,54.788,54.922], color="blue red", name="Arrows_16.3209991455_5")

cluster_dict["16.3209991455"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(100.706263457), float(59.1463220913), float(49.9136287981), float(1.0)]


cluster_dict["16.3209991455"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(97.0), float(66.0), float(51.5), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([97.0,66.0,51.5], [95.231,68.351,52.627], color="red blue", name="Arrows_16.3209991455_6")

cluster_dict["16.3209991455"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(98.5), float(54.0), float(48.0), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([98.5,54.0,48.0], [97.986,50.759,47.681], color="red blue", name="Arrows_16.3209991455_7")

cluster_dict["16.3209991455"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(98.5), float(65.5), float(49.0), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([98.5,65.5,49.0], [98.672,66.443,45.392], color="red blue", name="Arrows_16.3209991455_8")

cluster_dict["16.3209991455"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(102.5), float(60.5), float(49.0), float(1.0)]

cluster_dict["16.3209991455_arrows"] += cgo_arrow([102.5,60.5,49.0], [100.246,57.359,46.359], color="red blue", name="Arrows_16.3209991455_9")

cmd.load_cgo(cluster_dict["16.3209991455"], "Features_16.3209991455", 1)
cmd.load_cgo(cluster_dict["16.3209991455_arrows"], "Arrows_16.3209991455")
cmd.set("transparency", 0.2,"Features_16.3209991455")
cmd.group("Pharmacophore_16.3209991455", members="Features_16.3209991455")
cmd.group("Pharmacophore_16.3209991455", members="Arrows_16.3209991455")

if dirpath:
    f = join(dirpath, "label_threshold_16.3209991455.mol2")
else:
    f = "label_threshold_16.3209991455.mol2"

cmd.load(f, 'label_threshold_16.3209991455')
cmd.hide('everything', 'label_threshold_16.3209991455')
cmd.label("label_threshold_16.3209991455", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.3209991455', members= 'label_threshold_16.3209991455')
