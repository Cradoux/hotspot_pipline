
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"12.6870002747":[], "12.6870002747_arrows":[]}

cluster_dict["12.6870002747"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(64.5), float(74.5), float(69.0), float(1.0)]

cluster_dict["12.6870002747_arrows"] += cgo_arrow([64.5,74.5,69.0], [64.104,76.866,68.238], color="blue red", name="Arrows_12.6870002747_1")

cluster_dict["12.6870002747"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(69.5), float(74.0), float(71.0), float(1.0)]

cluster_dict["12.6870002747_arrows"] += cgo_arrow([69.5,74.0,71.0], [70.684,70.92,69.926], color="blue red", name="Arrows_12.6870002747_2")

cluster_dict["12.6870002747"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(64.0), float(68.2179070932), float(70.1283716273), float(1.0)]


cluster_dict["12.6870002747"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(67.8382818177), float(72.8605894452), float(69.2749621117), float(1.0)]


cluster_dict["12.6870002747"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(72.7575906192), float(74.6182319448), float(72.111968943), float(1.0)]


cluster_dict["12.6870002747"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(68.0), float(70.0), float(69.0), float(1.0)]

cluster_dict["12.6870002747_arrows"] += cgo_arrow([68.0,70.0,69.0], [68.171,69.129,66.651], color="red blue", name="Arrows_12.6870002747_3")

cluster_dict["12.6870002747"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(66.0), float(74.5), float(68.5), float(1.0)]

cluster_dict["12.6870002747_arrows"] += cgo_arrow([66.0,74.5,68.5], [64.836,73.977,66.465], color="red blue", name="Arrows_12.6870002747_4")

cluster_dict["12.6870002747"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(67.0), float(77.5), float(72.0), float(1.0)]

cluster_dict["12.6870002747_arrows"] += cgo_arrow([67.0,77.5,72.0], [64.782,77.81,70.101], color="red blue", name="Arrows_12.6870002747_5")

cluster_dict["12.6870002747"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(69.5), float(74.0), float(65.5), float(1.0)]

cluster_dict["12.6870002747_arrows"] += cgo_arrow([69.5,74.0,65.5], [71.481,75.749,67.887], color="red blue", name="Arrows_12.6870002747_6")

cluster_dict["12.6870002747"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(70.5), float(73.5), float(71.5), float(1.0)]

cluster_dict["12.6870002747_arrows"] += cgo_arrow([70.5,73.5,71.5], [70.684,70.92,69.926], color="red blue", name="Arrows_12.6870002747_7")

cmd.load_cgo(cluster_dict["12.6870002747"], "Features_12.6870002747", 1)
cmd.load_cgo(cluster_dict["12.6870002747_arrows"], "Arrows_12.6870002747")
cmd.set("transparency", 0.2,"Features_12.6870002747")
cmd.group("Pharmacophore_12.6870002747", members="Features_12.6870002747")
cmd.group("Pharmacophore_12.6870002747", members="Arrows_12.6870002747")

if dirpath:
    f = join(dirpath, "label_threshold_12.6870002747.mol2")
else:
    f = "label_threshold_12.6870002747.mol2"

cmd.load(f, 'label_threshold_12.6870002747')
cmd.hide('everything', 'label_threshold_12.6870002747')
cmd.label("label_threshold_12.6870002747", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_12.6870002747', members= 'label_threshold_12.6870002747')
