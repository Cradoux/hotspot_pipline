
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.8619995117":[], "16.8619995117_arrows":[]}

cluster_dict["16.8619995117"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(6.0), float(103.5), float(82.5), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([6.0,103.5,82.5], [3.903,105.552,80.989], color="blue red", name="Arrows_16.8619995117_1")

cluster_dict["16.8619995117"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(9.5), float(108.0), float(80.5), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([9.5,108.0,80.5], [11.728,106.388,80.182], color="blue red", name="Arrows_16.8619995117_2")

cluster_dict["16.8619995117"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(9.5), float(105.0), float(79.0), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([9.5,105.0,79.0], [11.728,106.388,80.182], color="blue red", name="Arrows_16.8619995117_3")

cluster_dict["16.8619995117"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(9.5), float(105.5), float(77.0), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([9.5,105.5,77.0], [11.141,102.835,76.967], color="blue red", name="Arrows_16.8619995117_4")

cluster_dict["16.8619995117"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(11.0), float(110.5), float(81.0), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([11.0,110.5,81.0], [13.419,110.042,82.914], color="blue red", name="Arrows_16.8619995117_5")

cluster_dict["16.8619995117"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(7.40742551031), float(107.60787514), float(78.3804100525), float(1.0)]


cluster_dict["16.8619995117"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(5.5), float(113.5), float(80.0), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([5.5,113.5,80.0], [5.021,110.73,80.529], color="red blue", name="Arrows_16.8619995117_6")

cluster_dict["16.8619995117"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(8.5), float(115.0), float(78.0), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([8.5,115.0,78.0], [6.555,117.389,78.438], color="red blue", name="Arrows_16.8619995117_7")

cluster_dict["16.8619995117"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(10.5), float(109.0), float(79.5), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([10.5,109.0,79.5], [11.883,106.786,77.978], color="red blue", name="Arrows_16.8619995117_8")

cluster_dict["16.8619995117"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(11.5), float(113.0), float(78.0), float(1.0)]

cluster_dict["16.8619995117_arrows"] += cgo_arrow([11.5,113.0,78.0], [13.328,115.357,77.05], color="red blue", name="Arrows_16.8619995117_9")

cmd.load_cgo(cluster_dict["16.8619995117"], "Features_16.8619995117", 1)
cmd.load_cgo(cluster_dict["16.8619995117_arrows"], "Arrows_16.8619995117")
cmd.set("transparency", 0.2,"Features_16.8619995117")
cmd.group("Pharmacophore_16.8619995117", members="Features_16.8619995117")
cmd.group("Pharmacophore_16.8619995117", members="Arrows_16.8619995117")

if dirpath:
    f = join(dirpath, "label_threshold_16.8619995117.mol2")
else:
    f = "label_threshold_16.8619995117.mol2"

cmd.load(f, 'label_threshold_16.8619995117')
cmd.hide('everything', 'label_threshold_16.8619995117')
cmd.label("label_threshold_16.8619995117", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.8619995117', members= 'label_threshold_16.8619995117')
