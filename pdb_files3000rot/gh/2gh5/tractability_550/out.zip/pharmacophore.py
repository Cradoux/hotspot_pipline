
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.7849998474":[], "13.7849998474_arrows":[]}

cluster_dict["13.7849998474"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(95.5), float(16.5), float(100.0), float(1.0)]

cluster_dict["13.7849998474_arrows"] += cgo_arrow([95.5,16.5,100.0], [95.246,15.863,102.643], color="blue red", name="Arrows_13.7849998474_1")

cluster_dict["13.7849998474"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(97.5), float(17.0), float(88.0), float(1.0)]

cluster_dict["13.7849998474_arrows"] += cgo_arrow([97.5,17.0,88.0], [95.688,16.84,85.897], color="blue red", name="Arrows_13.7849998474_2")

cluster_dict["13.7849998474"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(99.5), float(14.0), float(101.0), float(1.0)]

cluster_dict["13.7849998474_arrows"] += cgo_arrow([99.5,14.0,101.0], [99.4,10.661,101.72], color="blue red", name="Arrows_13.7849998474_3")

cluster_dict["13.7849998474"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(97.772087602), float(19.9493024124), float(95.3467341073), float(1.0)]


cluster_dict["13.7849998474"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(101.008891421), float(12.4209284588), float(90.7068681001), float(1.0)]


cluster_dict["13.7849998474"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(96.0), float(18.0), float(99.0), float(1.0)]

cluster_dict["13.7849998474_arrows"] += cgo_arrow([96.0,18.0,99.0], [93.358,18.6,99.599], color="red blue", name="Arrows_13.7849998474_4")

cluster_dict["13.7849998474"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(99.5), float(24.0), float(92.0), float(1.0)]

cluster_dict["13.7849998474_arrows"] += cgo_arrow([99.5,24.0,92.0], [99.478,26.029,94.674], color="red blue", name="Arrows_13.7849998474_5")

cluster_dict["13.7849998474"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(101.0), float(21.5), float(100.0), float(1.0)]

cluster_dict["13.7849998474_arrows"] += cgo_arrow([101.0,21.5,100.0], [101.55,19.69,101.979], color="red blue", name="Arrows_13.7849998474_6")

cluster_dict["13.7849998474"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(101.5), float(10.0), float(89.5), float(1.0)]

cluster_dict["13.7849998474_arrows"] += cgo_arrow([101.5,10.0,89.5], [99.053,9.698,91.013], color="red blue", name="Arrows_13.7849998474_7")

cmd.load_cgo(cluster_dict["13.7849998474"], "Features_13.7849998474", 1)
cmd.load_cgo(cluster_dict["13.7849998474_arrows"], "Arrows_13.7849998474")
cmd.set("transparency", 0.2,"Features_13.7849998474")
cmd.group("Pharmacophore_13.7849998474", members="Features_13.7849998474")
cmd.group("Pharmacophore_13.7849998474", members="Arrows_13.7849998474")

if dirpath:
    f = join(dirpath, "label_threshold_13.7849998474.mol2")
else:
    f = "label_threshold_13.7849998474.mol2"

cmd.load(f, 'label_threshold_13.7849998474')
cmd.hide('everything', 'label_threshold_13.7849998474')
cmd.label("label_threshold_13.7849998474", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.7849998474', members= 'label_threshold_13.7849998474')
