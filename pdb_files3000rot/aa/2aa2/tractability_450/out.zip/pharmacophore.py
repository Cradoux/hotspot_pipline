
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.4200000763":[], "17.4200000763_arrows":[]}

cluster_dict["17.4200000763"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(18.0), float(75.0), float(24.5), float(1.0)]

cluster_dict["17.4200000763_arrows"] += cgo_arrow([18.0,75.0,24.5], [15.611,73.163,23.589], color="blue red", name="Arrows_17.4200000763_1")

cluster_dict["17.4200000763"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.0), float(68.0), float(17.0), float(1.0)]

cluster_dict["17.4200000763_arrows"] += cgo_arrow([19.0,68.0,17.0], [17.176,65.615,17.937], color="blue red", name="Arrows_17.4200000763_2")

cluster_dict["17.4200000763"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(19.179257793), float(72.410610248), float(19.9318837079), float(1.0)]


cluster_dict["17.4200000763"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(77.0), float(23.5), float(1.0)]

cluster_dict["17.4200000763_arrows"] += cgo_arrow([17.0,77.0,23.5], [18.025,77.713,26.505], color="red blue", name="Arrows_17.4200000763_3")

cluster_dict["17.4200000763"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(68.0), float(15.5), float(1.0)]

cluster_dict["17.4200000763_arrows"] += cgo_arrow([17.5,68.0,15.5], [16.119,65.678,15.964], color="red blue", name="Arrows_17.4200000763_4")

cluster_dict["17.4200000763"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(70.0), float(22.5), float(1.0)]

cluster_dict["17.4200000763_arrows"] += cgo_arrow([17.5,70.0,22.5], [14.032,67.68,20.514], color="red blue", name="Arrows_17.4200000763_5")

cluster_dict["17.4200000763"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.0), float(71.5), float(24.5), float(1.0)]

cluster_dict["17.4200000763_arrows"] += cgo_arrow([18.0,71.5,24.5], [20.683,72.995,26.534], color="red blue", name="Arrows_17.4200000763_6")

cluster_dict["17.4200000763"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.0), float(71.5), float(24.5), float(1.0)]

cluster_dict["17.4200000763_arrows"] += cgo_arrow([18.0,71.5,24.5], [20.683,72.995,26.534], color="red blue", name="Arrows_17.4200000763_7")

cluster_dict["17.4200000763"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(72.0), float(17.0), float(1.0)]


cluster_dict["17.4200000763"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.0), float(73.5), float(19.5), float(1.0)]


cmd.load_cgo(cluster_dict["17.4200000763"], "Features_17.4200000763", 1)
cmd.load_cgo(cluster_dict["17.4200000763_arrows"], "Arrows_17.4200000763")
cmd.set("transparency", 0.2,"Features_17.4200000763")
cmd.group("Pharmacophore_17.4200000763", members="Features_17.4200000763")
cmd.group("Pharmacophore_17.4200000763", members="Arrows_17.4200000763")

if dirpath:
    f = join(dirpath, "label_threshold_17.4200000763.mol2")
else:
    f = "label_threshold_17.4200000763.mol2"

cmd.load(f, 'label_threshold_17.4200000763')
cmd.hide('everything', 'label_threshold_17.4200000763')
cmd.label("label_threshold_17.4200000763", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.4200000763', members= 'label_threshold_17.4200000763')
