
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"18.5480003357":[], "18.5480003357_arrows":[]}

cluster_dict["18.5480003357"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-12.5), float(92.0), float(25.5), float(1.0)]

cluster_dict["18.5480003357_arrows"] += cgo_arrow([-12.5,92.0,25.5], [-11.32,91.433,27.948], color="blue red", name="Arrows_18.5480003357_1")

cluster_dict["18.5480003357"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-12.0), float(98.0), float(15.0), float(1.0)]

cluster_dict["18.5480003357_arrows"] += cgo_arrow([-12.0,98.0,15.0], [-11.776,98.791,11.921], color="blue red", name="Arrows_18.5480003357_2")

cluster_dict["18.5480003357"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-9.5), float(96.5), float(15.5), float(1.0)]

cluster_dict["18.5480003357_arrows"] += cgo_arrow([-9.5,96.5,15.5], [-8.732,93.236,15.72], color="blue red", name="Arrows_18.5480003357_3")

cluster_dict["18.5480003357"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-9.5), float(96.0), float(22.0), float(1.0)]

cluster_dict["18.5480003357_arrows"] += cgo_arrow([-9.5,96.0,22.0], [-8.429,98.737,22.114], color="blue red", name="Arrows_18.5480003357_4")

cluster_dict["18.5480003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-12.528050792), float(94.6473355959), float(21.4154235986), float(1.0)]


cluster_dict["18.5480003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(98.0), float(15.0), float(1.0)]

cluster_dict["18.5480003357_arrows"] += cgo_arrow([-13.5,98.0,15.0], [-11.776,98.791,11.921], color="red blue", name="Arrows_18.5480003357_5")

cluster_dict["18.5480003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-10.5), float(95.0), float(15.5), float(1.0)]

cluster_dict["18.5480003357_arrows"] += cgo_arrow([-10.5,95.0,15.5], [-8.732,93.236,15.72], color="red blue", name="Arrows_18.5480003357_6")

cluster_dict["18.5480003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.5), float(96.5), float(20.5), float(1.0)]

cluster_dict["18.5480003357_arrows"] += cgo_arrow([-9.5,96.5,20.5], [-6.897,95.324,20.938], color="red blue", name="Arrows_18.5480003357_7")

cluster_dict["18.5480003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-8.0), float(98.0), float(16.5), float(1.0)]

cluster_dict["18.5480003357_arrows"] += cgo_arrow([-8.0,98.0,16.5], [-5.737,97.286,18.551], color="red blue", name="Arrows_18.5480003357_8")

cmd.load_cgo(cluster_dict["18.5480003357"], "Features_18.5480003357", 1)
cmd.load_cgo(cluster_dict["18.5480003357_arrows"], "Arrows_18.5480003357")
cmd.set("transparency", 0.2,"Features_18.5480003357")
cmd.group("Pharmacophore_18.5480003357", members="Features_18.5480003357")
cmd.group("Pharmacophore_18.5480003357", members="Arrows_18.5480003357")

if dirpath:
    f = join(dirpath, "label_threshold_18.5480003357.mol2")
else:
    f = "label_threshold_18.5480003357.mol2"

cmd.load(f, 'label_threshold_18.5480003357')
cmd.hide('everything', 'label_threshold_18.5480003357')
cmd.label("label_threshold_18.5480003357", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_18.5480003357', members= 'label_threshold_18.5480003357')
