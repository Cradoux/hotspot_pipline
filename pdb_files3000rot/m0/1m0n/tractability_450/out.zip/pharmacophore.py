
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"12.6180000305":[], "12.6180000305_arrows":[]}

cluster_dict["12.6180000305"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(12.0), float(53.5), float(24.5), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([12.0,53.5,24.5], [9.808,52.921,25.117], color="blue red", name="Arrows_12.6180000305_1")

cluster_dict["12.6180000305"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(16.9235377231), float(49.1302594434), float(24.2662700406), float(1.0)]


cluster_dict["12.6180000305"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(47.5), float(26.5), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([13.0,47.5,26.5], [13.665,46.492,23.997], color="red blue", name="Arrows_12.6180000305_2")

cluster_dict["12.6180000305"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(52.5), float(26.0), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([13.0,52.5,26.0], [10.627,51.048,26.078], color="red blue", name="Arrows_12.6180000305_3")

cluster_dict["12.6180000305"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(53.5), float(21.5), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([15.5,53.5,21.5], [14.391,54.985,20.064], color="red blue", name="Arrows_12.6180000305_4")

cluster_dict["12.6180000305"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(14.0), float(53.5), float(22.0), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([14.0,53.5,22.0], [14.391,54.985,20.064], color="red blue", name="Arrows_12.6180000305_5")

cluster_dict["12.6180000305"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.0), float(43.5), float(18.0), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([15.0,43.5,18.0], [12.884,44.157,16.767], color="red blue", name="Arrows_12.6180000305_6")

cluster_dict["12.6180000305"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(53.5), float(21.5), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([15.5,53.5,21.5], [14.391,54.985,20.064], color="red blue", name="Arrows_12.6180000305_7")

cluster_dict["12.6180000305"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(46.5), float(18.0), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([16.5,46.5,18.0], [13.87,48.102,17.509], color="red blue", name="Arrows_12.6180000305_8")

cluster_dict["12.6180000305"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(45.5), float(27.0), float(1.0)]

cluster_dict["12.6180000305_arrows"] += cgo_arrow([17.0,45.5,27.0], [19.435,44.038,28.278], color="red blue", name="Arrows_12.6180000305_9")

cmd.load_cgo(cluster_dict["12.6180000305"], "Features_12.6180000305", 1)
cmd.load_cgo(cluster_dict["12.6180000305_arrows"], "Arrows_12.6180000305")
cmd.set("transparency", 0.2,"Features_12.6180000305")
cmd.group("Pharmacophore_12.6180000305", members="Features_12.6180000305")
cmd.group("Pharmacophore_12.6180000305", members="Arrows_12.6180000305")

if dirpath:
    f = join(dirpath, "label_threshold_12.6180000305.mol2")
else:
    f = "label_threshold_12.6180000305.mol2"

cmd.load(f, 'label_threshold_12.6180000305')
cmd.hide('everything', 'label_threshold_12.6180000305')
cmd.label("label_threshold_12.6180000305", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_12.6180000305', members= 'label_threshold_12.6180000305')
