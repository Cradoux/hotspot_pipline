
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.9179992676":[], "16.9179992676_arrows":[]}

cluster_dict["16.9179992676"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(40.0), float(-0.5), float(-17.0), float(1.0)]

cluster_dict["16.9179992676_arrows"] += cgo_arrow([40.0,-0.5,-17.0], [39.544,-0.566,-14.152], color="blue red", name="Arrows_16.9179992676_1")

cluster_dict["16.9179992676"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(42.5), float(-0.5), float(-20.0), float(1.0)]

cluster_dict["16.9179992676_arrows"] += cgo_arrow([42.5,-0.5,-20.0], [42.983,-2.845,-21.818], color="blue red", name="Arrows_16.9179992676_2")

cluster_dict["16.9179992676"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(46.0), float(2.5), float(-19.0), float(1.0)]

cluster_dict["16.9179992676_arrows"] += cgo_arrow([46.0,2.5,-19.0], [46.799,4.205,-16.758], color="blue red", name="Arrows_16.9179992676_3")

cluster_dict["16.9179992676"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(41.7578232582), float(3.63584239611), float(-21.3633680948), float(1.0)]


cluster_dict["16.9179992676"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(-2.5), float(-17.5), float(1.0)]

cluster_dict["16.9179992676_arrows"] += cgo_arrow([36.0,-2.5,-17.5], [36.188,-3.85,-14.011], color="red blue", name="Arrows_16.9179992676_4")

cluster_dict["16.9179992676"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(-2.5), float(-17.5), float(1.0)]

cluster_dict["16.9179992676_arrows"] += cgo_arrow([36.0,-2.5,-17.5], [36.188,-3.85,-14.011], color="red blue", name="Arrows_16.9179992676_5")

cluster_dict["16.9179992676"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(38.0), float(5.0), float(-18.0), float(1.0)]

cluster_dict["16.9179992676_arrows"] += cgo_arrow([38.0,5.0,-18.0], [36.971,3.647,-15.506], color="red blue", name="Arrows_16.9179992676_6")

cluster_dict["16.9179992676"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(40.0), float(-3.0), float(-18.0), float(1.0)]

cluster_dict["16.9179992676_arrows"] += cgo_arrow([40.0,-3.0,-18.0], [43.999,-4.142,-19.151], color="red blue", name="Arrows_16.9179992676_7")

cluster_dict["16.9179992676"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(43.0), float(0.5), float(-22.0), float(1.0)]


cluster_dict["16.9179992676"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(46.5), float(6.5), float(-25.5), float(1.0)]

cluster_dict["16.9179992676_arrows"] += cgo_arrow([46.5,6.5,-25.5], [47.586,4.444,-27.546], color="red blue", name="Arrows_16.9179992676_8")

cmd.load_cgo(cluster_dict["16.9179992676"], "Features_16.9179992676", 1)
cmd.load_cgo(cluster_dict["16.9179992676_arrows"], "Arrows_16.9179992676")
cmd.set("transparency", 0.2,"Features_16.9179992676")
cmd.group("Pharmacophore_16.9179992676", members="Features_16.9179992676")
cmd.group("Pharmacophore_16.9179992676", members="Arrows_16.9179992676")

if dirpath:
    f = join(dirpath, "label_threshold_16.9179992676.mol2")
else:
    f = "label_threshold_16.9179992676.mol2"

cmd.load(f, 'label_threshold_16.9179992676')
cmd.hide('everything', 'label_threshold_16.9179992676')
cmd.label("label_threshold_16.9179992676", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.9179992676', members= 'label_threshold_16.9179992676')
