
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.013999939":[], "16.013999939_arrows":[]}

cluster_dict["16.013999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(42.0), float(20.5), float(1.0)]

cluster_dict["16.013999939_arrows"] += cgo_arrow([23.0,42.0,20.5], [21.792,42.89,17.917], color="blue red", name="Arrows_16.013999939_1")

cluster_dict["16.013999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(42.0), float(20.5), float(1.0)]

cluster_dict["16.013999939_arrows"] += cgo_arrow([23.0,42.0,20.5], [21.792,42.89,17.917], color="blue red", name="Arrows_16.013999939_2")

cluster_dict["16.013999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(44.5), float(13.5), float(1.0)]

cluster_dict["16.013999939_arrows"] += cgo_arrow([26.0,44.5,13.5], [23.869,44.199,14.749], color="blue red", name="Arrows_16.013999939_3")

cluster_dict["16.013999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(45.0), float(15.5), float(1.0)]

cluster_dict["16.013999939_arrows"] += cgo_arrow([26.0,45.0,15.5], [23.869,44.199,14.749], color="blue red", name="Arrows_16.013999939_4")

cluster_dict["16.013999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(42.0), float(16.5), float(1.0)]

cluster_dict["16.013999939_arrows"] += cgo_arrow([30.0,42.0,16.5], [32.135,42.72,14.753], color="blue red", name="Arrows_16.013999939_5")

cluster_dict["16.013999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.0652979484), float(39.9161904697), float(23.3878309611), float(1.0)]


cluster_dict["16.013999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.409764407), float(42.3185661634), float(17.2182060054), float(1.0)]


cluster_dict["16.013999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(23.9615384615), float(43.7307692308), float(26.0), float(1.0)]


cluster_dict["16.013999939"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(44.5), float(21.0), float(1.0)]

cluster_dict["16.013999939_arrows"] += cgo_arrow([22.5,44.5,21.0], [22.183,45.976,18.664], color="red blue", name="Arrows_16.013999939_6")

cluster_dict["16.013999939"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(44.5), float(24.0), float(1.0)]

cluster_dict["16.013999939_arrows"] += cgo_arrow([22.5,44.5,24.0], [19.407,45.482,25.054], color="red blue", name="Arrows_16.013999939_7")

cluster_dict["16.013999939"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(45.5), float(17.0), float(1.0)]

cluster_dict["16.013999939_arrows"] += cgo_arrow([25.5,45.5,17.0], [23.869,44.199,14.749], color="red blue", name="Arrows_16.013999939_8")

cmd.load_cgo(cluster_dict["16.013999939"], "Features_16.013999939", 1)
cmd.load_cgo(cluster_dict["16.013999939_arrows"], "Arrows_16.013999939")
cmd.set("transparency", 0.2,"Features_16.013999939")
cmd.group("Pharmacophore_16.013999939", members="Features_16.013999939")
cmd.group("Pharmacophore_16.013999939", members="Arrows_16.013999939")

if dirpath:
    f = join(dirpath, "label_threshold_16.013999939.mol2")
else:
    f = "label_threshold_16.013999939.mol2"

cmd.load(f, 'label_threshold_16.013999939')
cmd.hide('everything', 'label_threshold_16.013999939')
cmd.label("label_threshold_16.013999939", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.013999939', members= 'label_threshold_16.013999939')
