
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.404999733":[], "15.404999733_arrows":[]}

cluster_dict["15.404999733"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(42.0), float(20.5), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([23.0,42.0,20.5], [21.792,42.89,17.917], color="blue red", name="Arrows_15.404999733_1")

cluster_dict["15.404999733"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(42.0), float(20.5), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([23.0,42.0,20.5], [21.792,42.89,17.917], color="blue red", name="Arrows_15.404999733_2")

cluster_dict["15.404999733"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(44.5), float(13.5), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([26.0,44.5,13.5], [23.869,44.199,14.749], color="blue red", name="Arrows_15.404999733_3")

cluster_dict["15.404999733"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(45.0), float(15.5), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([26.0,45.0,15.5], [23.869,44.199,14.749], color="blue red", name="Arrows_15.404999733_4")

cluster_dict["15.404999733"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(42.0), float(16.5), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([30.0,42.0,16.5], [32.135,42.72,14.753], color="blue red", name="Arrows_15.404999733_5")

cluster_dict["15.404999733"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(24.0200196403), float(41.0406786373), float(20.3680364552), float(1.0)]


cluster_dict["15.404999733"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.5959770965), float(40.8839083861), float(18.0), float(1.0)]


cluster_dict["15.404999733"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(29.8993660971), float(46.8545972047), float(12.754445023), float(1.0)]


cluster_dict["15.404999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(44.5), float(21.0), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([22.5,44.5,21.0], [22.183,45.976,18.664], color="red blue", name="Arrows_15.404999733_6")

cluster_dict["15.404999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(44.5), float(24.0), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([22.5,44.5,24.0], [19.407,45.482,25.054], color="red blue", name="Arrows_15.404999733_7")

cluster_dict["15.404999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(45.5), float(17.0), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([25.5,45.5,17.0], [23.869,44.199,14.749], color="red blue", name="Arrows_15.404999733_8")

cluster_dict["15.404999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(39.0), float(13.0), float(1.0)]

cluster_dict["15.404999733_arrows"] += cgo_arrow([29.5,39.0,13.0], [28.345,38.011,15.772], color="red blue", name="Arrows_15.404999733_9")

cmd.load_cgo(cluster_dict["15.404999733"], "Features_15.404999733", 1)
cmd.load_cgo(cluster_dict["15.404999733_arrows"], "Arrows_15.404999733")
cmd.set("transparency", 0.2,"Features_15.404999733")
cmd.group("Pharmacophore_15.404999733", members="Features_15.404999733")
cmd.group("Pharmacophore_15.404999733", members="Arrows_15.404999733")

if dirpath:
    f = join(dirpath, "label_threshold_15.404999733.mol2")
else:
    f = "label_threshold_15.404999733.mol2"

cmd.load(f, 'label_threshold_15.404999733')
cmd.hide('everything', 'label_threshold_15.404999733')
cmd.label("label_threshold_15.404999733", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.404999733', members= 'label_threshold_15.404999733')
