
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.6789999008":[], "13.6789999008_arrows":[]}

cluster_dict["13.6789999008"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(11.0), float(-30.5), float(20.5), float(1.0)]

cluster_dict["13.6789999008_arrows"] += cgo_arrow([11.0,-30.5,20.5], [9.585,-29.781,18.163], color="blue red", name="Arrows_13.6789999008_1")

cluster_dict["13.6789999008"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(14.0), float(-30.0), float(25.0), float(1.0)]

cluster_dict["13.6789999008_arrows"] += cgo_arrow([14.0,-30.0,25.0], [9.882,-32.205,24.114], color="blue red", name="Arrows_13.6789999008_2")

cluster_dict["13.6789999008"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(15.6933459066), float(-28.6284494322), float(21.7644730691), float(1.0)]


cluster_dict["13.6789999008"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.5), float(-29.5), float(22.5), float(1.0)]

cluster_dict["13.6789999008_arrows"] += cgo_arrow([13.5,-29.5,22.5], [13.553,-32.357,23.289], color="red blue", name="Arrows_13.6789999008_3")

cluster_dict["13.6789999008"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(-33.0), float(25.5), float(1.0)]

cluster_dict["13.6789999008_arrows"] += cgo_arrow([15.5,-33.0,25.5], [13.553,-32.357,23.289], color="red blue", name="Arrows_13.6789999008_4")

cluster_dict["13.6789999008"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(-23.0), float(20.5), float(1.0)]

cluster_dict["13.6789999008_arrows"] += cgo_arrow([16.5,-23.0,20.5], [16.178,-24.525,22.851], color="red blue", name="Arrows_13.6789999008_5")

cmd.load_cgo(cluster_dict["13.6789999008"], "Features_13.6789999008", 1)
cmd.load_cgo(cluster_dict["13.6789999008_arrows"], "Arrows_13.6789999008")
cmd.set("transparency", 0.2,"Features_13.6789999008")
cmd.group("Pharmacophore_13.6789999008", members="Features_13.6789999008")
cmd.group("Pharmacophore_13.6789999008", members="Arrows_13.6789999008")

if dirpath:
    f = join(dirpath, "label_threshold_13.6789999008.mol2")
else:
    f = "label_threshold_13.6789999008.mol2"

cmd.load(f, 'label_threshold_13.6789999008')
cmd.hide('everything', 'label_threshold_13.6789999008')
cmd.label("label_threshold_13.6789999008", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.6789999008', members= 'label_threshold_13.6789999008')
