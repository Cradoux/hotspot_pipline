
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.3349990845":[], "17.3349990845_arrows":[]}

cluster_dict["17.3349990845"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-4.0), float(5.5), float(35.0), float(1.0)]

cluster_dict["17.3349990845_arrows"] += cgo_arrow([-4.0,5.5,35.0], [-5.806,3.277,33.264], color="blue red", name="Arrows_17.3349990845_1")

cluster_dict["17.3349990845"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(4.0), float(5.5), float(32.5), float(1.0)]

cluster_dict["17.3349990845_arrows"] += cgo_arrow([4.0,5.5,32.5], [4.428,7.941,30.839], color="blue red", name="Arrows_17.3349990845_2")

cluster_dict["17.3349990845"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(3.19466973367), float(4.94199290894), float(33.8716225064), float(1.0)]


cluster_dict["17.3349990845"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-5.5), float(5.5), float(35.5), float(1.0)]

cluster_dict["17.3349990845_arrows"] += cgo_arrow([-5.5,5.5,35.5], [-7.684,3.077,36.685], color="red blue", name="Arrows_17.3349990845_3")

cluster_dict["17.3349990845"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(1.5), float(5.5), float(34.5), float(1.0)]

cluster_dict["17.3349990845_arrows"] += cgo_arrow([1.5,5.5,34.5], [4.099,4.885,36.872], color="red blue", name="Arrows_17.3349990845_4")

cluster_dict["17.3349990845"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(0.0), float(5.0), float(32.5), float(1.0)]

cluster_dict["17.3349990845_arrows"] += cgo_arrow([0.0,5.0,32.5], [-1.528,3.649,30.394], color="red blue", name="Arrows_17.3349990845_5")

cluster_dict["17.3349990845"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(2.0), float(9.0), float(33.5), float(1.0)]

cluster_dict["17.3349990845_arrows"] += cgo_arrow([2.0,9.0,33.5], [3.428,11.483,32.678], color="red blue", name="Arrows_17.3349990845_6")

cluster_dict["17.3349990845"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(7.5), float(0.0), float(34.5), float(1.0)]


cluster_dict["17.3349990845"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(11.0), float(1.5), float(34.0), float(1.0)]

cluster_dict["17.3349990845_arrows"] += cgo_arrow([11.0,1.5,34.0], [13.026,0.93,37.598], color="red blue", name="Arrows_17.3349990845_7")

cluster_dict["17.3349990845"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(10.0), float(1.5), float(32.0), float(1.0)]


cmd.load_cgo(cluster_dict["17.3349990845"], "Features_17.3349990845", 1)
cmd.load_cgo(cluster_dict["17.3349990845_arrows"], "Arrows_17.3349990845")
cmd.set("transparency", 0.2,"Features_17.3349990845")
cmd.group("Pharmacophore_17.3349990845", members="Features_17.3349990845")
cmd.group("Pharmacophore_17.3349990845", members="Arrows_17.3349990845")

if dirpath:
    f = join(dirpath, "label_threshold_17.3349990845.mol2")
else:
    f = "label_threshold_17.3349990845.mol2"

cmd.load(f, 'label_threshold_17.3349990845')
cmd.hide('everything', 'label_threshold_17.3349990845')
cmd.label("label_threshold_17.3349990845", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.3349990845', members= 'label_threshold_17.3349990845')
