
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.6000003815":[], "13.6000003815_arrows":[]}

cluster_dict["13.6000003815"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-5.5), float(169.0), float(250.0), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([-5.5,169.0,250.0], [-7.174,168.495,252.421], color="blue red", name="Arrows_13.6000003815_1")

cluster_dict["13.6000003815"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(0.5), float(169.5), float(248.5), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([0.5,169.5,248.5], [0.757,167.114,246.986], color="blue red", name="Arrows_13.6000003815_2")

cluster_dict["13.6000003815"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(4.0), float(173.0), float(249.5), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([4.0,173.0,249.5], [6.108,174.259,247.704], color="blue red", name="Arrows_13.6000003815_3")

cluster_dict["13.6000003815"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(5.0), float(171.0), float(243.5), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([5.0,171.0,243.5], [5.69,168.686,244.539], color="blue red", name="Arrows_13.6000003815_4")

cluster_dict["13.6000003815"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-1.2418262005), float(170.820573491), float(247.801329933), float(1.0)]


cluster_dict["13.6000003815"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-2.5), float(170.0), float(253.0), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([-2.5,170.0,253.0], [-4.667,167.69,253.552], color="red blue", name="Arrows_13.6000003815_5")

cluster_dict["13.6000003815"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(0.0), float(172.5), float(248.5), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([0.0,172.5,248.5], [-1.924,175.146,250.952], color="red blue", name="Arrows_13.6000003815_6")

cluster_dict["13.6000003815"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(1.5), float(174.0), float(248.5), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([1.5,174.0,248.5], [-1.924,175.146,250.952], color="red blue", name="Arrows_13.6000003815_7")

cluster_dict["13.6000003815"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(2.0), float(175.0), float(246.5), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([2.0,175.0,246.5], [4.733,176.608,244.082], color="red blue", name="Arrows_13.6000003815_8")

cluster_dict["13.6000003815"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(4.0), float(170.5), float(248.0), float(1.0)]

cluster_dict["13.6000003815_arrows"] += cgo_arrow([4.0,170.5,248.0], [3.183,168.074,250.353], color="red blue", name="Arrows_13.6000003815_9")

cmd.load_cgo(cluster_dict["13.6000003815"], "Features_13.6000003815", 1)
cmd.load_cgo(cluster_dict["13.6000003815_arrows"], "Arrows_13.6000003815")
cmd.set("transparency", 0.2,"Features_13.6000003815")
cmd.group("Pharmacophore_13.6000003815", members="Features_13.6000003815")
cmd.group("Pharmacophore_13.6000003815", members="Arrows_13.6000003815")

if dirpath:
    f = join(dirpath, "label_threshold_13.6000003815.mol2")
else:
    f = "label_threshold_13.6000003815.mol2"

cmd.load(f, 'label_threshold_13.6000003815')
cmd.hide('everything', 'label_threshold_13.6000003815')
cmd.label("label_threshold_13.6000003815", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.6000003815', members= 'label_threshold_13.6000003815')
