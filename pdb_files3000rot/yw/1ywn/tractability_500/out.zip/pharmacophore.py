
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.5699996948":[], "17.5699996948_arrows":[]}

cluster_dict["17.5699996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(1.5), float(37.5), float(14.5), float(1.0)]

cluster_dict["17.5699996948_arrows"] += cgo_arrow([1.5,37.5,14.5], [-0.422,38.866,12.703], color="blue red", name="Arrows_17.5699996948_1")

cluster_dict["17.5699996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(1.5), float(37.5), float(14.5), float(1.0)]

cluster_dict["17.5699996948_arrows"] += cgo_arrow([1.5,37.5,14.5], [-0.422,38.866,12.703], color="blue red", name="Arrows_17.5699996948_2")

cluster_dict["17.5699996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(28.5), float(19.5), float(1.0)]

cluster_dict["17.5699996948_arrows"] += cgo_arrow([2.5,28.5,19.5], [5.259,27.287,18.789], color="blue red", name="Arrows_17.5699996948_3")

cluster_dict["17.5699996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(4.0), float(32.5), float(15.5), float(1.0)]

cluster_dict["17.5699996948_arrows"] += cgo_arrow([4.0,32.5,15.5], [6.051,31.184,13.663], color="blue red", name="Arrows_17.5699996948_4")

cluster_dict["17.5699996948"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(2.31182845255), float(43.5677976075), float(15.5578537543), float(1.0)]


cluster_dict["17.5699996948"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(0.849327143144), float(32.8665990981), float(15.612059146), float(1.0)]


cluster_dict["17.5699996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-1.5), float(31.5), float(15.5), float(1.0)]


cluster_dict["17.5699996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(36.0), float(15.5), float(1.0)]

cluster_dict["17.5699996948_arrows"] += cgo_arrow([2.5,36.0,15.5], [2.014,39.461,18.603], color="red blue", name="Arrows_17.5699996948_5")

cluster_dict["17.5699996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(36.0), float(15.5), float(1.0)]

cluster_dict["17.5699996948_arrows"] += cgo_arrow([2.5,36.0,15.5], [2.014,39.461,18.603], color="red blue", name="Arrows_17.5699996948_6")

cluster_dict["17.5699996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(3.5), float(29.5), float(16.0), float(1.0)]

cluster_dict["17.5699996948_arrows"] += cgo_arrow([3.5,29.5,16.0], [6.367,28.535,16.294], color="red blue", name="Arrows_17.5699996948_7")

cluster_dict["17.5699996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(5.0), float(46.5), float(18.5), float(1.0)]

cluster_dict["17.5699996948_arrows"] += cgo_arrow([5.0,46.5,18.5], [4.082,48.1,21.486], color="red blue", name="Arrows_17.5699996948_8")

cmd.load_cgo(cluster_dict["17.5699996948"], "Features_17.5699996948", 1)
cmd.load_cgo(cluster_dict["17.5699996948_arrows"], "Arrows_17.5699996948")
cmd.set("transparency", 0.2,"Features_17.5699996948")
cmd.group("Pharmacophore_17.5699996948", members="Features_17.5699996948")
cmd.group("Pharmacophore_17.5699996948", members="Arrows_17.5699996948")

if dirpath:
    f = join(dirpath, "label_threshold_17.5699996948.mol2")
else:
    f = "label_threshold_17.5699996948.mol2"

cmd.load(f, 'label_threshold_17.5699996948')
cmd.hide('everything', 'label_threshold_17.5699996948')
cmd.label("label_threshold_17.5699996948", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.5699996948', members= 'label_threshold_17.5699996948')
