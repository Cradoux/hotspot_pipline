
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"10.3400001526":[], "10.3400001526_arrows":[]}

cluster_dict["10.3400001526"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(9.0), float(16.0), float(28.0), float(1.0)]

cluster_dict["10.3400001526_arrows"] += cgo_arrow([9.0,16.0,28.0], [8.812,14.79,30.582], color="blue red", name="Arrows_10.3400001526_1")

cluster_dict["10.3400001526"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(9.82400071025), float(15.8069867439), float(25.7812292612), float(1.0)]


cluster_dict["10.3400001526"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.5), float(16.5), float(26.0), float(1.0)]

cluster_dict["10.3400001526_arrows"] += cgo_arrow([13.5,16.5,26.0], [15.637,15.324,27.84], color="red blue", name="Arrows_10.3400001526_2")

cluster_dict["10.3400001526"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(18.5), float(24.5), float(1.0)]

cluster_dict["10.3400001526_arrows"] += cgo_arrow([16.0,18.5,24.5], [15.83,15.852,23.048], color="red blue", name="Arrows_10.3400001526_3")

cmd.load_cgo(cluster_dict["10.3400001526"], "Features_10.3400001526", 1)
cmd.load_cgo(cluster_dict["10.3400001526_arrows"], "Arrows_10.3400001526")
cmd.set("transparency", 0.2,"Features_10.3400001526")
cmd.group("Pharmacophore_10.3400001526", members="Features_10.3400001526")
cmd.group("Pharmacophore_10.3400001526", members="Arrows_10.3400001526")

if dirpath:
    f = join(dirpath, "label_threshold_10.3400001526.mol2")
else:
    f = "label_threshold_10.3400001526.mol2"

cmd.load(f, 'label_threshold_10.3400001526')
cmd.hide('everything', 'label_threshold_10.3400001526')
cmd.label("label_threshold_10.3400001526", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_10.3400001526', members= 'label_threshold_10.3400001526')
