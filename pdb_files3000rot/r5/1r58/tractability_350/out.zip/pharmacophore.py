
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.5229997635":[], "15.5229997635_arrows":[]}

cluster_dict["15.5229997635"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(21.0), float(26.5), float(16.5), float(1.0)]

cluster_dict["15.5229997635_arrows"] += cgo_arrow([21.0,26.5,16.5], [21.013,25.218,14.284], color="blue red", name="Arrows_15.5229997635_1")

cluster_dict["15.5229997635"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(18.5448146365), float(31.928935901), float(16.3150946405), float(1.0)]


cluster_dict["15.5229997635"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(12.5), float(34.0), float(17.5), float(1.0)]

cluster_dict["15.5229997635_arrows"] += cgo_arrow([12.5,34.0,17.5], [14.582,36.399,16.508], color="red blue", name="Arrows_15.5229997635_2")

cluster_dict["15.5229997635"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(21.0), float(35.0), float(16.0), float(1.0)]

cluster_dict["15.5229997635_arrows"] += cgo_arrow([21.0,35.0,16.0], [22.095,38.925,15.612], color="red blue", name="Arrows_15.5229997635_3")

cluster_dict["15.5229997635"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(32.5), float(15.5), float(1.0)]

cluster_dict["15.5229997635_arrows"] += cgo_arrow([22.5,32.5,15.5], [25.339,35.489,18.215], color="red blue", name="Arrows_15.5229997635_4")

cmd.load_cgo(cluster_dict["15.5229997635"], "Features_15.5229997635", 1)
cmd.load_cgo(cluster_dict["15.5229997635_arrows"], "Arrows_15.5229997635")
cmd.set("transparency", 0.2,"Features_15.5229997635")
cmd.group("Pharmacophore_15.5229997635", members="Features_15.5229997635")
cmd.group("Pharmacophore_15.5229997635", members="Arrows_15.5229997635")

if dirpath:
    f = join(dirpath, "label_threshold_15.5229997635.mol2")
else:
    f = "label_threshold_15.5229997635.mol2"

cmd.load(f, 'label_threshold_15.5229997635')
cmd.hide('everything', 'label_threshold_15.5229997635')
cmd.label("label_threshold_15.5229997635", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.5229997635', members= 'label_threshold_15.5229997635')
