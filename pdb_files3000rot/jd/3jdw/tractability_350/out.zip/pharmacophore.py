
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.7609996796":[], "13.7609996796_arrows":[]}

cluster_dict["13.7609996796"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(46.5), float(73.5), float(14.5), float(1.0)]

cluster_dict["13.7609996796_arrows"] += cgo_arrow([46.5,73.5,14.5], [44.9,70.913,13.25], color="blue red", name="Arrows_13.7609996796_1")

cluster_dict["13.7609996796"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(46.5), float(73.5), float(14.5), float(1.0)]

cluster_dict["13.7609996796_arrows"] += cgo_arrow([46.5,73.5,14.5], [44.9,70.913,13.25], color="blue red", name="Arrows_13.7609996796_2")

cluster_dict["13.7609996796"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(44.0), float(73.0), float(19.0), float(1.0)]

cluster_dict["13.7609996796_arrows"] += cgo_arrow([44.0,73.0,19.0], [42.775,75.507,19.924], color="blue red", name="Arrows_13.7609996796_3")

cluster_dict["13.7609996796"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(46.5), float(71.0), float(16.5), float(1.0)]

cluster_dict["13.7609996796_arrows"] += cgo_arrow([46.5,71.0,16.5], [44.9,70.913,13.25], color="blue red", name="Arrows_13.7609996796_4")

cluster_dict["13.7609996796"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(41.972593237), float(80.5123275304), float(14.5805313699), float(1.0)]


cluster_dict["13.7609996796"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(45.5348721988), float(72.2499561365), float(16.2128594018), float(1.0)]


cluster_dict["13.7609996796"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(47.257620355), float(76.757620355), float(14.8833136558), float(1.0)]


cluster_dict["13.7609996796"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(47.4404300499), float(77.2357419701), float(15.0595699501), float(1.0)]


cluster_dict["13.7609996796"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(42.0), float(72.5), float(13.5), float(1.0)]

cluster_dict["13.7609996796_arrows"] += cgo_arrow([42.0,72.5,13.5], [43.61,72.345,11.062], color="red blue", name="Arrows_13.7609996796_5")

cluster_dict["13.7609996796"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(45.0), float(73.5), float(17.5), float(1.0)]

cluster_dict["13.7609996796_arrows"] += cgo_arrow([45.0,73.5,17.5], [45.656,76.341,19.264], color="red blue", name="Arrows_13.7609996796_6")

cluster_dict["13.7609996796"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(44.0), float(77.5), float(16.0), float(1.0)]

cluster_dict["13.7609996796_arrows"] += cgo_arrow([44.0,77.5,16.0], [43.632,79.741,17.764], color="red blue", name="Arrows_13.7609996796_7")

cmd.load_cgo(cluster_dict["13.7609996796"], "Features_13.7609996796", 1)
cmd.load_cgo(cluster_dict["13.7609996796_arrows"], "Arrows_13.7609996796")
cmd.set("transparency", 0.2,"Features_13.7609996796")
cmd.group("Pharmacophore_13.7609996796", members="Features_13.7609996796")
cmd.group("Pharmacophore_13.7609996796", members="Arrows_13.7609996796")

if dirpath:
    f = join(dirpath, "label_threshold_13.7609996796.mol2")
else:
    f = "label_threshold_13.7609996796.mol2"

cmd.load(f, 'label_threshold_13.7609996796')
cmd.hide('everything', 'label_threshold_13.7609996796')
cmd.label("label_threshold_13.7609996796", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.7609996796', members= 'label_threshold_13.7609996796')
