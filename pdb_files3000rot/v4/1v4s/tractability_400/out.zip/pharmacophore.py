
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.2159996033":[], "15.2159996033_arrows":[]}

cluster_dict["15.2159996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(19.0), float(57.0), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([36.5,19.0,57.0], [34.748,16.322,56.81], color="blue red", name="Arrows_15.2159996033_1")

cluster_dict["15.2159996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(39.0), float(17.5), float(61.0), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([39.0,17.5,61.0], [40.059,15.519,58.856], color="blue red", name="Arrows_15.2159996033_2")

cluster_dict["15.2159996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(40.0), float(24.0), float(60.0), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([40.0,24.0,60.0], [37.531,24.144,61.642], color="blue red", name="Arrows_15.2159996033_3")

cluster_dict["15.2159996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(40.0), float(18.5), float(64.5), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([40.0,18.5,64.5], [42.04,17.748,66.666], color="blue red", name="Arrows_15.2159996033_4")

cluster_dict["15.2159996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(42.0), float(10.0), float(63.5), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([42.0,10.0,63.5], [43.007,7.661,65.091], color="blue red", name="Arrows_15.2159996033_5")

cluster_dict["15.2159996033"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(39.2490018678), float(17.3413102136), float(60.9045078689), float(1.0)]


cluster_dict["15.2159996033"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(37.5), float(17.5), float(63.0), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([37.5,17.5,63.0], [35.617,18.465,66.87], color="red blue", name="Arrows_15.2159996033_6")

cluster_dict["15.2159996033"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(40.0), float(17.0), float(65.5), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([40.0,17.0,65.5], [42.04,17.748,66.666], color="red blue", name="Arrows_15.2159996033_7")

cluster_dict["15.2159996033"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(41.5), float(18.0), float(63.0), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([41.5,18.0,63.0], [45.018,17.321,62.219], color="red blue", name="Arrows_15.2159996033_8")

cluster_dict["15.2159996033"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(43.5), float(13.0), float(61.5), float(1.0)]

cluster_dict["15.2159996033_arrows"] += cgo_arrow([43.5,13.0,61.5], [43.012,15.508,59.647], color="red blue", name="Arrows_15.2159996033_9")

cmd.load_cgo(cluster_dict["15.2159996033"], "Features_15.2159996033", 1)
cmd.load_cgo(cluster_dict["15.2159996033_arrows"], "Arrows_15.2159996033")
cmd.set("transparency", 0.2,"Features_15.2159996033")
cmd.group("Pharmacophore_15.2159996033", members="Features_15.2159996033")
cmd.group("Pharmacophore_15.2159996033", members="Arrows_15.2159996033")

if dirpath:
    f = join(dirpath, "label_threshold_15.2159996033.mol2")
else:
    f = "label_threshold_15.2159996033.mol2"

cmd.load(f, 'label_threshold_15.2159996033')
cmd.hide('everything', 'label_threshold_15.2159996033')
cmd.label("label_threshold_15.2159996033", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.2159996033', members= 'label_threshold_15.2159996033')
