
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.0990009308":[], "17.0990009308_arrows":[]}

cluster_dict["17.0990009308"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-27.5), float(150.0), float(58.0), float(1.0)]

cluster_dict["17.0990009308_arrows"] += cgo_arrow([-27.5,150.0,58.0], [-28.645,151.11,60.419], color="blue red", name="Arrows_17.0990009308_1")

cluster_dict["17.0990009308"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-24.5), float(151.0), float(57.0), float(1.0)]

cluster_dict["17.0990009308_arrows"] += cgo_arrow([-24.5,151.0,57.0], [-21.963,148.062,56.622], color="blue red", name="Arrows_17.0990009308_2")

cluster_dict["17.0990009308"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-23.0), float(151.0), float(56.0), float(1.0)]

cluster_dict["17.0990009308_arrows"] += cgo_arrow([-23.0,151.0,56.0], [-21.963,148.062,56.622], color="blue red", name="Arrows_17.0990009308_3")

cluster_dict["17.0990009308"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-27.2964560393), float(152.144634709), float(56.8738141836), float(1.0)]


cluster_dict["17.0990009308"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-33.0), float(151.5), float(58.0), float(1.0)]

cluster_dict["17.0990009308_arrows"] += cgo_arrow([-33.0,151.5,58.0], [-30.715,150.471,60.731], color="red blue", name="Arrows_17.0990009308_4")

cluster_dict["17.0990009308"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-31.0), float(150.5), float(55.5), float(1.0)]

cluster_dict["17.0990009308_arrows"] += cgo_arrow([-31.0,150.5,55.5], [-34.61,150.654,54.431], color="red blue", name="Arrows_17.0990009308_5")

cluster_dict["17.0990009308"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-30.0), float(152.5), float(55.5), float(1.0)]


cluster_dict["17.0990009308"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-28.5), float(149.5), float(56.5), float(1.0)]

cluster_dict["17.0990009308_arrows"] += cgo_arrow([-28.5,149.5,56.5], [-30.336,148.482,58.963], color="red blue", name="Arrows_17.0990009308_6")

cluster_dict["17.0990009308"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-28.0), float(154.5), float(57.5), float(1.0)]

cluster_dict["17.0990009308_arrows"] += cgo_arrow([-28.0,154.5,57.5], [-28.645,151.11,60.419], color="red blue", name="Arrows_17.0990009308_7")

cluster_dict["17.0990009308"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-21.5), float(151.0), float(54.5), float(1.0)]

cluster_dict["17.0990009308_arrows"] += cgo_arrow([-21.5,151.0,54.5], [-18.5,150.526,55.499], color="red blue", name="Arrows_17.0990009308_8")

cmd.load_cgo(cluster_dict["17.0990009308"], "Features_17.0990009308", 1)
cmd.load_cgo(cluster_dict["17.0990009308_arrows"], "Arrows_17.0990009308")
cmd.set("transparency", 0.2,"Features_17.0990009308")
cmd.group("Pharmacophore_17.0990009308", members="Features_17.0990009308")
cmd.group("Pharmacophore_17.0990009308", members="Arrows_17.0990009308")

if dirpath:
    f = join(dirpath, "label_threshold_17.0990009308.mol2")
else:
    f = "label_threshold_17.0990009308.mol2"

cmd.load(f, 'label_threshold_17.0990009308')
cmd.hide('everything', 'label_threshold_17.0990009308')
cmd.label("label_threshold_17.0990009308", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.0990009308', members= 'label_threshold_17.0990009308')
