
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.8109998703":[], "14.8109998703_arrows":[]}

cluster_dict["14.8109998703"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-37.0), float(-5.0), float(20.0), float(1.0)]

cluster_dict["14.8109998703_arrows"] += cgo_arrow([-37.0,-5.0,20.0], [-38.622,-6.27,22.029], color="blue red", name="Arrows_14.8109998703_1")

cluster_dict["14.8109998703"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-36.0), float(-3.0), float(19.5), float(1.0)]

cluster_dict["14.8109998703_arrows"] += cgo_arrow([-36.0,-3.0,19.5], [-34.856,-3.36,23.916], color="blue red", name="Arrows_14.8109998703_2")

cluster_dict["14.8109998703"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-37.7888075656), float(-3.80413999504), float(14.8325897757), float(1.0)]


cluster_dict["14.8109998703"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-42.0), float(-3.5), float(16.5), float(1.0)]

cluster_dict["14.8109998703_arrows"] += cgo_arrow([-42.0,-3.5,16.5], [-43.746,-5.489,16.065], color="red blue", name="Arrows_14.8109998703_3")

cluster_dict["14.8109998703"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-39.0), float(-5.5), float(14.0), float(1.0)]


cluster_dict["14.8109998703"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-35.0), float(-2.0), float(15.0), float(1.0)]

cluster_dict["14.8109998703_arrows"] += cgo_arrow([-35.0,-2.0,15.0], [-32.307,-1.783,15.84], color="red blue", name="Arrows_14.8109998703_4")

cmd.load_cgo(cluster_dict["14.8109998703"], "Features_14.8109998703", 1)
cmd.load_cgo(cluster_dict["14.8109998703_arrows"], "Arrows_14.8109998703")
cmd.set("transparency", 0.2,"Features_14.8109998703")
cmd.group("Pharmacophore_14.8109998703", members="Features_14.8109998703")
cmd.group("Pharmacophore_14.8109998703", members="Arrows_14.8109998703")

if dirpath:
    f = join(dirpath, "label_threshold_14.8109998703.mol2")
else:
    f = "label_threshold_14.8109998703.mol2"

cmd.load(f, 'label_threshold_14.8109998703')
cmd.hide('everything', 'label_threshold_14.8109998703')
cmd.label("label_threshold_14.8109998703", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.8109998703', members= 'label_threshold_14.8109998703')
