
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.1890001297":[], "15.1890001297_arrows":[]}

cluster_dict["15.1890001297"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(14.0), float(3.5), float(16.0), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([14.0,3.5,16.0], [13.465,1.988,13.526], color="blue red", name="Arrows_15.1890001297_1")

cluster_dict["15.1890001297"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(2.0), float(10.0), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([16.5,2.0,10.0], [14.173,3.186,8.735], color="blue red", name="Arrows_15.1890001297_2")

cluster_dict["15.1890001297"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(17.0205008558), float(5.00743540801), float(13.7685046611), float(1.0)]


cluster_dict["15.1890001297"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(17.6662347627), float(2.91672065467), float(9.0), float(1.0)]


cluster_dict["15.1890001297"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(19.7472399259), float(2.00003956818), float(9.74723992591), float(1.0)]


cluster_dict["15.1890001297"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(2.5), float(17.0), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([16.0,2.5,17.0], [17.464,-0.224,17.579], color="red blue", name="Arrows_15.1890001297_3")

cluster_dict["15.1890001297"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(3.5), float(12.0), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([15.5,3.5,12.0], [13.406,5.822,11.575], color="red blue", name="Arrows_15.1890001297_4")

cluster_dict["15.1890001297"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(8.0), float(15.0), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([16.0,8.0,15.0], [13.406,5.822,11.575], color="red blue", name="Arrows_15.1890001297_5")

cluster_dict["15.1890001297"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(1.0), float(15.0), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([17.0,1.0,15.0], [17.464,-0.224,17.579], color="red blue", name="Arrows_15.1890001297_6")

cluster_dict["15.1890001297"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(2.5), float(13.5), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([17.5,2.5,13.5], [20.254,3.203,14.512], color="red blue", name="Arrows_15.1890001297_7")

cluster_dict["15.1890001297"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(1.5), float(11.0), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([19.5,1.5,11.0], [20.254,3.203,14.512], color="red blue", name="Arrows_15.1890001297_8")

cluster_dict["15.1890001297"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(1.5), float(11.0), float(1.0)]

cluster_dict["15.1890001297_arrows"] += cgo_arrow([19.5,1.5,11.0], [20.254,3.203,14.512], color="red blue", name="Arrows_15.1890001297_9")

cmd.load_cgo(cluster_dict["15.1890001297"], "Features_15.1890001297", 1)
cmd.load_cgo(cluster_dict["15.1890001297_arrows"], "Arrows_15.1890001297")
cmd.set("transparency", 0.2,"Features_15.1890001297")
cmd.group("Pharmacophore_15.1890001297", members="Features_15.1890001297")
cmd.group("Pharmacophore_15.1890001297", members="Arrows_15.1890001297")

if dirpath:
    f = join(dirpath, "label_threshold_15.1890001297.mol2")
else:
    f = "label_threshold_15.1890001297.mol2"

cmd.load(f, 'label_threshold_15.1890001297')
cmd.hide('everything', 'label_threshold_15.1890001297')
cmd.label("label_threshold_15.1890001297", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.1890001297', members= 'label_threshold_15.1890001297')
