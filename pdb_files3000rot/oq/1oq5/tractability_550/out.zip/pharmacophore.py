
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.4949998856":[], "13.4949998856_arrows":[]}

cluster_dict["13.4949998856"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(14.0), float(3.5), float(16.0), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([14.0,3.5,16.0], [13.465,1.988,13.526], color="blue red", name="Arrows_13.4949998856_1")

cluster_dict["13.4949998856"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(2.0), float(10.0), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([16.5,2.0,10.0], [14.173,3.186,8.735], color="blue red", name="Arrows_13.4949998856_2")

cluster_dict["13.4949998856"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(17.2032245328), float(4.98872854668), float(13.3945983294), float(1.0)]


cluster_dict["13.4949998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(1.0), float(15.0), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([17.0,1.0,15.0], [17.464,-0.224,17.579], color="red blue", name="Arrows_13.4949998856_3")

cluster_dict["13.4949998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(3.5), float(12.0), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([15.5,3.5,12.0], [13.406,5.822,11.575], color="red blue", name="Arrows_13.4949998856_4")

cluster_dict["13.4949998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(8.0), float(15.0), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([16.0,8.0,15.0], [13.406,5.822,11.575], color="red blue", name="Arrows_13.4949998856_5")

cluster_dict["13.4949998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(1.0), float(15.0), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([17.0,1.0,15.0], [17.464,-0.224,17.579], color="red blue", name="Arrows_13.4949998856_6")

cluster_dict["13.4949998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(2.5), float(13.5), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([17.5,2.5,13.5], [20.254,3.203,14.512], color="red blue", name="Arrows_13.4949998856_7")

cluster_dict["13.4949998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(1.5), float(11.0), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([19.5,1.5,11.0], [20.254,3.203,14.512], color="red blue", name="Arrows_13.4949998856_8")

cluster_dict["13.4949998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(1.5), float(11.0), float(1.0)]

cluster_dict["13.4949998856_arrows"] += cgo_arrow([19.5,1.5,11.0], [20.254,3.203,14.512], color="red blue", name="Arrows_13.4949998856_9")

cmd.load_cgo(cluster_dict["13.4949998856"], "Features_13.4949998856", 1)
cmd.load_cgo(cluster_dict["13.4949998856_arrows"], "Arrows_13.4949998856")
cmd.set("transparency", 0.2,"Features_13.4949998856")
cmd.group("Pharmacophore_13.4949998856", members="Features_13.4949998856")
cmd.group("Pharmacophore_13.4949998856", members="Arrows_13.4949998856")

if dirpath:
    f = join(dirpath, "label_threshold_13.4949998856.mol2")
else:
    f = "label_threshold_13.4949998856.mol2"

cmd.load(f, 'label_threshold_13.4949998856')
cmd.hide('everything', 'label_threshold_13.4949998856')
cmd.label("label_threshold_13.4949998856", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.4949998856', members= 'label_threshold_13.4949998856')
