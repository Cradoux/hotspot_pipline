
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.9449996948":[], "14.9449996948_arrows":[]}

cluster_dict["14.9449996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(-12.5), float(34.5), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([2.5,-12.5,34.5], [4.182,-11.8,37.801], color="blue red", name="Arrows_14.9449996948_1")

cluster_dict["14.9449996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(-12.5), float(34.5), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([2.5,-12.5,34.5], [4.182,-11.8,37.801], color="blue red", name="Arrows_14.9449996948_2")

cluster_dict["14.9449996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(10.5), float(-12.0), float(32.0), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([10.5,-12.0,32.0], [10.136,-14.416,34.373], color="blue red", name="Arrows_14.9449996948_3")

cluster_dict["14.9449996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(11.5), float(-14.0), float(31.0), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([11.5,-14.0,31.0], [10.645,-16.255,29.051], color="blue red", name="Arrows_14.9449996948_4")

cluster_dict["14.9449996948"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(-11.5), float(33.0), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([13.0,-11.5,33.0], [13.415,-8.724,35.278], color="blue red", name="Arrows_14.9449996948_5")

cluster_dict["14.9449996948"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(6.50482755621), float(-11.4130772357), float(32.4021324911), float(1.0)]


cluster_dict["14.9449996948"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(12.4742846082), float(-7.17754019165), float(33.4316362478), float(1.0)]


cluster_dict["14.9449996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(-13.5), float(27.0), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([2.5,-13.5,27.0], [3.171,-14.39,24.633], color="red blue", name="Arrows_14.9449996948_6")

cluster_dict["14.9449996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(3.0), float(-14.0), float(35.5), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([3.0,-14.0,35.5], [4.182,-11.8,37.801], color="red blue", name="Arrows_14.9449996948_7")

cluster_dict["14.9449996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(3.0), float(-13.0), float(36.5), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([3.0,-13.0,36.5], [4.182,-11.8,37.801], color="red blue", name="Arrows_14.9449996948_8")

cluster_dict["14.9449996948"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(4.5), float(-10.0), float(27.5), float(1.0)]

cluster_dict["14.9449996948_arrows"] += cgo_arrow([4.5,-10.0,27.5], [5.385,-10.845,25.006], color="red blue", name="Arrows_14.9449996948_9")

cmd.load_cgo(cluster_dict["14.9449996948"], "Features_14.9449996948", 1)
cmd.load_cgo(cluster_dict["14.9449996948_arrows"], "Arrows_14.9449996948")
cmd.set("transparency", 0.2,"Features_14.9449996948")
cmd.group("Pharmacophore_14.9449996948", members="Features_14.9449996948")
cmd.group("Pharmacophore_14.9449996948", members="Arrows_14.9449996948")

if dirpath:
    f = join(dirpath, "label_threshold_14.9449996948.mol2")
else:
    f = "label_threshold_14.9449996948.mol2"

cmd.load(f, 'label_threshold_14.9449996948')
cmd.hide('everything', 'label_threshold_14.9449996948')
cmd.label("label_threshold_14.9449996948", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.9449996948', members= 'label_threshold_14.9449996948')
