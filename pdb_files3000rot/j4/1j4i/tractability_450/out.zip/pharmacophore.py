
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"10.779999733":[], "10.779999733_arrows":[]}

cluster_dict["10.779999733"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(31.6714735452), float(-33.4614280414), float(-41.6510032784), float(1.0)]


cluster_dict["10.779999733"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(27.7663284705), float(-35.2933312225), float(-40.5976537759), float(1.0)]


cluster_dict["10.779999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(-34.5), float(-42.0), float(1.0)]

cluster_dict["10.779999733_arrows"] += cgo_arrow([28.5,-34.5,-42.0], [28.508,-35.292,-39.201], color="red blue", name="Arrows_10.779999733_1")

cluster_dict["10.779999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(-28.5), float(-41.0), float(1.0)]

cluster_dict["10.779999733_arrows"] += cgo_arrow([28.0,-28.5,-41.0], [30.429,-25.793,-41.989], color="red blue", name="Arrows_10.779999733_2")

cmd.load_cgo(cluster_dict["10.779999733"], "Features_10.779999733", 1)
cmd.load_cgo(cluster_dict["10.779999733_arrows"], "Arrows_10.779999733")
cmd.set("transparency", 0.2,"Features_10.779999733")
cmd.group("Pharmacophore_10.779999733", members="Features_10.779999733")
cmd.group("Pharmacophore_10.779999733", members="Arrows_10.779999733")

if dirpath:
    f = join(dirpath, "label_threshold_10.779999733.mol2")
else:
    f = "label_threshold_10.779999733.mol2"

cmd.load(f, 'label_threshold_10.779999733')
cmd.hide('everything', 'label_threshold_10.779999733')
cmd.label("label_threshold_10.779999733", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_10.779999733', members= 'label_threshold_10.779999733')
