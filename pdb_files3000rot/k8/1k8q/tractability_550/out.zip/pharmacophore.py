
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"18.7010002136":[], "18.7010002136_arrows":[]}

cluster_dict["18.7010002136"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(79.5), float(26.0), float(1.0)]

cluster_dict["18.7010002136_arrows"] += cgo_arrow([27.5,79.5,26.0], [29.808,77.916,26.239], color="blue red", name="Arrows_18.7010002136_1")

cluster_dict["18.7010002136"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.5), float(79.5), float(21.0), float(1.0)]

cluster_dict["18.7010002136_arrows"] += cgo_arrow([33.5,79.5,21.0], [31.339,80.486,20.698], color="blue red", name="Arrows_18.7010002136_2")

cluster_dict["18.7010002136"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(38.0), float(87.5), float(25.5), float(1.0)]

cluster_dict["18.7010002136_arrows"] += cgo_arrow([38.0,87.5,25.5], [39.517,89.678,24.804], color="blue red", name="Arrows_18.7010002136_3")

cluster_dict["18.7010002136"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(32.8838390208), float(82.8524284883), float(28.8020950229), float(1.0)]


cluster_dict["18.7010002136"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(79.5), float(25.0), float(1.0)]

cluster_dict["18.7010002136_arrows"] += cgo_arrow([26.0,79.5,25.0], [24.113,77.816,23.114], color="red blue", name="Arrows_18.7010002136_4")

cluster_dict["18.7010002136"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(32.5), float(79.0), float(22.5), float(1.0)]

cluster_dict["18.7010002136_arrows"] += cgo_arrow([32.5,79.0,22.5], [31.339,80.486,20.698], color="red blue", name="Arrows_18.7010002136_5")

cluster_dict["18.7010002136"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(34.0), float(86.0), float(27.0), float(1.0)]

cluster_dict["18.7010002136_arrows"] += cgo_arrow([34.0,86.0,27.0], [33.415,89.874,26.877], color="red blue", name="Arrows_18.7010002136_6")

cluster_dict["18.7010002136"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(82.5), float(33.0), float(1.0)]


cluster_dict["18.7010002136"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(82.5), float(33.0), float(1.0)]


cluster_dict["18.7010002136"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(38.0), float(86.5), float(25.5), float(1.0)]

cluster_dict["18.7010002136_arrows"] += cgo_arrow([38.0,86.5,25.5], [38.8,88.432,23.02], color="red blue", name="Arrows_18.7010002136_7")

cmd.load_cgo(cluster_dict["18.7010002136"], "Features_18.7010002136", 1)
cmd.load_cgo(cluster_dict["18.7010002136_arrows"], "Arrows_18.7010002136")
cmd.set("transparency", 0.2,"Features_18.7010002136")
cmd.group("Pharmacophore_18.7010002136", members="Features_18.7010002136")
cmd.group("Pharmacophore_18.7010002136", members="Arrows_18.7010002136")

if dirpath:
    f = join(dirpath, "label_threshold_18.7010002136.mol2")
else:
    f = "label_threshold_18.7010002136.mol2"

cmd.load(f, 'label_threshold_18.7010002136')
cmd.hide('everything', 'label_threshold_18.7010002136')
cmd.label("label_threshold_18.7010002136", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_18.7010002136', members= 'label_threshold_18.7010002136')
