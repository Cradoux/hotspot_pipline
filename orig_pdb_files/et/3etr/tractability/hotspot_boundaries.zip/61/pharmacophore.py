
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.8819999695":[], "15.8819999695_arrows":[]}

cluster_dict["15.8819999695"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-19.0), float(-8.0), float(33.5), float(1.0)]

cluster_dict["15.8819999695_arrows"] += cgo_arrow([-19.0,-8.0,33.5], [-20.183,-8.769,31.779], color="blue red", name="Arrows_15.8819999695_1")

cluster_dict["15.8819999695"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-17.5), float(-10.5), float(28.0), float(1.0)]

cluster_dict["15.8819999695_arrows"] += cgo_arrow([-17.5,-10.5,28.0], [-19.572,-9.949,26.024], color="blue red", name="Arrows_15.8819999695_2")

cluster_dict["15.8819999695"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-15.5), float(-13.0), float(33.5), float(1.0)]

cluster_dict["15.8819999695_arrows"] += cgo_arrow([-15.5,-13.0,33.5], [-18.251,-13.39,33.288], color="blue red", name="Arrows_15.8819999695_3")

cluster_dict["15.8819999695"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-23.1857651346), float(-17.2200114681), float(37.0519769517), float(1.0)]


cluster_dict["15.8819999695"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-18.8844205294), float(-7.51376315249), float(37.0975887935), float(1.0)]


cluster_dict["15.8819999695"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-15.5298795438), float(-13.3566427357), float(31.427262498), float(1.0)]


cluster_dict["15.8819999695"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-12.2572565123), float(-13.9725546503), float(43.256809705), float(1.0)]


cluster_dict["15.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-17.5), float(-8.0), float(36.5), float(1.0)]

cluster_dict["15.8819999695_arrows"] += cgo_arrow([-17.5,-8.0,36.5], [-14.978,-7.526,35.757], color="red blue", name="Arrows_15.8819999695_4")

cluster_dict["15.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-16.5), float(-10.0), float(27.0), float(1.0)]

cluster_dict["15.8819999695_arrows"] += cgo_arrow([-16.5,-10.0,27.0], [-19.572,-9.949,26.024], color="red blue", name="Arrows_15.8819999695_5")

cluster_dict["15.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-14.5), float(-14.0), float(43.5), float(1.0)]

cluster_dict["15.8819999695_arrows"] += cgo_arrow([-14.5,-14.0,43.5], [-15.04,-16.828,41.999], color="red blue", name="Arrows_15.8819999695_6")

cluster_dict["15.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-15.5), float(-4.5), float(35.0), float(1.0)]

cluster_dict["15.8819999695_arrows"] += cgo_arrow([-15.5,-4.5,35.0], [-14.978,-7.526,35.757], color="red blue", name="Arrows_15.8819999695_7")

cluster_dict["15.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-12.5), float(-13.0), float(42.5), float(1.0)]

cluster_dict["15.8819999695_arrows"] += cgo_arrow([-12.5,-13.0,42.5], [-13.853,-9.961,40.813], color="red blue", name="Arrows_15.8819999695_8")

cmd.load_cgo(cluster_dict["15.8819999695"], "Features_15.8819999695", 1)
cmd.load_cgo(cluster_dict["15.8819999695_arrows"], "Arrows_15.8819999695")
cmd.set("transparency", 0.2,"Features_15.8819999695")
cmd.group("Pharmacophore_15.8819999695", members="Features_15.8819999695")
cmd.group("Pharmacophore_15.8819999695", members="Arrows_15.8819999695")

if dirpath:
    f = join(dirpath, "label_threshold_15.8819999695.mol2")
else:
    f = "label_threshold_15.8819999695.mol2"

cmd.load(f, 'label_threshold_15.8819999695')
cmd.hide('everything', 'label_threshold_15.8819999695')
cmd.label("label_threshold_15.8819999695", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.8819999695', members= 'label_threshold_15.8819999695')
