
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.5570001602":[], "13.5570001602_arrows":[]}

cluster_dict["13.5570001602"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-11.0), float(8.5), float(30.5), float(1.0)]

cluster_dict["13.5570001602_arrows"] += cgo_arrow([-11.0,8.5,30.5], [-12.682,10.491,30.534], color="blue red", name="Arrows_13.5570001602_1")

cluster_dict["13.5570001602"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-8.50413955772), float(12.2589652309), float(28.6219068985), float(1.0)]


cluster_dict["13.5570001602"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-10.3910607962), float(8.31459573776), float(32.6452522717), float(1.0)]


cluster_dict["13.5570001602"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-8.32572708714), float(12.0406848078), float(38.4137080344), float(1.0)]


cluster_dict["13.5570001602"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-5.93172994162), float(19.9786139874), float(35.0098352585), float(1.0)]


cluster_dict["13.5570001602"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-6.88535031847), float(14.4872611465), float(29.9808917197), float(1.0)]


cluster_dict["13.5570001602"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-0.0151718870713), float(12.9404145944), float(43.999253171), float(1.0)]


cluster_dict["13.5570001602"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-6.5), float(18.0), float(32.5), float(1.0)]


cluster_dict["13.5570001602"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-4.5), float(8.0), float(30.0), float(1.0)]

cluster_dict["13.5570001602_arrows"] += cgo_arrow([-4.5,8.0,30.0], [-6.661,9.212,32.894], color="red blue", name="Arrows_13.5570001602_2")

cmd.load_cgo(cluster_dict["13.5570001602"], "Features_13.5570001602", 1)
cmd.load_cgo(cluster_dict["13.5570001602_arrows"], "Arrows_13.5570001602")
cmd.set("transparency", 0.2,"Features_13.5570001602")
cmd.group("Pharmacophore_13.5570001602", members="Features_13.5570001602")
cmd.group("Pharmacophore_13.5570001602", members="Arrows_13.5570001602")

if dirpath:
    f = join(dirpath, "label_threshold_13.5570001602.mol2")
else:
    f = "label_threshold_13.5570001602.mol2"

cmd.load(f, 'label_threshold_13.5570001602')
cmd.hide('everything', 'label_threshold_13.5570001602')
cmd.label("label_threshold_13.5570001602", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.5570001602', members= 'label_threshold_13.5570001602')
