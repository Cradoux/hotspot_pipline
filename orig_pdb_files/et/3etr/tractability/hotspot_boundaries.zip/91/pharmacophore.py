
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.2349996567":[], "13.2349996567_arrows":[]}

cluster_dict["13.2349996567"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-16.0), float(-3.0), float(54.0), float(1.0)]

cluster_dict["13.2349996567_arrows"] += cgo_arrow([-16.0,-3.0,54.0], [-17.363,-0.587,52.277], color="blue red", name="Arrows_13.2349996567_1")

cluster_dict["13.2349996567"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-16.0), float(-4.5), float(48.5), float(1.0)]

cluster_dict["13.2349996567_arrows"] += cgo_arrow([-16.0,-4.5,48.5], [-18.731,-2.721,49.33], color="blue red", name="Arrows_13.2349996567_2")

cluster_dict["13.2349996567"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-14.0), float(-4.0), float(46.5), float(1.0)]

cluster_dict["13.2349996567_arrows"] += cgo_arrow([-14.0,-4.0,46.5], [-13.027,-1.485,45.573], color="blue red", name="Arrows_13.2349996567_3")

cluster_dict["13.2349996567"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-12.5), float(-11.5), float(49.0), float(1.0)]

cluster_dict["13.2349996567_arrows"] += cgo_arrow([-12.5,-11.5,49.0], [-9.173,-12.246,47.746], color="blue red", name="Arrows_13.2349996567_4")

cluster_dict["13.2349996567"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-16.440752504), float(-8.06355100462), float(47.5568299782), float(1.0)]


cluster_dict["13.2349996567"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-17.6646354123), float(-13.2677194032), float(55.9536277695), float(1.0)]


cluster_dict["13.2349996567"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-16.0752768125), float(-2.40509635209), float(56.9283773099), float(1.0)]


cluster_dict["13.2349996567"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-14.4861385615), float(-0.639112063669), float(49.530595123), float(1.0)]


cluster_dict["13.2349996567"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-21.0), float(-6.0), float(45.5), float(1.0)]

cluster_dict["13.2349996567_arrows"] += cgo_arrow([-21.0,-6.0,45.5], [-22.337,-3.396,48.966], color="red blue", name="Arrows_13.2349996567_5")

cluster_dict["13.2349996567"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-19.0), float(-4.0), float(56.5), float(1.0)]

cluster_dict["13.2349996567_arrows"] += cgo_arrow([-19.0,-4.0,56.5], [-21.532,-6.13,56.958], color="red blue", name="Arrows_13.2349996567_6")

cluster_dict["13.2349996567"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-18.0), float(-2.0), float(57.5), float(1.0)]


cluster_dict["13.2349996567"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-17.0), float(-3.5), float(55.5), float(1.0)]


cluster_dict["13.2349996567"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-15.0), float(-0.5), float(46.5), float(1.0)]

cluster_dict["13.2349996567_arrows"] += cgo_arrow([-15.0,-0.5,46.5], [-17.71,0.005,45.762], color="red blue", name="Arrows_13.2349996567_7")

cmd.load_cgo(cluster_dict["13.2349996567"], "Features_13.2349996567", 1)
cmd.load_cgo(cluster_dict["13.2349996567_arrows"], "Arrows_13.2349996567")
cmd.set("transparency", 0.2,"Features_13.2349996567")
cmd.group("Pharmacophore_13.2349996567", members="Features_13.2349996567")
cmd.group("Pharmacophore_13.2349996567", members="Arrows_13.2349996567")

if dirpath:
    f = join(dirpath, "label_threshold_13.2349996567.mol2")
else:
    f = "label_threshold_13.2349996567.mol2"

cmd.load(f, 'label_threshold_13.2349996567')
cmd.hide('everything', 'label_threshold_13.2349996567')
cmd.label("label_threshold_13.2349996567", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.2349996567', members= 'label_threshold_13.2349996567')
