
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_16.0.mol2")
else:
    f = "label_threshold_16.0.mol2"

cmd.load(f, 'label_threshold_16.0')
cmd.hide('everything', 'label_threshold_16.0')
cmd.label("label_threshold_16.0", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [16.0]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"17.1770000458":[], "17.1770000458_arrows":[]}

cluster_dict["17.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(31.5), float(27.5), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([16.5,31.5,27.5], [18.584,34.583,29.301], color="blue red", name="Arrows_17.1770000458_1")

cluster_dict["17.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(31.5), float(26.0), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([16.0,31.5,26.0], [14.264,28.282,24.68], color="blue red", name="Arrows_17.1770000458_2")

cluster_dict["17.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(31.5), float(27.5), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([16.5,31.5,27.5], [18.584,34.583,29.301], color="blue red", name="Arrows_17.1770000458_3")

cluster_dict["17.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(18.0), float(28.0), float(40.0), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([18.0,28.0,40.0], [19.6,30.549,39.07], color="blue red", name="Arrows_17.1770000458_4")

cluster_dict["17.1770000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(33.0), float(34.0), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([19.5,33.0,34.0], [16.762,32.791,33.752], color="blue red", name="Arrows_17.1770000458_5")

cluster_dict["17.1770000458"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(13.5686560093), float(34.5240737596), float(40.5060185822), float(1.0)]


cluster_dict["17.1770000458"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(13.545177045), float(22.9346666888), float(38.0961426547), float(1.0)]


cluster_dict["17.1770000458"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(19.0796077114), float(29.8161042763), float(32.1359048255), float(1.0)]


cluster_dict["17.1770000458"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(20.4102658895), float(27.8250703292), float(24.1446848278), float(1.0)]


cluster_dict["17.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(11.5), float(22.5), float(38.5), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([11.5,22.5,38.5], [10.91,21.842,41.086], color="red blue", name="Arrows_17.1770000458_6")

cluster_dict["17.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(27.0), float(29.5), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([16.0,27.0,29.5], [12.214,25.278,28.555], color="red blue", name="Arrows_17.1770000458_7")

cluster_dict["17.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(27.5), float(30.0), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([18.5,27.5,30.0], [20.516,24.849,30.866], color="red blue", name="Arrows_17.1770000458_8")

cluster_dict["17.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(21.0), float(31.5), float(29.0), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([21.0,31.5,29.0], [20.757,32.781,26.406], color="red blue", name="Arrows_17.1770000458_9")

cluster_dict["17.1770000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.0), float(23.0), float(22.5), float(1.0)]

cluster_dict["17.1770000458_arrows"] += cgo_arrow([22.0,23.0,22.5], [20.807,22.261,23.987], color="red blue", name="Arrows_17.1770000458_10")

cmd.load_cgo(cluster_dict["17.1770000458"], "Features_17.1770000458", 1)
cmd.load_cgo(cluster_dict["17.1770000458_arrows"], "Arrows_17.1770000458")
cmd.set("transparency", 0.2,"Features_17.1770000458")
cmd.group("Pharmacophore_17.1770000458", members="Features_17.1770000458")
cmd.group("Pharmacophore_17.1770000458", members="Arrows_17.1770000458")

if dirpath:
    f = join(dirpath, "label_threshold_17.1770000458.mol2")
else:
    f = "label_threshold_17.1770000458.mol2"

cmd.load(f, 'label_threshold_17.1770000458')
cmd.hide('everything', 'label_threshold_17.1770000458')
cmd.label("label_threshold_17.1770000458", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.1770000458', members= 'label_threshold_17.1770000458')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
