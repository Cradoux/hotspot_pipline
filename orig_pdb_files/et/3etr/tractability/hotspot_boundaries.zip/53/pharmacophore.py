
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.2280006409":[], "16.2280006409_arrows":[]}

cluster_dict["16.2280006409"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(12.0), float(33.5), float(39.0), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([12.0,33.5,39.0], [11.415,33.832,35.865], color="blue red", name="Arrows_16.2280006409_1")

cluster_dict["16.2280006409"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(15.0), float(36.5), float(43.0), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([15.0,36.5,43.0], [16.087,33.906,43.704], color="blue red", name="Arrows_16.2280006409_2")

cluster_dict["16.2280006409"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(37.5), float(40.5), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([17.0,37.5,40.5], [16.019,37.942,37.737], color="blue red", name="Arrows_16.2280006409_3")

cluster_dict["16.2280006409"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(29.5), float(39.5), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([17.5,29.5,39.5], [19.6,30.549,39.07], color="blue red", name="Arrows_16.2280006409_4")

cluster_dict["16.2280006409"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.0), float(29.5), float(36.5), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([19.0,29.5,36.5], [19.6,30.549,39.07], color="blue red", name="Arrows_16.2280006409_5")

cluster_dict["16.2280006409"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(11.4237813717), float(35.2931543491), float(41.391286656), float(1.0)]


cluster_dict["16.2280006409"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(16.7028350381), float(29.8766050452), float(36.6731262164), float(1.0)]


cluster_dict["16.2280006409"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(7.5), float(32.0), float(44.5), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([7.5,32.0,44.5], [11.491,29.94,43.112], color="red blue", name="Arrows_16.2280006409_6")

cluster_dict["16.2280006409"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(8.5), float(38.5), float(39.5), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([8.5,38.5,39.5], [10.654,40.531,39.037], color="red blue", name="Arrows_16.2280006409_7")

cluster_dict["16.2280006409"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(12.0), float(30.5), float(39.0), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([12.0,30.5,39.0], [13.35,28.307,37.593], color="red blue", name="Arrows_16.2280006409_8")

cluster_dict["16.2280006409"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(14.5), float(31.0), float(40.0), float(1.0)]

cluster_dict["16.2280006409_arrows"] += cgo_arrow([14.5,31.0,40.0], [13.35,28.307,37.593], color="red blue", name="Arrows_16.2280006409_9")

cmd.load_cgo(cluster_dict["16.2280006409"], "Features_16.2280006409", 1)
cmd.load_cgo(cluster_dict["16.2280006409_arrows"], "Arrows_16.2280006409")
cmd.set("transparency", 0.2,"Features_16.2280006409")
cmd.group("Pharmacophore_16.2280006409", members="Features_16.2280006409")
cmd.group("Pharmacophore_16.2280006409", members="Arrows_16.2280006409")

if dirpath:
    f = join(dirpath, "label_threshold_16.2280006409.mol2")
else:
    f = "label_threshold_16.2280006409.mol2"

cmd.load(f, 'label_threshold_16.2280006409')
cmd.hide('everything', 'label_threshold_16.2280006409')
cmd.label("label_threshold_16.2280006409", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.2280006409', members= 'label_threshold_16.2280006409')
