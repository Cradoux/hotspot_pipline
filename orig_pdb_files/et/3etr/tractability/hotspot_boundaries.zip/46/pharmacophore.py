
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.4419994354":[], "16.4419994354_arrows":[]}

cluster_dict["16.4419994354"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(22.0), float(9.0), float(26.0), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([22.0,9.0,26.0], [20.263,11.401,25.376], color="blue red", name="Arrows_16.4419994354_1")

cluster_dict["16.4419994354"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(5.0), float(25.5), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([23.0,5.0,25.5], [21.848,2.901,23.953], color="blue red", name="Arrows_16.4419994354_2")

cluster_dict["16.4419994354"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(6.5), float(22.5), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([26.5,6.5,22.5], [24.383,5.1,20.493], color="blue red", name="Arrows_16.4419994354_3")

cluster_dict["16.4419994354"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(10.5), float(24.0), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([26.0,10.5,24.0], [24.828,13.48,24.46], color="blue red", name="Arrows_16.4419994354_4")

cluster_dict["16.4419994354"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(7.5), float(16.0), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([28.0,7.5,16.0], [25.678,8.126,17.598], color="blue red", name="Arrows_16.4419994354_5")

cluster_dict["16.4419994354"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(4.0), float(24.5), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([29.5,4.0,24.5], [31.281,4.479,26.704], color="blue red", name="Arrows_16.4419994354_6")

cluster_dict["16.4419994354"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(5.0), float(20.0), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([30.0,5.0,20.0], [31.989,4.998,17.834], color="blue red", name="Arrows_16.4419994354_7")

cluster_dict["16.4419994354"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(27.2585955207), float(7.54896635327), float(22.8028688937), float(1.0)]


cluster_dict["16.4419994354"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(1.5), float(25.5), float(1.0)]


cluster_dict["16.4419994354"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(35.3245614035), float(9.51169590643), float(17.7368421053), float(1.0)]


cluster_dict["16.4419994354"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(5.5), float(21.0), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([27.0,5.5,21.0], [24.383,5.1,20.493], color="red blue", name="Arrows_16.4419994354_8")

cluster_dict["16.4419994354"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(5.5), float(16.5), float(1.0)]

cluster_dict["16.4419994354_arrows"] += cgo_arrow([28.5,5.5,16.5], [30.035,4.383,14.053], color="red blue", name="Arrows_16.4419994354_9")

cmd.load_cgo(cluster_dict["16.4419994354"], "Features_16.4419994354", 1)
cmd.load_cgo(cluster_dict["16.4419994354_arrows"], "Arrows_16.4419994354")
cmd.set("transparency", 0.2,"Features_16.4419994354")
cmd.group("Pharmacophore_16.4419994354", members="Features_16.4419994354")
cmd.group("Pharmacophore_16.4419994354", members="Arrows_16.4419994354")

if dirpath:
    f = join(dirpath, "label_threshold_16.4419994354.mol2")
else:
    f = "label_threshold_16.4419994354.mol2"

cmd.load(f, 'label_threshold_16.4419994354')
cmd.hide('everything', 'label_threshold_16.4419994354')
cmd.label("label_threshold_16.4419994354", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.4419994354', members= 'label_threshold_16.4419994354')
