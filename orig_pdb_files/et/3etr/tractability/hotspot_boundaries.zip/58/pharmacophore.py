
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.0340003967":[], "16.0340003967_arrows":[]}

cluster_dict["16.0340003967"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(21.5), float(5.5), float(38.0), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([21.5,5.5,38.0], [22.648,5.212,35.929], color="blue red", name="Arrows_16.0340003967_1")

cluster_dict["16.0340003967"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.5), float(9.0), float(41.0), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([23.5,9.0,41.0], [24.082,12.057,42.288], color="blue red", name="Arrows_16.0340003967_2")

cluster_dict["16.0340003967"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.5), float(16.0), float(45.5), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([23.5,16.0,45.5], [25.971,15.865,43.79], color="blue red", name="Arrows_16.0340003967_3")

cluster_dict["16.0340003967"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(15.0), float(36.5), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([26.5,15.0,36.5], [28.472,16.776,37.727], color="blue red", name="Arrows_16.0340003967_4")

cluster_dict["16.0340003967"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.2206122954), float(5.46950127292), float(41.3765765547), float(1.0)]


cluster_dict["16.0340003967"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.7750251756), float(11.4969795874), float(34.0825699141), float(1.0)]


cluster_dict["16.0340003967"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(23.2748932444), float(16.1824154588), float(45.7678372386), float(1.0)]


cluster_dict["16.0340003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(19.0), float(-0.5), float(42.5), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([19.0,-0.5,42.5], [15.944,-0.291,41.945], color="red blue", name="Arrows_16.0340003967_5")

cluster_dict["16.0340003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(7.0), float(38.0), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([22.5,7.0,38.0], [22.648,5.212,35.929], color="red blue", name="Arrows_16.0340003967_6")

cluster_dict["16.0340003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(8.0), float(31.5), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([23.0,8.0,31.5], [24.327,5.898,29.592], color="red blue", name="Arrows_16.0340003967_7")

cluster_dict["16.0340003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(15.0), float(37.0), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([23.0,15.0,37.0], [20.949,16.359,38.69], color="red blue", name="Arrows_16.0340003967_8")

cluster_dict["16.0340003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.0), float(15.0), float(46.0), float(1.0)]

cluster_dict["16.0340003967_arrows"] += cgo_arrow([25.0,15.0,46.0], [25.971,15.865,43.79], color="red blue", name="Arrows_16.0340003967_9")

cmd.load_cgo(cluster_dict["16.0340003967"], "Features_16.0340003967", 1)
cmd.load_cgo(cluster_dict["16.0340003967_arrows"], "Arrows_16.0340003967")
cmd.set("transparency", 0.2,"Features_16.0340003967")
cmd.group("Pharmacophore_16.0340003967", members="Features_16.0340003967")
cmd.group("Pharmacophore_16.0340003967", members="Arrows_16.0340003967")

if dirpath:
    f = join(dirpath, "label_threshold_16.0340003967.mol2")
else:
    f = "label_threshold_16.0340003967.mol2"

cmd.load(f, 'label_threshold_16.0340003967')
cmd.hide('everything', 'label_threshold_16.0340003967')
cmd.label("label_threshold_16.0340003967", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.0340003967', members= 'label_threshold_16.0340003967')
