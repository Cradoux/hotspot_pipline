
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.6719999313":[], "14.6719999313_arrows":[]}

cluster_dict["14.6719999313"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-16.0), float(-3.0), float(54.0), float(1.0)]

cluster_dict["14.6719999313_arrows"] += cgo_arrow([-16.0,-3.0,54.0], [-17.363,-0.587,52.277], color="blue red", name="Arrows_14.6719999313_1")

cluster_dict["14.6719999313"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-16.0), float(-4.5), float(48.5), float(1.0)]

cluster_dict["14.6719999313_arrows"] += cgo_arrow([-16.0,-4.5,48.5], [-18.731,-2.721,49.33], color="blue red", name="Arrows_14.6719999313_2")

cluster_dict["14.6719999313"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-14.0), float(-4.0), float(46.5), float(1.0)]

cluster_dict["14.6719999313_arrows"] += cgo_arrow([-14.0,-4.0,46.5], [-13.027,-1.485,45.573], color="blue red", name="Arrows_14.6719999313_3")

cluster_dict["14.6719999313"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-12.0), float(-13.0), float(48.0), float(1.0)]

cluster_dict["14.6719999313_arrows"] += cgo_arrow([-12.0,-13.0,48.0], [-9.173,-12.246,47.746], color="blue red", name="Arrows_14.6719999313_4")

cluster_dict["14.6719999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-19.0710749899), float(-7.09927869789), float(45.0060518138), float(1.0)]


cluster_dict["14.6719999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-18.1608580596), float(-13.9680461792), float(56.3264427109), float(1.0)]


cluster_dict["14.6719999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-18.0925404926), float(-16.3691893375), float(45.9427934622), float(1.0)]


cluster_dict["14.6719999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-16.2796885207), float(-2.4488654791), float(56.9594561523), float(1.0)]


cluster_dict["14.6719999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-15.030006436), float(-0.833798249699), float(49.3738831333), float(1.0)]


cluster_dict["14.6719999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-12.6555050534), float(-15.0718888402), float(46.6962526756), float(1.0)]


cluster_dict["14.6719999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-21.0), float(-6.0), float(45.5), float(1.0)]

cluster_dict["14.6719999313_arrows"] += cgo_arrow([-21.0,-6.0,45.5], [-22.337,-3.396,48.966], color="red blue", name="Arrows_14.6719999313_5")

cluster_dict["14.6719999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-19.0), float(-4.0), float(56.5), float(1.0)]

cluster_dict["14.6719999313_arrows"] += cgo_arrow([-19.0,-4.0,56.5], [-21.532,-6.13,56.958], color="red blue", name="Arrows_14.6719999313_6")

cluster_dict["14.6719999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-18.0), float(-2.0), float(57.5), float(1.0)]


cluster_dict["14.6719999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-17.0), float(-3.5), float(55.5), float(1.0)]


cluster_dict["14.6719999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-11.0), float(-16.5), float(44.5), float(1.0)]

cluster_dict["14.6719999313_arrows"] += cgo_arrow([-11.0,-16.5,44.5], [-15.04,-16.828,41.999], color="red blue", name="Arrows_14.6719999313_7")

cmd.load_cgo(cluster_dict["14.6719999313"], "Features_14.6719999313", 1)
cmd.load_cgo(cluster_dict["14.6719999313_arrows"], "Arrows_14.6719999313")
cmd.set("transparency", 0.2,"Features_14.6719999313")
cmd.group("Pharmacophore_14.6719999313", members="Features_14.6719999313")
cmd.group("Pharmacophore_14.6719999313", members="Arrows_14.6719999313")

if dirpath:
    f = join(dirpath, "label_threshold_14.6719999313.mol2")
else:
    f = "label_threshold_14.6719999313.mol2"

cmd.load(f, 'label_threshold_14.6719999313')
cmd.hide('everything', 'label_threshold_14.6719999313')
cmd.label("label_threshold_14.6719999313", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.6719999313', members= 'label_threshold_14.6719999313')
