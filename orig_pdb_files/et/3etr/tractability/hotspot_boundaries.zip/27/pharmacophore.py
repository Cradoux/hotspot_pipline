
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.4335002899":[], "17.4335002899_arrows":[]}

cluster_dict["17.4335002899"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-55.0), float(-3.5), float(49.0), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-55.0,-3.5,49.0], [-56.059,-0.837,49.615], color="blue red", name="Arrows_17.4335002899_1")

cluster_dict["17.4335002899"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-48.0), float(-4.0), float(48.5), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-48.0,-4.0,48.5], [-48.278,-5.299,45.404], color="blue red", name="Arrows_17.4335002899_2")

cluster_dict["17.4335002899"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-47.0), float(8.0), float(59.5), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-47.0,8.0,59.5], [-49.244,7.68,61.514], color="blue red", name="Arrows_17.4335002899_3")

cluster_dict["17.4335002899"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-46.0), float(9.0), float(48.0), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-46.0,9.0,48.0], [-47.285,10.878,46.617], color="blue red", name="Arrows_17.4335002899_4")

cluster_dict["17.4335002899"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-46.0), float(9.5), float(45.0), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-46.0,9.5,45.0], [-47.285,10.878,46.617], color="blue red", name="Arrows_17.4335002899_5")

cluster_dict["17.4335002899"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-46.5), float(11.5), float(53.5), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-46.5,11.5,53.5], [-45.246,12.959,55.728], color="blue red", name="Arrows_17.4335002899_6")

cluster_dict["17.4335002899"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-51.0146379384), float(-4.8305837183), float(51.3245883589), float(1.0)]


cluster_dict["17.4335002899"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-44.8882262892), float(10.9565859382), float(50.5267943719), float(1.0)]


cluster_dict["17.4335002899"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-42.1093900997), float(12.8874540851), float(61.5179952277), float(1.0)]


cluster_dict["17.4335002899"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-45.5), float(8.5), float(49.5), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-45.5,8.5,49.5], [-46.33,6.271,48.222], color="red blue", name="Arrows_17.4335002899_7")

cluster_dict["17.4335002899"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-44.0), float(15.0), float(59.5), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-44.0,15.0,59.5], [-45.765,13.142,60.591], color="red blue", name="Arrows_17.4335002899_8")

cluster_dict["17.4335002899"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-40.0), float(11.5), float(61.5), float(1.0)]

cluster_dict["17.4335002899_arrows"] += cgo_arrow([-40.0,11.5,61.5], [-37.759,9.32,60.96], color="red blue", name="Arrows_17.4335002899_9")

cmd.load_cgo(cluster_dict["17.4335002899"], "Features_17.4335002899", 1)
cmd.load_cgo(cluster_dict["17.4335002899_arrows"], "Arrows_17.4335002899")
cmd.set("transparency", 0.2,"Features_17.4335002899")
cmd.group("Pharmacophore_17.4335002899", members="Features_17.4335002899")
cmd.group("Pharmacophore_17.4335002899", members="Arrows_17.4335002899")

if dirpath:
    f = join(dirpath, "label_threshold_17.4335002899.mol2")
else:
    f = "label_threshold_17.4335002899.mol2"

cmd.load(f, 'label_threshold_17.4335002899')
cmd.hide('everything', 'label_threshold_17.4335002899')
cmd.label("label_threshold_17.4335002899", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.4335002899', members= 'label_threshold_17.4335002899')
