
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_14.9.mol2")
else:
    f = "label_threshold_14.9.mol2"

cmd.load(f, 'label_threshold_14.9')
cmd.hide('everything', 'label_threshold_14.9')
cmd.label("label_threshold_14.9", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [14.9]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"16.3659992218":[], "16.3659992218_arrows":[]}

cluster_dict["16.3659992218"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-40.5), float(-3.0), float(69.5), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-40.5,-3.0,69.5], [-41.252,-0.556,70.849], color="blue red", name="Arrows_16.3659992218_1")

cluster_dict["16.3659992218"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-39.5), float(-2.0), float(71.5), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-39.5,-2.0,71.5], [-41.252,-0.556,70.849], color="blue red", name="Arrows_16.3659992218_2")

cluster_dict["16.3659992218"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-37.0), float(0.0), float(68.0), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-37.0,0.0,68.0], [-38.407,0.945,65.456], color="blue red", name="Arrows_16.3659992218_3")

cluster_dict["16.3659992218"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-37.0), float(-6.5), float(69.0), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-37.0,-6.5,69.0], [-35.002,-6.704,67.036], color="blue red", name="Arrows_16.3659992218_4")

cluster_dict["16.3659992218"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-37.0), float(-2.5), float(73.5), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-37.0,-2.5,73.5], [-35.226,-0.918,75.907], color="blue red", name="Arrows_16.3659992218_5")

cluster_dict["16.3659992218"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-39.9769157481), float(-4.83180071927), float(70.6990508832), float(1.0)]


cluster_dict["16.3659992218"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-44.5), float(-3.5), float(76.0), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-44.5,-3.5,76.0], [-46.114,-1.645,74.864], color="red blue", name="Arrows_16.3659992218_6")

cluster_dict["16.3659992218"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-40.5), float(-3.0), float(71.5), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-40.5,-3.0,71.5], [-41.252,-0.556,70.849], color="red blue", name="Arrows_16.3659992218_7")

cluster_dict["16.3659992218"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-38.5), float(-6.5), float(74.0), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-38.5,-6.5,74.0], [-36.711,-4.673,75.752], color="red blue", name="Arrows_16.3659992218_8")

cluster_dict["16.3659992218"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-38.0), float(-5.5), float(63.0), float(1.0)]

cluster_dict["16.3659992218_arrows"] += cgo_arrow([-38.0,-5.5,63.0], [-35.514,-4.848,62.445], color="red blue", name="Arrows_16.3659992218_9")

cmd.load_cgo(cluster_dict["16.3659992218"], "Features_16.3659992218", 1)
cmd.load_cgo(cluster_dict["16.3659992218_arrows"], "Arrows_16.3659992218")
cmd.set("transparency", 0.2,"Features_16.3659992218")
cmd.group("Pharmacophore_16.3659992218", members="Features_16.3659992218")
cmd.group("Pharmacophore_16.3659992218", members="Arrows_16.3659992218")

if dirpath:
    f = join(dirpath, "label_threshold_16.3659992218.mol2")
else:
    f = "label_threshold_16.3659992218.mol2"

cmd.load(f, 'label_threshold_16.3659992218')
cmd.hide('everything', 'label_threshold_16.3659992218')
cmd.label("label_threshold_16.3659992218", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.3659992218', members= 'label_threshold_16.3659992218')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
