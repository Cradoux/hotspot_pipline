
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.7740001678":[], "13.7740001678_arrows":[]}

cluster_dict["13.7740001678"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-17.5), float(-10.5), float(28.0), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-17.5,-10.5,28.0], [-19.572,-9.949,26.024], color="blue red", name="Arrows_13.7740001678_1")

cluster_dict["13.7740001678"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-16.5), float(-11.5), float(32.0), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-16.5,-11.5,32.0], [-18.259,-9.567,30.976], color="blue red", name="Arrows_13.7740001678_2")

cluster_dict["13.7740001678"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(-6.0), float(23.0), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-13.5,-6.0,23.0], [-15.302,-8.206,23.93], color="blue red", name="Arrows_13.7740001678_3")

cluster_dict["13.7740001678"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-14.0), float(-2.0), float(25.0), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-14.0,-2.0,25.0], [-14.141,-2.336,27.942], color="blue red", name="Arrows_13.7740001678_4")

cluster_dict["13.7740001678"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-8.5), float(2.0), float(19.5), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-8.5,2.0,19.5], [-10.06,1.446,18.913], color="blue red", name="Arrows_13.7740001678_5")

cluster_dict["13.7740001678"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-16.6001710987), float(-12.5644473837), float(29.0537832513), float(1.0)]


cluster_dict["13.7740001678"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-14.3716340986), float(-3.36595784527), float(22.2961981316), float(1.0)]


cluster_dict["13.7740001678"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-14.876422277), float(7.93809100776), float(23.0695410219), float(1.0)]


cluster_dict["13.7740001678"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-9.26183906667), float(3.39759338228), float(29.2837605687), float(1.0)]


cluster_dict["13.7740001678"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-5.85602411237), float(0.0967710881865), float(18.878155802), float(1.0)]


cluster_dict["13.7740001678"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-5.4564138048), float(-2.39918215313), float(28.2879158581), float(1.0)]


cluster_dict["13.7740001678"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-16.5), float(-10.0), float(27.0), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-16.5,-10.0,27.0], [-19.572,-9.949,26.024], color="red blue", name="Arrows_13.7740001678_6")

cluster_dict["13.7740001678"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-16.0), float(8.5), float(22.5), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-16.0,8.5,22.5], [-12.952,6.981,19.841], color="red blue", name="Arrows_13.7740001678_7")

cluster_dict["13.7740001678"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-10.5), float(-2.0), float(27.5), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-10.5,-2.0,27.5], [-12.063,-0.184,28.703], color="red blue", name="Arrows_13.7740001678_8")

cluster_dict["13.7740001678"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.5), float(1.5), float(30.0), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-9.5,1.5,30.0], [-12.063,-0.184,28.703], color="red blue", name="Arrows_13.7740001678_9")

cluster_dict["13.7740001678"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-8.0), float(-2.5), float(28.0), float(1.0)]

cluster_dict["13.7740001678_arrows"] += cgo_arrow([-8.0,-2.5,28.0], [-9.153,-5.211,25.883], color="red blue", name="Arrows_13.7740001678_10")

cmd.load_cgo(cluster_dict["13.7740001678"], "Features_13.7740001678", 1)
cmd.load_cgo(cluster_dict["13.7740001678_arrows"], "Arrows_13.7740001678")
cmd.set("transparency", 0.2,"Features_13.7740001678")
cmd.group("Pharmacophore_13.7740001678", members="Features_13.7740001678")
cmd.group("Pharmacophore_13.7740001678", members="Arrows_13.7740001678")

if dirpath:
    f = join(dirpath, "label_threshold_13.7740001678.mol2")
else:
    f = "label_threshold_13.7740001678.mol2"

cmd.load(f, 'label_threshold_13.7740001678')
cmd.hide('everything', 'label_threshold_13.7740001678')
cmd.label("label_threshold_13.7740001678", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.7740001678', members= 'label_threshold_13.7740001678')
