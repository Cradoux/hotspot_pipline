
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.0659999847":[], "17.0659999847_arrows":[]}

cluster_dict["17.0659999847"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-37.0), float(0.0), float(68.0), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-37.0,0.0,68.0], [-38.407,0.945,65.456], color="blue red", name="Arrows_17.0659999847_1")

cluster_dict["17.0659999847"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-37.0), float(-2.5), float(73.5), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-37.0,-2.5,73.5], [-35.226,-0.918,75.907], color="blue red", name="Arrows_17.0659999847_2")

cluster_dict["17.0659999847"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-41.1913122579), float(-9.44466663169), float(67.9655497924), float(1.0)]


cluster_dict["17.0659999847"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-43.9557996207), float(7.29268507496), float(78.6890920318), float(1.0)]


cluster_dict["17.0659999847"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-39.2510902394), float(-1.98905385467), float(72.5806423876), float(1.0)]


cluster_dict["17.0659999847"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-33.798312702), float(4.05451260087), float(74.9820527454), float(1.0)]


cluster_dict["17.0659999847"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-40.5), float(-3.0), float(71.5), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-40.5,-3.0,71.5], [-41.252,-0.556,70.849], color="red blue", name="Arrows_17.0659999847_3")

cluster_dict["17.0659999847"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-38.5), float(-6.5), float(74.0), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-38.5,-6.5,74.0], [-36.711,-4.673,75.752], color="red blue", name="Arrows_17.0659999847_4")

cluster_dict["17.0659999847"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-38.0), float(-5.5), float(63.0), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-38.0,-5.5,63.0], [-35.514,-4.848,62.445], color="red blue", name="Arrows_17.0659999847_5")

cluster_dict["17.0659999847"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-35.5), float(4.0), float(70.5), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-35.5,4.0,70.5], [-33.782,2.549,68.962], color="red blue", name="Arrows_17.0659999847_6")

cluster_dict["17.0659999847"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-35.0), float(4.5), float(67.0), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-35.0,4.5,67.0], [-33.782,2.549,68.962], color="red blue", name="Arrows_17.0659999847_7")

cluster_dict["17.0659999847"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-36.0), float(5.5), float(65.0), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-36.0,5.5,65.0], [-37.903,8.797,63.64], color="red blue", name="Arrows_17.0659999847_8")

cluster_dict["17.0659999847"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-32.5), float(6.0), float(70.5), float(1.0)]

cluster_dict["17.0659999847_arrows"] += cgo_arrow([-32.5,6.0,70.5], [-33.782,2.549,68.962], color="red blue", name="Arrows_17.0659999847_9")

cmd.load_cgo(cluster_dict["17.0659999847"], "Features_17.0659999847", 1)
cmd.load_cgo(cluster_dict["17.0659999847_arrows"], "Arrows_17.0659999847")
cmd.set("transparency", 0.2,"Features_17.0659999847")
cmd.group("Pharmacophore_17.0659999847", members="Features_17.0659999847")
cmd.group("Pharmacophore_17.0659999847", members="Arrows_17.0659999847")

if dirpath:
    f = join(dirpath, "label_threshold_17.0659999847.mol2")
else:
    f = "label_threshold_17.0659999847.mol2"

cmd.load(f, 'label_threshold_17.0659999847')
cmd.hide('everything', 'label_threshold_17.0659999847')
cmd.label("label_threshold_17.0659999847", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.0659999847', members= 'label_threshold_17.0659999847')
