
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_15.0.mol2")
else:
    f = "label_threshold_15.0.mol2"

cmd.load(f, 'label_threshold_15.0')
cmd.hide('everything', 'label_threshold_15.0')
cmd.label("label_threshold_15.0", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [15.0]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"16.6275005341":[], "16.6275005341_arrows":[]}

cluster_dict["16.6275005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-56.0), float(-8.5), float(49.0), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-56.0,-8.5,49.0], [-58.938,-9.438,49.082], color="blue red", name="Arrows_16.6275005341_1")

cluster_dict["16.6275005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-55.0), float(-3.5), float(49.0), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-55.0,-3.5,49.0], [-56.059,-0.837,49.615], color="blue red", name="Arrows_16.6275005341_2")

cluster_dict["16.6275005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-52.5), float(-6.5), float(48.0), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-52.5,-6.5,48.0], [-50.9,-8.682,47.613], color="blue red", name="Arrows_16.6275005341_3")

cluster_dict["16.6275005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-48.0), float(-4.0), float(48.5), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-48.0,-4.0,48.5], [-48.278,-5.299,45.404], color="blue red", name="Arrows_16.6275005341_4")

cluster_dict["16.6275005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-46.0), float(9.0), float(48.0), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-46.0,9.0,48.0], [-47.285,10.878,46.617], color="blue red", name="Arrows_16.6275005341_5")

cluster_dict["16.6275005341"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-46.0), float(9.5), float(45.0), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-46.0,9.5,45.0], [-47.285,10.878,46.617], color="blue red", name="Arrows_16.6275005341_6")

cluster_dict["16.6275005341"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-52.514160347), float(-3.74128449495), float(49.3404289655), float(1.0)]


cluster_dict["16.6275005341"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-46.6156435545), float(2.11819235224), float(52.969012571), float(1.0)]


cluster_dict["16.6275005341"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-45.7319106788), float(8.6161192276), float(49.5247088625), float(1.0)]


cluster_dict["16.6275005341"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-44.3021726387), float(7.5), float(48.4173811099), float(1.0)]


cluster_dict["16.6275005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-56.5), float(-4.5), float(50.5), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-56.5,-4.5,50.5], [-59.288,-5.348,50.967], color="red blue", name="Arrows_16.6275005341_7")

cluster_dict["16.6275005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-53.0), float(-7.5), float(49.0), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-53.0,-7.5,49.0], [-50.9,-8.682,47.613], color="red blue", name="Arrows_16.6275005341_8")

cluster_dict["16.6275005341"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-46.0), float(8.0), float(49.0), float(1.0)]

cluster_dict["16.6275005341_arrows"] += cgo_arrow([-46.0,8.0,49.0], [-46.33,6.271,48.222], color="red blue", name="Arrows_16.6275005341_9")

cmd.load_cgo(cluster_dict["16.6275005341"], "Features_16.6275005341", 1)
cmd.load_cgo(cluster_dict["16.6275005341_arrows"], "Arrows_16.6275005341")
cmd.set("transparency", 0.2,"Features_16.6275005341")
cmd.group("Pharmacophore_16.6275005341", members="Features_16.6275005341")
cmd.group("Pharmacophore_16.6275005341", members="Arrows_16.6275005341")

if dirpath:
    f = join(dirpath, "label_threshold_16.6275005341.mol2")
else:
    f = "label_threshold_16.6275005341.mol2"

cmd.load(f, 'label_threshold_16.6275005341')
cmd.hide('everything', 'label_threshold_16.6275005341')
cmd.label("label_threshold_16.6275005341", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.6275005341', members= 'label_threshold_16.6275005341')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
