
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.2999992371":[], "17.2999992371_arrows":[]}

cluster_dict["17.2999992371"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(12.0), float(33.5), float(39.0), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([12.0,33.5,39.0], [11.415,33.832,35.865], color="blue red", name="Arrows_17.2999992371_1")

cluster_dict["17.2999992371"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(31.5), float(27.5), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([16.5,31.5,27.5], [18.584,34.583,29.301], color="blue red", name="Arrows_17.2999992371_2")

cluster_dict["17.2999992371"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(31.5), float(26.0), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([16.0,31.5,26.0], [14.264,28.282,24.68], color="blue red", name="Arrows_17.2999992371_3")

cluster_dict["17.2999992371"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(31.5), float(27.5), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([16.5,31.5,27.5], [18.584,34.583,29.301], color="blue red", name="Arrows_17.2999992371_4")

cluster_dict["17.2999992371"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(18.0), float(28.0), float(40.0), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([18.0,28.0,40.0], [19.6,30.549,39.07], color="blue red", name="Arrows_17.2999992371_5")

cluster_dict["17.2999992371"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(37.5), float(40.5), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([17.0,37.5,40.5], [16.019,37.942,37.737], color="blue red", name="Arrows_17.2999992371_6")

cluster_dict["17.2999992371"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(33.0), float(34.0), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([19.5,33.0,34.0], [16.762,32.791,33.752], color="blue red", name="Arrows_17.2999992371_7")

cluster_dict["17.2999992371"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(13.9507069323), float(35.4969849971), float(40.8339925715), float(1.0)]


cluster_dict["17.2999992371"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(14.023030533), float(23.6688922864), float(37.9297947025), float(1.0)]


cluster_dict["17.2999992371"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(19.0600451992), float(29.7991617379), float(32.1416507133), float(1.0)]


cluster_dict["17.2999992371"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(21.0938360018), float(28.1228606777), float(24.2721536102), float(1.0)]


cluster_dict["17.2999992371"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.842647015), float(35.4332821446), float(41.3000581966), float(1.0)]


cluster_dict["17.2999992371"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(27.0), float(29.5), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([16.0,27.0,29.5], [12.214,25.278,28.555], color="red blue", name="Arrows_17.2999992371_8")

cluster_dict["17.2999992371"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(27.5), float(30.0), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([18.5,27.5,30.0], [20.516,24.849,30.866], color="red blue", name="Arrows_17.2999992371_9")

cluster_dict["17.2999992371"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(21.0), float(31.5), float(29.0), float(1.0)]

cluster_dict["17.2999992371_arrows"] += cgo_arrow([21.0,31.5,29.0], [20.757,32.781,26.406], color="red blue", name="Arrows_17.2999992371_10")

cmd.load_cgo(cluster_dict["17.2999992371"], "Features_17.2999992371", 1)
cmd.load_cgo(cluster_dict["17.2999992371_arrows"], "Arrows_17.2999992371")
cmd.set("transparency", 0.2,"Features_17.2999992371")
cmd.group("Pharmacophore_17.2999992371", members="Features_17.2999992371")
cmd.group("Pharmacophore_17.2999992371", members="Arrows_17.2999992371")

if dirpath:
    f = join(dirpath, "label_threshold_17.2999992371.mol2")
else:
    f = "label_threshold_17.2999992371.mol2"

cmd.load(f, 'label_threshold_17.2999992371')
cmd.hide('everything', 'label_threshold_17.2999992371')
cmd.label("label_threshold_17.2999992371", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.2999992371', members= 'label_threshold_17.2999992371')
