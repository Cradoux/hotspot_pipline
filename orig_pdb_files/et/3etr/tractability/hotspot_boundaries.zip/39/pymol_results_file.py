
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_15.7.mol2")
else:
    f = "label_threshold_15.7.mol2"

cmd.load(f, 'label_threshold_15.7')
cmd.hide('everything', 'label_threshold_15.7')
cmd.label("label_threshold_15.7", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [15.7]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"16.7269992828":[], "16.7269992828_arrows":[]}

cluster_dict["16.7269992828"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(7.5), float(36.5), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([20.5,7.5,36.5], [19.802,5.432,35.84], color="blue red", name="Arrows_16.7269992828_1")

cluster_dict["16.7269992828"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(21.0), float(8.5), float(26.5), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([21.0,8.5,26.5], [20.263,11.401,25.376], color="blue red", name="Arrows_16.7269992828_2")

cluster_dict["16.7269992828"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.5), float(9.0), float(41.0), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([23.5,9.0,41.0], [24.082,12.057,42.288], color="blue red", name="Arrows_16.7269992828_3")

cluster_dict["16.7269992828"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(6.5), float(22.5), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([26.5,6.5,22.5], [24.383,5.1,20.493], color="blue red", name="Arrows_16.7269992828_4")

cluster_dict["16.7269992828"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(10.5), float(24.0), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([26.0,10.5,24.0], [24.828,13.48,24.46], color="blue red", name="Arrows_16.7269992828_5")

cluster_dict["16.7269992828"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.0), float(4.0), float(24.5), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([29.0,4.0,24.5], [31.281,4.479,26.704], color="blue red", name="Arrows_16.7269992828_6")

cluster_dict["16.7269992828"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.1160899266), float(5.98590208424), float(40.761845009), float(1.0)]


cluster_dict["16.7269992828"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.1291690455), float(7.97590920165), float(24.0448020184), float(1.0)]


cluster_dict["16.7269992828"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(7.0), float(38.0), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([22.5,7.0,38.0], [22.648,5.212,35.929], color="red blue", name="Arrows_16.7269992828_7")

cluster_dict["16.7269992828"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(8.0), float(31.5), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([23.0,8.0,31.5], [24.327,5.898,29.592], color="red blue", name="Arrows_16.7269992828_8")

cluster_dict["16.7269992828"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(5.5), float(21.5), float(1.0)]

cluster_dict["16.7269992828_arrows"] += cgo_arrow([26.5,5.5,21.5], [24.383,5.1,20.493], color="red blue", name="Arrows_16.7269992828_9")

cmd.load_cgo(cluster_dict["16.7269992828"], "Features_16.7269992828", 1)
cmd.load_cgo(cluster_dict["16.7269992828_arrows"], "Arrows_16.7269992828")
cmd.set("transparency", 0.2,"Features_16.7269992828")
cmd.group("Pharmacophore_16.7269992828", members="Features_16.7269992828")
cmd.group("Pharmacophore_16.7269992828", members="Arrows_16.7269992828")

if dirpath:
    f = join(dirpath, "label_threshold_16.7269992828.mol2")
else:
    f = "label_threshold_16.7269992828.mol2"

cmd.load(f, 'label_threshold_16.7269992828')
cmd.hide('everything', 'label_threshold_16.7269992828')
cmd.label("label_threshold_16.7269992828", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.7269992828', members= 'label_threshold_16.7269992828')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
