
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.9499998093":[], "15.9499998093_arrows":[]}

cluster_dict["15.9499998093"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(21.0), float(8.0), float(26.5), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([21.0,8.0,26.5], [20.263,11.401,25.376], color="blue red", name="Arrows_15.9499998093_1")

cluster_dict["15.9499998093"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(5.0), float(26.0), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([23.0,5.0,26.0], [21.848,2.901,23.953], color="blue red", name="Arrows_15.9499998093_2")

cluster_dict["15.9499998093"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(21.5), float(5.5), float(38.0), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([21.5,5.5,38.0], [22.648,5.212,35.929], color="blue red", name="Arrows_15.9499998093_3")

cluster_dict["15.9499998093"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(6.5), float(22.5), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([26.5,6.5,22.5], [24.383,5.1,20.493], color="blue red", name="Arrows_15.9499998093_4")

cluster_dict["15.9499998093"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(4.0), float(24.5), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([29.5,4.0,24.5], [31.281,4.479,26.704], color="blue red", name="Arrows_15.9499998093_5")

cluster_dict["15.9499998093"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(4.5), float(20.0), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([30.0,4.5,20.0], [31.989,4.998,17.834], color="blue red", name="Arrows_15.9499998093_6")

cluster_dict["15.9499998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.2254589387), float(3.39278000187), float(39.8753166486), float(1.0)]


cluster_dict["15.9499998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(27.3062343537), float(6.40181565209), float(24.9081882365), float(1.0)]


cluster_dict["15.9499998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.4986250672), float(9.14089035022), float(31.5037872321), float(1.0)]


cluster_dict["15.9499998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(21.5094222256), float(6.92887273134), float(36.8676098123), float(1.0)]


cluster_dict["15.9499998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(1.5), float(25.5), float(1.0)]


cluster_dict["15.9499998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(6.5), float(37.5), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([22.5,6.5,37.5], [22.648,5.212,35.929], color="red blue", name="Arrows_15.9499998093_7")

cluster_dict["15.9499998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(8.0), float(31.5), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([23.0,8.0,31.5], [24.327,5.898,29.592], color="red blue", name="Arrows_15.9499998093_8")

cluster_dict["15.9499998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(5.5), float(21.0), float(1.0)]

cluster_dict["15.9499998093_arrows"] += cgo_arrow([27.0,5.5,21.0], [24.383,5.1,20.493], color="red blue", name="Arrows_15.9499998093_9")

cmd.load_cgo(cluster_dict["15.9499998093"], "Features_15.9499998093", 1)
cmd.load_cgo(cluster_dict["15.9499998093_arrows"], "Arrows_15.9499998093")
cmd.set("transparency", 0.2,"Features_15.9499998093")
cmd.group("Pharmacophore_15.9499998093", members="Features_15.9499998093")
cmd.group("Pharmacophore_15.9499998093", members="Arrows_15.9499998093")

if dirpath:
    f = join(dirpath, "label_threshold_15.9499998093.mol2")
else:
    f = "label_threshold_15.9499998093.mol2"

cmd.load(f, 'label_threshold_15.9499998093')
cmd.hide('everything', 'label_threshold_15.9499998093')
cmd.label("label_threshold_15.9499998093", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.9499998093', members= 'label_threshold_15.9499998093')
