
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_13.0.mol2")
else:
    f = "label_threshold_13.0.mol2"

cmd.load(f, 'label_threshold_13.0')
cmd.hide('everything', 'label_threshold_13.0')
cmd.label("label_threshold_13.0", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [13.0]
gfiles = ['apolar.grd']
grids = ['apolar']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"16.0054998398":[], "16.0054998398_arrows":[]}

cluster_dict["16.0054998398"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(56.5), float(27.5), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([24.0,56.5,27.5], [22.078,55.253,29.415], color="blue red", name="Arrows_16.0054998398_1")

cluster_dict["16.0054998398"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(59.0), float(24.5), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([27.0,59.0,24.5], [27.568,55.302,26.456], color="blue red", name="Arrows_16.0054998398_2")

cluster_dict["16.0054998398"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(37.5), float(61.5), float(26.0), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([37.5,61.5,26.0], [38.29,60.093,28.64], color="blue red", name="Arrows_16.0054998398_3")

cluster_dict["16.0054998398"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(38.0), float(61.5), float(22.0), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([38.0,61.5,22.0], [38.852,61.496,19.583], color="blue red", name="Arrows_16.0054998398_4")

cluster_dict["16.0054998398"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(39.0), float(60.0), float(25.0), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([39.0,60.0,25.0], [41.272,61.002,23.719], color="blue red", name="Arrows_16.0054998398_5")

cluster_dict["16.0054998398"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(33.184386423), float(60.7622870601), float(23.8376706288), float(1.0)]


cluster_dict["16.0054998398"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(57.0), float(26.5), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([26.5,57.0,26.5], [27.568,55.302,26.456], color="red blue", name="Arrows_16.0054998398_6")

cluster_dict["16.0054998398"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(60.5), float(26.0), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([26.5,60.5,26.0], [27.083,58.305,28.603], color="red blue", name="Arrows_16.0054998398_7")

cluster_dict["16.0054998398"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(33.5), float(61.0), float(23.5), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([33.5,61.0,23.5], [30.398,63.43,24.707], color="red blue", name="Arrows_16.0054998398_8")

cluster_dict["16.0054998398"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(37.0), float(63.5), float(21.5), float(1.0)]

cluster_dict["16.0054998398_arrows"] += cgo_arrow([37.0,63.5,21.5], [40.365,62.817,18.513], color="red blue", name="Arrows_16.0054998398_9")

cmd.load_cgo(cluster_dict["16.0054998398"], "Features_16.0054998398", 1)
cmd.load_cgo(cluster_dict["16.0054998398_arrows"], "Arrows_16.0054998398")
cmd.set("transparency", 0.2,"Features_16.0054998398")
cmd.group("Pharmacophore_16.0054998398", members="Features_16.0054998398")
cmd.group("Pharmacophore_16.0054998398", members="Arrows_16.0054998398")

if dirpath:
    f = join(dirpath, "label_threshold_16.0054998398.mol2")
else:
    f = "label_threshold_16.0054998398.mol2"

cmd.load(f, 'label_threshold_16.0054998398')
cmd.hide('everything', 'label_threshold_16.0054998398')
cmd.label("label_threshold_16.0054998398", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.0054998398', members= 'label_threshold_16.0054998398')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
