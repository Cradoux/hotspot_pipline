
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.6309995651":[], "14.6309995651_arrows":[]}

cluster_dict["14.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(-43.5), float(4.0), float(1.0)]

cluster_dict["14.6309995651_arrows"] += cgo_arrow([29.5,-43.5,4.0], [29.393,-40.692,4.576], color="blue red", name="Arrows_14.6309995651_1")

cluster_dict["14.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(-35.5), float(-1.0), float(1.0)]

cluster_dict["14.6309995651_arrows"] += cgo_arrow([35.5,-35.5,-1.0], [33.351,-35.839,-4.065], color="blue red", name="Arrows_14.6309995651_2")

cluster_dict["14.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(-35.5), float(-1.0), float(1.0)]

cluster_dict["14.6309995651_arrows"] += cgo_arrow([35.5,-35.5,-1.0], [33.351,-35.839,-4.065], color="blue red", name="Arrows_14.6309995651_3")

cluster_dict["14.6309995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(31.4075174442), float(-43.3475890629), float(3.68558489096), float(1.0)]


cluster_dict["14.6309995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(37.7627149749), float(-27.5349111774), float(-1.1222617153), float(1.0)]


cluster_dict["14.6309995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(36.0171850212), float(-37.7495738776), float(-0.959856382421), float(1.0)]


cluster_dict["14.6309995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(-37.5), float(-5.5), float(1.0)]


cluster_dict["14.6309995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(-28.5), float(-4.5), float(1.0)]

cluster_dict["14.6309995651_arrows"] += cgo_arrow([36.5,-28.5,-4.5], [37.132,-30.946,-6.482], color="red blue", name="Arrows_14.6309995651_4")

cluster_dict["14.6309995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(40.5), float(-27.5), float(2.0), float(1.0)]

cluster_dict["14.6309995651_arrows"] += cgo_arrow([40.5,-27.5,2.0], [43.271,-28.102,3.157], color="red blue", name="Arrows_14.6309995651_5")

cmd.load_cgo(cluster_dict["14.6309995651"], "Features_14.6309995651", 1)
cmd.load_cgo(cluster_dict["14.6309995651_arrows"], "Arrows_14.6309995651")
cmd.set("transparency", 0.2,"Features_14.6309995651")
cmd.group("Pharmacophore_14.6309995651", members="Features_14.6309995651")
cmd.group("Pharmacophore_14.6309995651", members="Arrows_14.6309995651")

if dirpath:
    f = join(dirpath, "label_threshold_14.6309995651.mol2")
else:
    f = "label_threshold_14.6309995651.mol2"

cmd.load(f, 'label_threshold_14.6309995651')
cmd.hide('everything', 'label_threshold_14.6309995651')
cmd.label("label_threshold_14.6309995651", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.6309995651', members= 'label_threshold_14.6309995651')
