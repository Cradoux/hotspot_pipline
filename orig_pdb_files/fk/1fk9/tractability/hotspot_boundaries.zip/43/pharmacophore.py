
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"9.98200035095":[], "9.98200035095_arrows":[]}

cluster_dict["9.98200035095"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(-9.5), float(14.0), float(1.0)]

cluster_dict["9.98200035095_arrows"] += cgo_arrow([26.5,-9.5,14.0], [28.783,-7.532,13.582], color="blue red", name="Arrows_9.98200035095_1")

cluster_dict["9.98200035095"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(18.193311252), float(-16.1239391994), float(16.2652059336), float(1.0)]


cluster_dict["9.98200035095"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.56770901), float(-12.0466505801), float(10.3365330733), float(1.0)]


cluster_dict["9.98200035095"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.0), float(-13.0), float(15.0), float(1.0)]

cluster_dict["9.98200035095_arrows"] += cgo_arrow([18.0,-13.0,15.0], [16.48,-10.765,14.656], color="red blue", name="Arrows_9.98200035095_2")

cluster_dict["9.98200035095"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.0), float(-9.0), float(7.0), float(1.0)]

cluster_dict["9.98200035095_arrows"] += cgo_arrow([22.0,-9.0,7.0], [22.101,-6.363,4.763], color="red blue", name="Arrows_9.98200035095_3")

cmd.load_cgo(cluster_dict["9.98200035095"], "Features_9.98200035095", 1)
cmd.load_cgo(cluster_dict["9.98200035095_arrows"], "Arrows_9.98200035095")
cmd.set("transparency", 0.2,"Features_9.98200035095")
cmd.group("Pharmacophore_9.98200035095", members="Features_9.98200035095")
cmd.group("Pharmacophore_9.98200035095", members="Arrows_9.98200035095")

if dirpath:
    f = join(dirpath, "label_threshold_9.98200035095.mol2")
else:
    f = "label_threshold_9.98200035095.mol2"

cmd.load(f, 'label_threshold_9.98200035095')
cmd.hide('everything', 'label_threshold_9.98200035095')
cmd.label("label_threshold_9.98200035095", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_9.98200035095', members= 'label_threshold_9.98200035095')
