
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_8.2.mol2")
else:
    f = "label_threshold_8.2.mol2"

cmd.load(f, 'label_threshold_8.2')
cmd.hide('everything', 'label_threshold_8.2')
cmd.label("label_threshold_8.2", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [8.2]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"11.5059995651":[], "11.5059995651_arrows":[]}

cluster_dict["11.5059995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(-3.5), float(12.5), float(1.0)]

cluster_dict["11.5059995651_arrows"] += cgo_arrow([24.0,-3.5,12.5], [21.766,-1.319,13.37], color="blue red", name="Arrows_11.5059995651_1")

cluster_dict["11.5059995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(-3.5), float(12.5), float(1.0)]

cluster_dict["11.5059995651_arrows"] += cgo_arrow([24.0,-3.5,12.5], [21.766,-1.319,13.37], color="blue red", name="Arrows_11.5059995651_2")

cluster_dict["11.5059995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(25.0), float(-0.5), float(3.0), float(1.0)]

cluster_dict["11.5059995651_arrows"] += cgo_arrow([25.0,-0.5,3.0], [23.784,-1.609,0.528], color="blue red", name="Arrows_11.5059995651_3")

cluster_dict["11.5059995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(-15.5), float(18.0), float(1.0)]


cluster_dict["11.5059995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(18.184603147), float(-16.2256148549), float(16.1963207519), float(1.0)]


cluster_dict["11.5059995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.6164940474), float(-11.6013310024), float(9.14526445125), float(1.0)]


cluster_dict["11.5059995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(25.0957410712), float(-2.44218658832), float(11.9308281248), float(1.0)]


cluster_dict["11.5059995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(27.2531745281), float(-1.6884982441), float(4.99753601511), float(1.0)]


cluster_dict["11.5059995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.0), float(-13.0), float(15.0), float(1.0)]

cluster_dict["11.5059995651_arrows"] += cgo_arrow([18.0,-13.0,15.0], [16.48,-10.765,14.656], color="red blue", name="Arrows_11.5059995651_4")

cluster_dict["11.5059995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(-8.5), float(7.0), float(1.0)]

cluster_dict["11.5059995651_arrows"] += cgo_arrow([22.5,-8.5,7.0], [22.101,-6.363,4.763], color="red blue", name="Arrows_11.5059995651_5")

cluster_dict["11.5059995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(-2.5), float(11.5), float(1.0)]

cluster_dict["11.5059995651_arrows"] += cgo_arrow([26.5,-2.5,11.5], [25.888,-5.209,9.814], color="red blue", name="Arrows_11.5059995651_6")

cluster_dict["11.5059995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(-2.5), float(11.5), float(1.0)]

cluster_dict["11.5059995651_arrows"] += cgo_arrow([26.5,-2.5,11.5], [25.888,-5.209,9.814], color="red blue", name="Arrows_11.5059995651_7")

cluster_dict["11.5059995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(-2.5), float(4.0), float(1.0)]

cluster_dict["11.5059995651_arrows"] += cgo_arrow([26.0,-2.5,4.0], [26.993,-4.956,2.181], color="red blue", name="Arrows_11.5059995651_8")

cmd.load_cgo(cluster_dict["11.5059995651"], "Features_11.5059995651", 1)
cmd.load_cgo(cluster_dict["11.5059995651_arrows"], "Arrows_11.5059995651")
cmd.set("transparency", 0.2,"Features_11.5059995651")
cmd.group("Pharmacophore_11.5059995651", members="Features_11.5059995651")
cmd.group("Pharmacophore_11.5059995651", members="Arrows_11.5059995651")

if dirpath:
    f = join(dirpath, "label_threshold_11.5059995651.mol2")
else:
    f = "label_threshold_11.5059995651.mol2"

cmd.load(f, 'label_threshold_11.5059995651')
cmd.hide('everything', 'label_threshold_11.5059995651')
cmd.label("label_threshold_11.5059995651", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_11.5059995651', members= 'label_threshold_11.5059995651')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
