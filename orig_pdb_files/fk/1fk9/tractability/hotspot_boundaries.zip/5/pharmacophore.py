
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.4230003357":[], "16.4230003357_arrows":[]}

cluster_dict["16.4230003357"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(-31.0), float(22.0), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([17.5,-31.0,22.0], [15.264,-32.638,22.22], color="blue red", name="Arrows_16.4230003357_1")

cluster_dict["16.4230003357"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(-44.0), float(26.5), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([18.5,-44.0,26.5], [15.475,-45.652,25.95], color="blue red", name="Arrows_16.4230003357_2")

cluster_dict["16.4230003357"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(20.0), float(-33.5), float(26.0), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([20.0,-33.5,26.0], [20.162,-31.121,28.672], color="blue red", name="Arrows_16.4230003357_3")

cluster_dict["16.4230003357"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(-30.5), float(21.0), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([19.5,-30.5,21.0], [22.725,-29.591,19.691], color="blue red", name="Arrows_16.4230003357_4")

cluster_dict["16.4230003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(12.1383293424), float(-37.0312123023), float(33.8141889245), float(1.0)]


cluster_dict["16.4230003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(19.3261786062), float(-41.7096184277), float(28.0941020175), float(1.0)]


cluster_dict["16.4230003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(20.3694078785), float(-32.7798788655), float(22.9498504669), float(1.0)]


cluster_dict["16.4230003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(20.1801188625), float(-47.8549009041), float(25.6989864157), float(1.0)]


cluster_dict["16.4230003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(21.2), float(-32.8), float(27.0), float(1.0)]


cluster_dict["16.4230003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(-32.9084143942), float(28.9471952019), float(1.0)]


cluster_dict["16.4230003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(-44.8426303555), float(30.194764049), float(1.0)]


cluster_dict["16.4230003357"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(-39.4995775304), float(34.7862616234), float(1.0)]


cluster_dict["16.4230003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(-40.5), float(28.5), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([16.0,-40.5,28.5], [13.403,-39.381,29.79], color="red blue", name="Arrows_16.4230003357_5")

cluster_dict["16.4230003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(-30.0), float(22.0), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([16.0,-30.0,22.0], [13.97,-30.815,22.039], color="red blue", name="Arrows_16.4230003357_6")

cluster_dict["16.4230003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(-31.5), float(24.0), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([17.5,-31.5,24.0], [15.279,-30.499,26.119], color="red blue", name="Arrows_16.4230003357_7")

cluster_dict["16.4230003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(-44.0), float(23.5), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([20.5,-44.0,23.5], [22.794,-42.19,22.011], color="red blue", name="Arrows_16.4230003357_8")

cluster_dict["16.4230003357"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(-31.0), float(24.0), float(1.0)]

cluster_dict["16.4230003357_arrows"] += cgo_arrow([23.0,-31.0,24.0], [24.932,-30.214,21.553], color="red blue", name="Arrows_16.4230003357_9")

cmd.load_cgo(cluster_dict["16.4230003357"], "Features_16.4230003357", 1)
cmd.load_cgo(cluster_dict["16.4230003357_arrows"], "Arrows_16.4230003357")
cmd.set("transparency", 0.2,"Features_16.4230003357")
cmd.group("Pharmacophore_16.4230003357", members="Features_16.4230003357")
cmd.group("Pharmacophore_16.4230003357", members="Arrows_16.4230003357")

if dirpath:
    f = join(dirpath, "label_threshold_16.4230003357.mol2")
else:
    f = "label_threshold_16.4230003357.mol2"

cmd.load(f, 'label_threshold_16.4230003357')
cmd.hide('everything', 'label_threshold_16.4230003357')
cmd.label("label_threshold_16.4230003357", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.4230003357', members= 'label_threshold_16.4230003357')
