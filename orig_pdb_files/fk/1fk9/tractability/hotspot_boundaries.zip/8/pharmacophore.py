
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.8090000153":[], "15.8090000153_arrows":[]}

cluster_dict["15.8090000153"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(-3.0), float(12.0), float(1.0)]

cluster_dict["15.8090000153_arrows"] += cgo_arrow([24.0,-3.0,12.0], [21.766,-1.319,13.37], color="blue red", name="Arrows_15.8090000153_1")

cluster_dict["15.8090000153"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(2.0), float(-2.5), float(1.0)]

cluster_dict["15.8090000153_arrows"] += cgo_arrow([27.0,2.0,-2.5], [26.236,5.121,-2.387], color="blue red", name="Arrows_15.8090000153_2")

cluster_dict["15.8090000153"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(7.0), float(0.0), float(1.0)]

cluster_dict["15.8090000153_arrows"] += cgo_arrow([30.5,7.0,0.0], [31.908,8.68,1.718], color="blue red", name="Arrows_15.8090000153_3")

cluster_dict["15.8090000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(29.8360627635), float(1.24309894995), float(0.688932158277), float(1.0)]


cluster_dict["15.8090000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(33.7801552175), float(1.70494645616), float(10.8799148095), float(1.0)]


cluster_dict["15.8090000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(40.531605642), float(1.94987620702), float(-0.753589955375), float(1.0)]


cluster_dict["15.8090000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(40.5), float(2.72222222222), float(-4.38888888889), float(1.0)]


cluster_dict["15.8090000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(-7.5), float(6.5), float(1.0)]

cluster_dict["15.8090000153_arrows"] += cgo_arrow([22.5,-7.5,6.5], [22.101,-6.363,4.763], color="red blue", name="Arrows_15.8090000153_4")

cluster_dict["15.8090000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(-2.5), float(11.5), float(1.0)]

cluster_dict["15.8090000153_arrows"] += cgo_arrow([27.0,-2.5,11.5], [25.888,-5.209,9.814], color="red blue", name="Arrows_15.8090000153_5")

cluster_dict["15.8090000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(-2.5), float(4.0), float(1.0)]

cluster_dict["15.8090000153_arrows"] += cgo_arrow([26.0,-2.5,4.0], [26.993,-4.956,2.181], color="red blue", name="Arrows_15.8090000153_6")

cluster_dict["15.8090000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(31.5), float(-0.5), float(2.0), float(1.0)]

cluster_dict["15.8090000153_arrows"] += cgo_arrow([31.5,-0.5,2.0], [33.219,-2.042,2.779], color="red blue", name="Arrows_15.8090000153_7")

cmd.load_cgo(cluster_dict["15.8090000153"], "Features_15.8090000153", 1)
cmd.load_cgo(cluster_dict["15.8090000153_arrows"], "Arrows_15.8090000153")
cmd.set("transparency", 0.2,"Features_15.8090000153")
cmd.group("Pharmacophore_15.8090000153", members="Features_15.8090000153")
cmd.group("Pharmacophore_15.8090000153", members="Arrows_15.8090000153")

if dirpath:
    f = join(dirpath, "label_threshold_15.8090000153.mol2")
else:
    f = "label_threshold_15.8090000153.mol2"

cmd.load(f, 'label_threshold_15.8090000153')
cmd.hide('everything', 'label_threshold_15.8090000153')
cmd.label("label_threshold_15.8090000153", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.8090000153', members= 'label_threshold_15.8090000153')
