
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.8039999008":[], "15.8039999008_arrows":[]}

cluster_dict["15.8039999008"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(-3.0), float(12.5), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([24.0,-3.0,12.5], [21.766,-1.319,13.37], color="blue red", name="Arrows_15.8039999008_1")

cluster_dict["15.8039999008"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.5), float(-11.0), float(9.0), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([24.5,-11.0,9.0], [26.667,-9.958,10.507], color="blue red", name="Arrows_15.8039999008_2")

cluster_dict["15.8039999008"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(2.0), float(-2.5), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([27.0,2.0,-2.5], [26.236,5.121,-2.387], color="blue red", name="Arrows_15.8039999008_3")

cluster_dict["15.8039999008"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(-9.5), float(14.0), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([26.5,-9.5,14.0], [28.783,-7.532,13.582], color="blue red", name="Arrows_15.8039999008_4")

cluster_dict["15.8039999008"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(7.0), float(0.0), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([30.5,7.0,0.0], [31.908,8.68,1.718], color="blue red", name="Arrows_15.8039999008_5")

cluster_dict["15.8039999008"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.9206195707), float(-11.0512520991), float(8.84098633983), float(1.0)]


cluster_dict["15.8039999008"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(29.8236361515), float(1.21709503082), float(0.723811118156), float(1.0)]


cluster_dict["15.8039999008"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(33.9630721097), float(1.79129273337), float(11.884841271), float(1.0)]


cluster_dict["15.8039999008"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(39.5), float(-1.7633203123), float(-0.560385400252), float(1.0)]


cluster_dict["15.8039999008"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(-8.5), float(7.0), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([22.5,-8.5,7.0], [22.101,-6.363,4.763], color="red blue", name="Arrows_15.8039999008_6")

cluster_dict["15.8039999008"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(-2.5), float(11.5), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([27.0,-2.5,11.5], [25.888,-5.209,9.814], color="red blue", name="Arrows_15.8039999008_7")

cluster_dict["15.8039999008"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(-2.5), float(4.0), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([26.0,-2.5,4.0], [26.993,-4.956,2.181], color="red blue", name="Arrows_15.8039999008_8")

cluster_dict["15.8039999008"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(31.5), float(-0.5), float(2.0), float(1.0)]

cluster_dict["15.8039999008_arrows"] += cgo_arrow([31.5,-0.5,2.0], [33.219,-2.042,2.779], color="red blue", name="Arrows_15.8039999008_9")

cmd.load_cgo(cluster_dict["15.8039999008"], "Features_15.8039999008", 1)
cmd.load_cgo(cluster_dict["15.8039999008_arrows"], "Arrows_15.8039999008")
cmd.set("transparency", 0.2,"Features_15.8039999008")
cmd.group("Pharmacophore_15.8039999008", members="Features_15.8039999008")
cmd.group("Pharmacophore_15.8039999008", members="Arrows_15.8039999008")

if dirpath:
    f = join(dirpath, "label_threshold_15.8039999008.mol2")
else:
    f = "label_threshold_15.8039999008.mol2"

cmd.load(f, 'label_threshold_15.8039999008')
cmd.hide('everything', 'label_threshold_15.8039999008')
cmd.label("label_threshold_15.8039999008", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.8039999008', members= 'label_threshold_15.8039999008')
