
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.7420005798":[], "16.7420005798_arrows":[]}

cluster_dict["16.7420005798"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(-3.0), float(12.0), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([24.0,-3.0,12.0], [21.766,-1.319,13.37], color="blue red", name="Arrows_16.7420005798_1")

cluster_dict["16.7420005798"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(2.0), float(2.0), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([26.0,2.0,2.0], [23.655,2.241,1.129], color="blue red", name="Arrows_16.7420005798_2")

cluster_dict["16.7420005798"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(2.5), float(-1.0), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([26.0,2.5,-1.0], [26.236,5.121,-2.387], color="blue red", name="Arrows_16.7420005798_3")

cluster_dict["16.7420005798"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(2.0), float(-2.5), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([27.0,2.0,-2.5], [26.236,5.121,-2.387], color="blue red", name="Arrows_16.7420005798_4")

cluster_dict["16.7420005798"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(7.0), float(0.0), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([30.5,7.0,0.0], [31.908,8.68,1.718], color="blue red", name="Arrows_16.7420005798_5")

cluster_dict["16.7420005798"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(44.5), float(-0.5), float(11.5), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([44.5,-0.5,11.5], [47.549,0.315,10.678], color="blue red", name="Arrows_16.7420005798_6")

cluster_dict["16.7420005798"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(29.4331221431), float(1.09660523711), float(1.11365114511), float(1.0)]


cluster_dict["16.7420005798"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(34.0345533343), float(1.77668193439), float(11.979851349), float(1.0)]


cluster_dict["16.7420005798"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(34.9028224901), float(2.39631919966), float(8.28702885726), float(1.0)]


cluster_dict["16.7420005798"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(41.4901511383), float(2.63355613373), float(-0.683013480244), float(1.0)]


cluster_dict["16.7420005798"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(43.2834367478), float(-4.72043011736), float(10.5970722458), float(1.0)]


cluster_dict["16.7420005798"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(44.5), float(4.0), float(8.5), float(1.0)]


cluster_dict["16.7420005798"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(-2.5), float(11.5), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([27.0,-2.5,11.5], [25.888,-5.209,9.814], color="red blue", name="Arrows_16.7420005798_7")

cluster_dict["16.7420005798"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(43.0), float(-7.0), float(8.5), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([43.0,-7.0,8.5], [40.826,-8.37,6.871], color="red blue", name="Arrows_16.7420005798_8")

cluster_dict["16.7420005798"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(44.5), float(-3.5), float(10.0), float(1.0)]

cluster_dict["16.7420005798_arrows"] += cgo_arrow([44.5,-3.5,10.0], [45.601,-1.014,8.286], color="red blue", name="Arrows_16.7420005798_9")

cmd.load_cgo(cluster_dict["16.7420005798"], "Features_16.7420005798", 1)
cmd.load_cgo(cluster_dict["16.7420005798_arrows"], "Arrows_16.7420005798")
cmd.set("transparency", 0.2,"Features_16.7420005798")
cmd.group("Pharmacophore_16.7420005798", members="Features_16.7420005798")
cmd.group("Pharmacophore_16.7420005798", members="Arrows_16.7420005798")

if dirpath:
    f = join(dirpath, "label_threshold_16.7420005798.mol2")
else:
    f = "label_threshold_16.7420005798.mol2"

cmd.load(f, 'label_threshold_16.7420005798')
cmd.hide('everything', 'label_threshold_16.7420005798')
cmd.label("label_threshold_16.7420005798", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.7420005798', members= 'label_threshold_16.7420005798')
