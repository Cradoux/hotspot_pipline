
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.5200004578":[], "14.5200004578_arrows":[]}

cluster_dict["14.5200004578"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(-34.5), float(-1.0), float(1.0)]

cluster_dict["14.5200004578_arrows"] += cgo_arrow([36.0,-34.5,-1.0], [35.162,-31.753,-0.868], color="blue red", name="Arrows_14.5200004578_1")

cluster_dict["14.5200004578"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(-36.0), float(-4.0), float(1.0)]

cluster_dict["14.5200004578_arrows"] += cgo_arrow([36.5,-36.0,-4.0], [33.351,-35.839,-4.065], color="blue red", name="Arrows_14.5200004578_2")

cluster_dict["14.5200004578"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(38.5), float(-25.0), float(0.0), float(1.0)]

cluster_dict["14.5200004578_arrows"] += cgo_arrow([38.5,-25.0,0.0], [37.904,-22.855,1.023], color="blue red", name="Arrows_14.5200004578_3")

cluster_dict["14.5200004578"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(38.8468691937), float(-26.7496661103), float(-1.47969838646), float(1.0)]


cluster_dict["14.5200004578"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(36.3383055946), float(-34.4811835163), float(-1.56143115676), float(1.0)]


cluster_dict["14.5200004578"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(-28.5), float(-4.5), float(1.0)]

cluster_dict["14.5200004578_arrows"] += cgo_arrow([36.5,-28.5,-4.5], [37.132,-30.946,-6.482], color="red blue", name="Arrows_14.5200004578_4")

cluster_dict["14.5200004578"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(39.0), float(-23.5), float(-4.0), float(1.0)]

cluster_dict["14.5200004578_arrows"] += cgo_arrow([39.0,-23.5,-4.0], [36.528,-21.922,-3.46], color="red blue", name="Arrows_14.5200004578_5")

cluster_dict["14.5200004578"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(40.5), float(-27.5), float(2.0), float(1.0)]

cluster_dict["14.5200004578_arrows"] += cgo_arrow([40.5,-27.5,2.0], [43.271,-28.102,3.157], color="red blue", name="Arrows_14.5200004578_6")

cmd.load_cgo(cluster_dict["14.5200004578"], "Features_14.5200004578", 1)
cmd.load_cgo(cluster_dict["14.5200004578_arrows"], "Arrows_14.5200004578")
cmd.set("transparency", 0.2,"Features_14.5200004578")
cmd.group("Pharmacophore_14.5200004578", members="Features_14.5200004578")
cmd.group("Pharmacophore_14.5200004578", members="Arrows_14.5200004578")

if dirpath:
    f = join(dirpath, "label_threshold_14.5200004578.mol2")
else:
    f = "label_threshold_14.5200004578.mol2"

cmd.load(f, 'label_threshold_14.5200004578')
cmd.hide('everything', 'label_threshold_14.5200004578')
cmd.label("label_threshold_14.5200004578", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.5200004578', members= 'label_threshold_14.5200004578')
