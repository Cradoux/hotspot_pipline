
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"8.93799972534":[], "8.93799972534_arrows":[]}

cluster_dict["8.93799972534"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(52.5), float(-7.5), float(6.5), float(1.0)]

cluster_dict["8.93799972534_arrows"] += cgo_arrow([52.5,-7.5,6.5], [50.139,-8.382,8.294], color="blue red", name="Arrows_8.93799972534_1")

cluster_dict["8.93799972534"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(46.5), float(-23.2757988631), float(-1.39680454755), float(1.0)]


cluster_dict["8.93799972534"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(52.5708664333), float(-12.3399113307), float(3.29011214206), float(1.0)]


cluster_dict["8.93799972534"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(49.0), float(-9.0), float(1.5), float(1.0)]

cluster_dict["8.93799972534_arrows"] += cgo_arrow([49.0,-9.0,1.5], [48.96,-11.301,1.715], color="red blue", name="Arrows_8.93799972534_2")

cluster_dict["8.93799972534"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(51.0), float(-9.0), float(3.5), float(1.0)]

cluster_dict["8.93799972534_arrows"] += cgo_arrow([51.0,-9.0,3.5], [48.96,-11.301,1.715], color="red blue", name="Arrows_8.93799972534_3")

cluster_dict["8.93799972534"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(51.0), float(-9.0), float(3.5), float(1.0)]

cluster_dict["8.93799972534_arrows"] += cgo_arrow([51.0,-9.0,3.5], [48.96,-11.301,1.715], color="red blue", name="Arrows_8.93799972534_4")

cmd.load_cgo(cluster_dict["8.93799972534"], "Features_8.93799972534", 1)
cmd.load_cgo(cluster_dict["8.93799972534_arrows"], "Arrows_8.93799972534")
cmd.set("transparency", 0.2,"Features_8.93799972534")
cmd.group("Pharmacophore_8.93799972534", members="Features_8.93799972534")
cmd.group("Pharmacophore_8.93799972534", members="Arrows_8.93799972534")

if dirpath:
    f = join(dirpath, "label_threshold_8.93799972534.mol2")
else:
    f = "label_threshold_8.93799972534.mol2"

cmd.load(f, 'label_threshold_8.93799972534')
cmd.hide('everything', 'label_threshold_8.93799972534')
cmd.label("label_threshold_8.93799972534", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_8.93799972534', members= 'label_threshold_8.93799972534')
