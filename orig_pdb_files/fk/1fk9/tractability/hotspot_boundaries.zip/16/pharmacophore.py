
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.7399997711":[], "14.7399997711_arrows":[]}

cluster_dict["14.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.0), float(-31.0), float(21.5), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([19.0,-31.0,21.5], [15.264,-32.638,22.22], color="blue red", name="Arrows_14.7399997711_1")

cluster_dict["14.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.0), float(-31.0), float(21.5), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([19.0,-31.0,21.5], [15.264,-32.638,22.22], color="blue red", name="Arrows_14.7399997711_2")

cluster_dict["14.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(-33.0), float(26.0), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([20.5,-33.0,26.0], [20.162,-31.121,28.672], color="blue red", name="Arrows_14.7399997711_3")

cluster_dict["14.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.0), float(-26.5), float(16.0), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([29.0,-26.5,16.0], [27.469,-24.336,14.801], color="blue red", name="Arrows_14.7399997711_4")

cluster_dict["14.7399997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(20.8727115296), float(-30.9851875476), float(22.7942605172), float(1.0)]


cluster_dict["14.7399997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(28.479841117), float(-26.0752281469), float(19.5143209604), float(1.0)]


cluster_dict["14.7399997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(-32.4383212106), float(28.9691407786), float(1.0)]


cluster_dict["14.7399997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(36.3634887665), float(-25.1801162355), float(20.0853889465), float(1.0)]


cluster_dict["14.7399997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(37.895945019), float(-31.7493058494), float(15.2686160489), float(1.0)]


cluster_dict["14.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(-29.5), float(22.0), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([17.0,-29.5,22.0], [13.97,-30.815,22.039], color="red blue", name="Arrows_14.7399997711_5")

cluster_dict["14.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(-32.0), float(17.0), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([18.5,-32.0,17.0], [20.191,-30.573,14.342], color="red blue", name="Arrows_14.7399997711_6")

cluster_dict["14.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(-34.0), float(21.0), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([18.5,-34.0,21.0], [17.274,-35.929,18.15], color="red blue", name="Arrows_14.7399997711_7")

cluster_dict["14.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(-35.5), float(23.5), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([20.5,-35.5,23.5], [21.795,-37.163,26.941], color="red blue", name="Arrows_14.7399997711_8")

cluster_dict["14.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(-31.0), float(24.0), float(1.0)]

cluster_dict["14.7399997711_arrows"] += cgo_arrow([23.0,-31.0,24.0], [24.932,-30.214,21.553], color="red blue", name="Arrows_14.7399997711_9")

cmd.load_cgo(cluster_dict["14.7399997711"], "Features_14.7399997711", 1)
cmd.load_cgo(cluster_dict["14.7399997711_arrows"], "Arrows_14.7399997711")
cmd.set("transparency", 0.2,"Features_14.7399997711")
cmd.group("Pharmacophore_14.7399997711", members="Features_14.7399997711")
cmd.group("Pharmacophore_14.7399997711", members="Arrows_14.7399997711")

if dirpath:
    f = join(dirpath, "label_threshold_14.7399997711.mol2")
else:
    f = "label_threshold_14.7399997711.mol2"

cmd.load(f, 'label_threshold_14.7399997711')
cmd.hide('everything', 'label_threshold_14.7399997711')
cmd.label("label_threshold_14.7399997711", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.7399997711', members= 'label_threshold_14.7399997711')
