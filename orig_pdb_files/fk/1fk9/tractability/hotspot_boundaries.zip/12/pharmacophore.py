
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.1840000153":[], "15.1840000153_arrows":[]}

cluster_dict["15.1840000153"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(43.5), float(-8.5), float(9.5), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([43.5,-8.5,9.5], [43.181,-9.676,7.212], color="blue red", name="Arrows_15.1840000153_1")

cluster_dict["15.1840000153"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(44.5), float(-1.0), float(11.0), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([44.5,-1.0,11.0], [47.549,0.315,10.678], color="blue red", name="Arrows_15.1840000153_2")

cluster_dict["15.1840000153"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(-6.0), float(8.0), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([48.0,-6.0,8.0], [45.592,-6.463,6.489], color="blue red", name="Arrows_15.1840000153_3")

cluster_dict["15.1840000153"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(52.5), float(-7.0), float(6.5), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([52.5,-7.0,6.5], [50.139,-8.382,8.294], color="blue red", name="Arrows_15.1840000153_4")

cluster_dict["15.1840000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(41.7715163298), float(-0.616554517252), float(-1.12806149459), float(1.0)]


cluster_dict["15.1840000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(44.1433299831), float(-6.15080711521), float(10.7317697741), float(1.0)]


cluster_dict["15.1840000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(51.1627419202), float(-8.22607166055), float(4.17812572322), float(1.0)]


cluster_dict["15.1840000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(53.0), float(-7.0), float(0.5), float(1.0)]


cluster_dict["15.1840000153"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(54.0), float(-6.99755319129), float(1.5), float(1.0)]


cluster_dict["15.1840000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(47.0), float(-7.0), float(9.0), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([47.0,-7.0,9.0], [45.592,-6.463,6.489], color="red blue", name="Arrows_15.1840000153_5")

cluster_dict["15.1840000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(45.0), float(-3.5), float(10.0), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([45.0,-3.5,10.0], [45.601,-1.014,8.286], color="red blue", name="Arrows_15.1840000153_6")

cluster_dict["15.1840000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(-7.0), float(5.5), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([48.0,-7.0,5.5], [45.592,-6.463,6.489], color="red blue", name="Arrows_15.1840000153_7")

cluster_dict["15.1840000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(51.0), float(-9.0), float(3.5), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([51.0,-9.0,3.5], [48.96,-11.301,1.715], color="red blue", name="Arrows_15.1840000153_8")

cluster_dict["15.1840000153"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(51.0), float(-9.0), float(3.5), float(1.0)]

cluster_dict["15.1840000153_arrows"] += cgo_arrow([51.0,-9.0,3.5], [48.96,-11.301,1.715], color="red blue", name="Arrows_15.1840000153_9")

cmd.load_cgo(cluster_dict["15.1840000153"], "Features_15.1840000153", 1)
cmd.load_cgo(cluster_dict["15.1840000153_arrows"], "Arrows_15.1840000153")
cmd.set("transparency", 0.2,"Features_15.1840000153")
cmd.group("Pharmacophore_15.1840000153", members="Features_15.1840000153")
cmd.group("Pharmacophore_15.1840000153", members="Arrows_15.1840000153")

if dirpath:
    f = join(dirpath, "label_threshold_15.1840000153.mol2")
else:
    f = "label_threshold_15.1840000153.mol2"

cmd.load(f, 'label_threshold_15.1840000153')
cmd.hide('everything', 'label_threshold_15.1840000153')
cmd.label("label_threshold_15.1840000153", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.1840000153', members= 'label_threshold_15.1840000153')
