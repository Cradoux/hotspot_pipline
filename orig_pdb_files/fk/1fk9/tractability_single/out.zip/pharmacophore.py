
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.7140007019":[], "17.7140007019_arrows":[]}

cluster_dict["17.7140007019"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(-41.5), float(36.0), float(1.0)]

cluster_dict["17.7140007019_arrows"] += cgo_arrow([30.5,-41.5,36.0], [27.575,-41.176,36.727], color="blue red", name="Arrows_17.7140007019_1")

cluster_dict["17.7140007019"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(32.5), float(-35.5), float(36.0), float(1.0)]

cluster_dict["17.7140007019_arrows"] += cgo_arrow([32.5,-35.5,36.0], [34.071,-33.616,34.804], color="blue red", name="Arrows_17.7140007019_2")

cluster_dict["17.7140007019"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.0), float(-41.0), float(39.5), float(1.0)]

cluster_dict["17.7140007019_arrows"] += cgo_arrow([33.0,-41.0,39.5], [31.939,-40.222,42.03], color="blue red", name="Arrows_17.7140007019_3")

cluster_dict["17.7140007019"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(32.2444532429), float(-41.6500576936), float(34.0738691292), float(1.0)]


cluster_dict["17.7140007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(-44.0), float(36.5), float(1.0)]

cluster_dict["17.7140007019_arrows"] += cgo_arrow([30.0,-44.0,36.5], [28.683,-42.257,38.348], color="red blue", name="Arrows_17.7140007019_4")

cluster_dict["17.7140007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(-36.5), float(38.0), float(1.0)]

cluster_dict["17.7140007019_arrows"] += cgo_arrow([30.5,-36.5,38.0], [27.542,-36.538,38.091], color="red blue", name="Arrows_17.7140007019_5")

cluster_dict["17.7140007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(34.0), float(-39.5), float(34.5), float(1.0)]

cluster_dict["17.7140007019_arrows"] += cgo_arrow([34.0,-39.5,34.5], [33.968,-36.953,33.337], color="red blue", name="Arrows_17.7140007019_6")

cmd.load_cgo(cluster_dict["17.7140007019"], "Features_17.7140007019", 1)
cmd.load_cgo(cluster_dict["17.7140007019_arrows"], "Arrows_17.7140007019")
cmd.set("transparency", 0.2,"Features_17.7140007019")
cmd.group("Pharmacophore_17.7140007019", members="Features_17.7140007019")
cmd.group("Pharmacophore_17.7140007019", members="Arrows_17.7140007019")

if dirpath:
    f = join(dirpath, "label_threshold_17.7140007019.mol2")
else:
    f = "label_threshold_17.7140007019.mol2"

cmd.load(f, 'label_threshold_17.7140007019')
cmd.hide('everything', 'label_threshold_17.7140007019')
cmd.label("label_threshold_17.7140007019", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.7140007019', members= 'label_threshold_17.7140007019')
