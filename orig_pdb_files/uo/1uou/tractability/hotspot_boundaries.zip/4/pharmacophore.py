
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.0970001221":[], "14.0970001221_arrows":[]}

cluster_dict["14.0970001221"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-14.5), float(-7.5), float(21.5), float(1.0)]

cluster_dict["14.0970001221_arrows"] += cgo_arrow([-14.5,-7.5,21.5], [-14.228,-10.728,20.922], color="blue red", name="Arrows_14.0970001221_1")

cluster_dict["14.0970001221"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-14.0), float(-0.5), float(21.5), float(1.0)]

cluster_dict["14.0970001221_arrows"] += cgo_arrow([-14.0,-0.5,21.5], [-12.971,1.338,24.129], color="blue red", name="Arrows_14.0970001221_2")

cluster_dict["14.0970001221"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-13.0), float(1.0), float(21.0), float(1.0)]

cluster_dict["14.0970001221_arrows"] += cgo_arrow([-13.0,1.0,21.0], [-12.971,1.338,24.129], color="blue red", name="Arrows_14.0970001221_3")

cluster_dict["14.0970001221"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-11.0), float(-5.0), float(23.5), float(1.0)]

cluster_dict["14.0970001221_arrows"] += cgo_arrow([-11.0,-5.0,23.5], [-10.199,-6.72,22.235], color="blue red", name="Arrows_14.0970001221_4")

cluster_dict["14.0970001221"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-6.0), float(1.5), float(24.0), float(1.0)]

cluster_dict["14.0970001221_arrows"] += cgo_arrow([-6.0,1.5,24.0], [-6.966,-1.252,23.733], color="blue red", name="Arrows_14.0970001221_5")

cluster_dict["14.0970001221"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-13.4334821607), float(-4.35849451844), float(23.4710020673), float(1.0)]


cluster_dict["14.0970001221"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-8.5), float(-2.63222170249), float(20.4306236026), float(1.0)]


cluster_dict["14.0970001221"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-6.6672141948), float(0.450498108582), float(26.7523386979), float(1.0)]


cluster_dict["14.0970001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-14.0), float(-2.0), float(24.5), float(1.0)]

cluster_dict["14.0970001221_arrows"] += cgo_arrow([-14.0,-2.0,24.5], [-15.564,-2.598,27.017], color="red blue", name="Arrows_14.0970001221_6")

cluster_dict["14.0970001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-15.0), float(-1.0), float(21.5), float(1.0)]

cluster_dict["14.0970001221_arrows"] += cgo_arrow([-15.0,-1.0,21.5], [-18.128,-2.744,23.189], color="red blue", name="Arrows_14.0970001221_7")

cmd.load_cgo(cluster_dict["14.0970001221"], "Features_14.0970001221", 1)
cmd.load_cgo(cluster_dict["14.0970001221_arrows"], "Arrows_14.0970001221")
cmd.set("transparency", 0.2,"Features_14.0970001221")
cmd.group("Pharmacophore_14.0970001221", members="Features_14.0970001221")
cmd.group("Pharmacophore_14.0970001221", members="Arrows_14.0970001221")

if dirpath:
    f = join(dirpath, "label_threshold_14.0970001221.mol2")
else:
    f = "label_threshold_14.0970001221.mol2"

cmd.load(f, 'label_threshold_14.0970001221')
cmd.hide('everything', 'label_threshold_14.0970001221')
cmd.label("label_threshold_14.0970001221", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.0970001221', members= 'label_threshold_14.0970001221')
