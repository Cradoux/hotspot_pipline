
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"10.3339996338":[], "10.3339996338_arrows":[]}

cluster_dict["10.3339996338"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(45.0), float(48.5), float(10.5), float(1.0)]

cluster_dict["10.3339996338_arrows"] += cgo_arrow([45.0,48.5,10.5], [47.87,49.057,10.538], color="blue red", name="Arrows_10.3339996338_1")

cluster_dict["10.3339996338"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(43.4494100047), float(46.6783843293), float(10.8180872017), float(1.0)]


cluster_dict["10.3339996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(45.5), float(45.5), float(11.0), float(1.0)]

cluster_dict["10.3339996338_arrows"] += cgo_arrow([45.5,45.5,11.0], [44.739,42.649,13.009], color="red blue", name="Arrows_10.3339996338_2")

cluster_dict["10.3339996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(45.5), float(46.0), float(10.0), float(1.0)]

cluster_dict["10.3339996338_arrows"] += cgo_arrow([45.5,46.0,10.0], [48.134,47.667,8.79], color="red blue", name="Arrows_10.3339996338_3")

cmd.load_cgo(cluster_dict["10.3339996338"], "Features_10.3339996338", 1)
cmd.load_cgo(cluster_dict["10.3339996338_arrows"], "Arrows_10.3339996338")
cmd.set("transparency", 0.2,"Features_10.3339996338")
cmd.group("Pharmacophore_10.3339996338", members="Features_10.3339996338")
cmd.group("Pharmacophore_10.3339996338", members="Arrows_10.3339996338")

if dirpath:
    f = join(dirpath, "label_threshold_10.3339996338.mol2")
else:
    f = "label_threshold_10.3339996338.mol2"

cmd.load(f, 'label_threshold_10.3339996338')
cmd.hide('everything', 'label_threshold_10.3339996338')
cmd.label("label_threshold_10.3339996338", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_10.3339996338', members= 'label_threshold_10.3339996338')
