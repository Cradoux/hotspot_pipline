
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.3319997787":[], "14.3319997787_arrows":[]}

cluster_dict["14.3319997787"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(69.0), float(48.5), float(6.0), float(1.0)]

cluster_dict["14.3319997787_arrows"] += cgo_arrow([69.0,48.5,6.0], [67.674,48.455,3.678], color="blue red", name="Arrows_14.3319997787_1")

cluster_dict["14.3319997787"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(70.0), float(46.0), float(0.5), float(1.0)]

cluster_dict["14.3319997787_arrows"] += cgo_arrow([70.0,46.0,0.5], [67.737,45.598,-0.45], color="blue red", name="Arrows_14.3319997787_2")

cluster_dict["14.3319997787"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(71.0), float(44.0), float(-0.5), float(1.0)]

cluster_dict["14.3319997787_arrows"] += cgo_arrow([71.0,44.0,-0.5], [72.426,42.145,-2.486], color="blue red", name="Arrows_14.3319997787_3")

cluster_dict["14.3319997787"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(72.3710610664), float(45.1717009121), float(3.83195332625), float(1.0)]


cluster_dict["14.3319997787"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(70.5), float(43.0), float(3.0), float(1.0)]

cluster_dict["14.3319997787_arrows"] += cgo_arrow([70.5,43.0,3.0], [70.844,40.247,1.133], color="red blue", name="Arrows_14.3319997787_4")

cluster_dict["14.3319997787"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(68.5), float(46.0), float(6.0), float(1.0)]


cluster_dict["14.3319997787"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(74.5), float(42.0), float(3.0), float(1.0)]

cluster_dict["14.3319997787_arrows"] += cgo_arrow([74.5,42.0,3.0], [72.687,40.241,4.233], color="red blue", name="Arrows_14.3319997787_5")

cmd.load_cgo(cluster_dict["14.3319997787"], "Features_14.3319997787", 1)
cmd.load_cgo(cluster_dict["14.3319997787_arrows"], "Arrows_14.3319997787")
cmd.set("transparency", 0.2,"Features_14.3319997787")
cmd.group("Pharmacophore_14.3319997787", members="Features_14.3319997787")
cmd.group("Pharmacophore_14.3319997787", members="Arrows_14.3319997787")

if dirpath:
    f = join(dirpath, "label_threshold_14.3319997787.mol2")
else:
    f = "label_threshold_14.3319997787.mol2"

cmd.load(f, 'label_threshold_14.3319997787')
cmd.hide('everything', 'label_threshold_14.3319997787')
cmd.label("label_threshold_14.3319997787", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.3319997787', members= 'label_threshold_14.3319997787')
