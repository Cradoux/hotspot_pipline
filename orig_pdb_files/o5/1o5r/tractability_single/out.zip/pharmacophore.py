
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.7189998627":[], "17.7189998627_arrows":[]}

cluster_dict["17.7189998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(45.5), float(46.5), float(15.5), float(1.0)]

cluster_dict["17.7189998627_arrows"] += cgo_arrow([45.5,46.5,15.5], [45.97,44.411,17.789], color="blue red", name="Arrows_17.7189998627_1")

cluster_dict["17.7189998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(52.0), float(51.0), float(21.0), float(1.0)]

cluster_dict["17.7189998627_arrows"] += cgo_arrow([52.0,51.0,21.0], [53.656,48.18,22.209], color="blue red", name="Arrows_17.7189998627_2")

cluster_dict["17.7189998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(52.0), float(51.0), float(21.0), float(1.0)]

cluster_dict["17.7189998627_arrows"] += cgo_arrow([52.0,51.0,21.0], [53.656,48.18,22.209], color="blue red", name="Arrows_17.7189998627_3")

cluster_dict["17.7189998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(52.5), float(50.5), float(17.5), float(1.0)]

cluster_dict["17.7189998627_arrows"] += cgo_arrow([52.5,50.5,17.5], [53.201,48.444,16.802], color="blue red", name="Arrows_17.7189998627_4")

cluster_dict["17.7189998627"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(49.002816335), float(54.4621537135), float(18.2579666205), float(1.0)]


cluster_dict["17.7189998627"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(47.0), float(48.5), float(14.5), float(1.0)]


cluster_dict["17.7189998627"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(58.5), float(22.0), float(1.0)]

cluster_dict["17.7189998627_arrows"] += cgo_arrow([48.0,58.5,22.0], [51.913,59.313,24.353], color="red blue", name="Arrows_17.7189998627_5")

cluster_dict["17.7189998627"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(50.0), float(52.5), float(22.5), float(1.0)]

cluster_dict["17.7189998627_arrows"] += cgo_arrow([50.0,52.5,22.5], [51.984,50.907,24.513], color="red blue", name="Arrows_17.7189998627_6")

cluster_dict["17.7189998627"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(51.0), float(49.0), float(21.5), float(1.0)]

cluster_dict["17.7189998627_arrows"] += cgo_arrow([51.0,49.0,21.5], [53.656,48.18,22.209], color="red blue", name="Arrows_17.7189998627_7")

cmd.load_cgo(cluster_dict["17.7189998627"], "Features_17.7189998627", 1)
cmd.load_cgo(cluster_dict["17.7189998627_arrows"], "Arrows_17.7189998627")
cmd.set("transparency", 0.2,"Features_17.7189998627")
cmd.group("Pharmacophore_17.7189998627", members="Features_17.7189998627")
cmd.group("Pharmacophore_17.7189998627", members="Arrows_17.7189998627")

if dirpath:
    f = join(dirpath, "label_threshold_17.7189998627.mol2")
else:
    f = "label_threshold_17.7189998627.mol2"

cmd.load(f, 'label_threshold_17.7189998627')
cmd.hide('everything', 'label_threshold_17.7189998627')
cmd.label("label_threshold_17.7189998627", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.7189998627', members= 'label_threshold_17.7189998627')
