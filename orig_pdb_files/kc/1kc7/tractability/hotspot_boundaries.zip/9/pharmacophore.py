
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.579000473":[], "13.579000473_arrows":[]}

cluster_dict["13.579000473"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(3.5), float(-13.5), float(1.0)]

cluster_dict["13.579000473_arrows"] += cgo_arrow([27.0,3.5,-13.5], [25.564,1.866,-16.048], color="blue red", name="Arrows_13.579000473_1")

cluster_dict["13.579000473"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(7.5), float(-12.0), float(1.0)]

cluster_dict["13.579000473_arrows"] += cgo_arrow([28.5,7.5,-12.0], [29.116,7.566,-9.101], color="blue red", name="Arrows_13.579000473_2")

cluster_dict["13.579000473"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(3.5), float(-13.0), float(1.0)]

cluster_dict["13.579000473_arrows"] += cgo_arrow([30.5,3.5,-13.0], [30.724,3.981,-15.898], color="blue red", name="Arrows_13.579000473_3")

cluster_dict["13.579000473"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.0), float(1.5), float(-11.5), float(1.0)]

cluster_dict["13.579000473_arrows"] += cgo_arrow([33.0,1.5,-11.5], [32.955,-0.155,-14.973], color="blue red", name="Arrows_13.579000473_4")

cluster_dict["13.579000473"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.0), float(1.5), float(-11.5), float(1.0)]

cluster_dict["13.579000473_arrows"] += cgo_arrow([33.0,1.5,-11.5], [32.955,-0.155,-14.973], color="blue red", name="Arrows_13.579000473_5")

cluster_dict["13.579000473"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(37.0), float(8.5), float(-11.5), float(1.0)]

cluster_dict["13.579000473_arrows"] += cgo_arrow([37.0,8.5,-11.5], [34.648,10.111,-12.296], color="blue red", name="Arrows_13.579000473_6")

cluster_dict["13.579000473"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(37.0), float(5.5), float(-9.0), float(1.0)]

cluster_dict["13.579000473_arrows"] += cgo_arrow([37.0,5.5,-9.0], [35.325,7.016,-7.626], color="blue red", name="Arrows_13.579000473_7")

cluster_dict["13.579000473"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.4997064005), float(6.15373323095), float(-12.7304530467), float(1.0)]


cluster_dict["13.579000473"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.8), float(7.0), float(-11.4), float(1.0)]


cluster_dict["13.579000473"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(33.0939473219), float(-0.884017927955), float(-9.63851353317), float(1.0)]


cluster_dict["13.579000473"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(8.0), float(-12.5), float(1.0)]


cluster_dict["13.579000473"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(39.2236921289), float(5.56844039466), float(-9.12958121532), float(1.0)]


cluster_dict["13.579000473"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(6.0), float(-10.5), float(1.0)]

cluster_dict["13.579000473_arrows"] += cgo_arrow([36.5,6.0,-10.5], [33.693,5.068,-9.683], color="red blue", name="Arrows_13.579000473_8")

cmd.load_cgo(cluster_dict["13.579000473"], "Features_13.579000473", 1)
cmd.load_cgo(cluster_dict["13.579000473_arrows"], "Arrows_13.579000473")
cmd.set("transparency", 0.2,"Features_13.579000473")
cmd.group("Pharmacophore_13.579000473", members="Features_13.579000473")
cmd.group("Pharmacophore_13.579000473", members="Arrows_13.579000473")

if dirpath:
    f = join(dirpath, "label_threshold_13.579000473.mol2")
else:
    f = "label_threshold_13.579000473.mol2"

cmd.load(f, 'label_threshold_13.579000473')
cmd.hide('everything', 'label_threshold_13.579000473')
cmd.label("label_threshold_13.579000473", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.579000473', members= 'label_threshold_13.579000473')
