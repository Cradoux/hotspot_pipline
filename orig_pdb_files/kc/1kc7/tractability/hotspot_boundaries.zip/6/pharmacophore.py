
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.2839999199":[], "14.2839999199_arrows":[]}

cluster_dict["14.2839999199"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(10.0), float(-34.0), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([27.5,10.0,-34.0], [26.257,12.933,-32.801], color="blue red", name="Arrows_14.2839999199_1")

cluster_dict["14.2839999199"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(10.0), float(-37.5), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([27.0,10.0,-37.5], [25.878,8.199,-38.518], color="blue red", name="Arrows_14.2839999199_2")

cluster_dict["14.2839999199"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(31.0), float(10.0), float(-30.5), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([31.0,10.0,-30.5], [27.36,9.822,-28.982], color="blue red", name="Arrows_14.2839999199_3")

cluster_dict["14.2839999199"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(32.5), float(15.0), float(-32.5), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([32.5,15.0,-32.5], [35.064,16.748,-31.789], color="blue red", name="Arrows_14.2839999199_4")

cluster_dict["14.2839999199"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(15.5602840031), float(4.01430399498), float(-25.1611819989), float(1.0)]


cluster_dict["14.2839999199"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(18.3739704751), float(2.8583845611), float(-25.8925464539), float(1.0)]


cluster_dict["14.2839999199"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(20.5252740104), float(13.6785852336), float(-30.5730124156), float(1.0)]


cluster_dict["14.2839999199"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(24.8039993419), float(2.39558575163), float(-34.8006883022), float(1.0)]


cluster_dict["14.2839999199"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(30.1899577109), float(11.1510877904), float(-33.7557407051), float(1.0)]


cluster_dict["14.2839999199"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(16.0), float(-31.0), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([20.5,16.0,-31.0], [20.697,19.878,-30.934], color="red blue", name="Arrows_14.2839999199_5")

cluster_dict["14.2839999199"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(21.0), float(15.5), float(-33.5), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([21.0,15.5,-33.5], [23.42,17.057,-33.409], color="red blue", name="Arrows_14.2839999199_6")

cluster_dict["14.2839999199"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(7.5), float(-34.5), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([30.0,7.5,-34.5], [28.503,5.78,-35.679], color="red blue", name="Arrows_14.2839999199_7")

cluster_dict["14.2839999199"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(15.0), float(-30.5), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([30.0,15.0,-30.5], [29.452,18.335,-31.502], color="red blue", name="Arrows_14.2839999199_8")

cluster_dict["14.2839999199"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(15.0), float(-30.5), float(1.0)]

cluster_dict["14.2839999199_arrows"] += cgo_arrow([30.0,15.0,-30.5], [29.452,18.335,-31.502], color="red blue", name="Arrows_14.2839999199_9")

cmd.load_cgo(cluster_dict["14.2839999199"], "Features_14.2839999199", 1)
cmd.load_cgo(cluster_dict["14.2839999199_arrows"], "Arrows_14.2839999199")
cmd.set("transparency", 0.2,"Features_14.2839999199")
cmd.group("Pharmacophore_14.2839999199", members="Features_14.2839999199")
cmd.group("Pharmacophore_14.2839999199", members="Arrows_14.2839999199")

if dirpath:
    f = join(dirpath, "label_threshold_14.2839999199.mol2")
else:
    f = "label_threshold_14.2839999199.mol2"

cmd.load(f, 'label_threshold_14.2839999199')
cmd.hide('everything', 'label_threshold_14.2839999199')
cmd.label("label_threshold_14.2839999199", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.2839999199', members= 'label_threshold_14.2839999199')
