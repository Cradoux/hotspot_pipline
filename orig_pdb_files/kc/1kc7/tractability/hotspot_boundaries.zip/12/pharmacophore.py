
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.4709997177":[], "13.4709997177_arrows":[]}

cluster_dict["13.4709997177"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.5), float(9.0), float(-14.0), float(1.0)]

cluster_dict["13.4709997177_arrows"] += cgo_arrow([24.5,9.0,-14.0], [22.615,11.131,-15.816], color="blue red", name="Arrows_13.4709997177_1")

cluster_dict["13.4709997177"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(3.5), float(-13.5), float(1.0)]

cluster_dict["13.4709997177_arrows"] += cgo_arrow([27.0,3.5,-13.5], [25.564,1.866,-16.048], color="blue red", name="Arrows_13.4709997177_2")

cluster_dict["13.4709997177"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(11.0), float(-18.5), float(1.0)]

cluster_dict["13.4709997177_arrows"] += cgo_arrow([27.5,11.0,-18.5], [25.291,13.09,-18.48], color="blue red", name="Arrows_13.4709997177_3")

cluster_dict["13.4709997177"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.0), float(9.5), float(-13.0), float(1.0)]

cluster_dict["13.4709997177_arrows"] += cgo_arrow([29.0,9.5,-13.0], [30.129,7.657,-14.523], color="blue red", name="Arrows_13.4709997177_4")

cluster_dict["13.4709997177"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(3.5), float(-13.0), float(1.0)]

cluster_dict["13.4709997177_arrows"] += cgo_arrow([30.5,3.5,-13.0], [30.724,3.981,-15.898], color="blue red", name="Arrows_13.4709997177_5")

cluster_dict["13.4709997177"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(14.7919923704), float(2.94441467867), float(-23.2558744251), float(1.0)]


cluster_dict["13.4709997177"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(17.9791649224), float(10.6206132726), float(-11.1845092282), float(1.0)]


cluster_dict["13.4709997177"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(18.2100452111), float(2.30523495221), float(-25.8819094404), float(1.0)]


cluster_dict["13.4709997177"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.2412757005), float(9.8311117214), float(-14.5112946889), float(1.0)]


cluster_dict["13.4709997177"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(24.0879946273), float(11.3333892833), float(-14.4210342246), float(1.0)]


cluster_dict["13.4709997177"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(27.8221112005), float(10.3059968621), float(-23.058168882), float(1.0)]


cluster_dict["13.4709997177"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(30.0554071364), float(1.58982395583), float(-11.9614392694), float(1.0)]


cluster_dict["13.4709997177"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(9.5), float(-21.0), float(1.0)]

cluster_dict["13.4709997177_arrows"] += cgo_arrow([26.0,9.5,-21.0], [23.813,11.613,-19.373], color="red blue", name="Arrows_13.4709997177_6")

cluster_dict["13.4709997177"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(10.5), float(-22.0), float(1.0)]

cluster_dict["13.4709997177_arrows"] += cgo_arrow([28.0,10.5,-22.0], [26.191,13.098,-22.189], color="red blue", name="Arrows_13.4709997177_7")

cmd.load_cgo(cluster_dict["13.4709997177"], "Features_13.4709997177", 1)
cmd.load_cgo(cluster_dict["13.4709997177_arrows"], "Arrows_13.4709997177")
cmd.set("transparency", 0.2,"Features_13.4709997177")
cmd.group("Pharmacophore_13.4709997177", members="Features_13.4709997177")
cmd.group("Pharmacophore_13.4709997177", members="Arrows_13.4709997177")

if dirpath:
    f = join(dirpath, "label_threshold_13.4709997177.mol2")
else:
    f = "label_threshold_13.4709997177.mol2"

cmd.load(f, 'label_threshold_13.4709997177')
cmd.hide('everything', 'label_threshold_13.4709997177')
cmd.label("label_threshold_13.4709997177", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.4709997177', members= 'label_threshold_13.4709997177')
