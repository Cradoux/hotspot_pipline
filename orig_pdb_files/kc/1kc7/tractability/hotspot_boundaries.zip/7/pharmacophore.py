
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.1510000229":[], "14.1510000229_arrows":[]}

cluster_dict["14.1510000229"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(3.5), float(-13.5), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([27.0,3.5,-13.5], [25.564,1.866,-16.048], color="blue red", name="Arrows_14.1510000229_1")

cluster_dict["14.1510000229"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(10.0), float(-13.0), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([29.5,10.0,-13.0], [30.129,7.657,-14.523], color="blue red", name="Arrows_14.1510000229_2")

cluster_dict["14.1510000229"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(3.5), float(-13.0), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([30.5,3.5,-13.0], [30.724,3.981,-15.898], color="blue red", name="Arrows_14.1510000229_3")

cluster_dict["14.1510000229"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(35.0), float(0.5), float(-9.0), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([35.0,0.5,-9.0], [37.234,0.497,-7.21], color="blue red", name="Arrows_14.1510000229_4")

cluster_dict["14.1510000229"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.0), float(1.5), float(-11.5), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([33.0,1.5,-11.5], [32.955,-0.155,-14.973], color="blue red", name="Arrows_14.1510000229_5")

cluster_dict["14.1510000229"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(27.4900218989), float(9.3137254336), float(-12.7802427545), float(1.0)]


cluster_dict["14.1510000229"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(32.9909044295), float(-0.557912329366), float(-9.82485130433), float(1.0)]


cluster_dict["14.1510000229"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(39.8654915103), float(6.5498225685), float(-8.78921525031), float(1.0)]


cluster_dict["14.1510000229"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(44.912008325), float(7.7916346073), float(-16.4200540805), float(1.0)]


cluster_dict["14.1510000229"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(10.0), float(-13.5), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([29.5,10.0,-13.5], [32.505,10.662,-12.636], color="red blue", name="Arrows_14.1510000229_6")

cluster_dict["14.1510000229"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(10.0), float(-13.5), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([29.5,10.0,-13.5], [32.505,10.662,-12.636], color="red blue", name="Arrows_14.1510000229_7")

cluster_dict["14.1510000229"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(6.0), float(-10.5), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([36.5,6.0,-10.5], [33.693,5.068,-9.683], color="red blue", name="Arrows_14.1510000229_8")

cluster_dict["14.1510000229"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(43.5), float(7.0), float(-14.5), float(1.0)]

cluster_dict["14.1510000229_arrows"] += cgo_arrow([43.5,7.0,-14.5], [43.481,4.46,-13.067], color="red blue", name="Arrows_14.1510000229_9")

cmd.load_cgo(cluster_dict["14.1510000229"], "Features_14.1510000229", 1)
cmd.load_cgo(cluster_dict["14.1510000229_arrows"], "Arrows_14.1510000229")
cmd.set("transparency", 0.2,"Features_14.1510000229")
cmd.group("Pharmacophore_14.1510000229", members="Features_14.1510000229")
cmd.group("Pharmacophore_14.1510000229", members="Arrows_14.1510000229")

if dirpath:
    f = join(dirpath, "label_threshold_14.1510000229.mol2")
else:
    f = "label_threshold_14.1510000229.mol2"

cmd.load(f, 'label_threshold_14.1510000229')
cmd.hide('everything', 'label_threshold_14.1510000229')
cmd.label("label_threshold_14.1510000229", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.1510000229', members= 'label_threshold_14.1510000229')
