
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.1760005951":[], "16.1760005951_arrows":[]}

cluster_dict["16.1760005951"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.5), float(1.5), float(-34.0), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([24.5,1.5,-34.0], [26.171,2.494,-31.486], color="blue red", name="Arrows_16.1760005951_1")

cluster_dict["16.1760005951"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(-5.5), float(-36.5), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([29.5,-5.5,-36.5], [30.398,-6.958,-34.45], color="blue red", name="Arrows_16.1760005951_2")

cluster_dict["16.1760005951"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(32.0), float(3.5), float(-37.0), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([32.0,3.5,-37.0], [32.104,1.695,-34.881], color="blue red", name="Arrows_16.1760005951_3")

cluster_dict["16.1760005951"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(34.5), float(6.5), float(-41.5), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([34.5,6.5,-41.5], [33.786,9.103,-42.297], color="blue red", name="Arrows_16.1760005951_4")

cluster_dict["16.1760005951"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.5), float(3.5), float(-42.0), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([33.5,3.5,-42.0], [30.388,4.44,-42.566], color="blue red", name="Arrows_16.1760005951_5")

cluster_dict["16.1760005951"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(2.5), float(-43.5), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([36.5,2.5,-43.5], [38.722,3.854,-44.392], color="blue red", name="Arrows_16.1760005951_6")

cluster_dict["16.1760005951"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(37.0), float(5.5), float(-40.0), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([37.0,5.5,-40.0], [38.1,7.79,-41.551], color="blue red", name="Arrows_16.1760005951_7")

cluster_dict["16.1760005951"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(30.0867257132), float(-2.88805050218), float(-37.3847165677), float(1.0)]


cluster_dict["16.1760005951"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(32.9513575424), float(5.51057666049), float(-39.0850243626), float(1.0)]


cluster_dict["16.1760005951"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(7.5), float(-34.5), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([30.5,7.5,-34.5], [28.503,5.78,-35.679], color="red blue", name="Arrows_16.1760005951_8")

cluster_dict["16.1760005951"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(33.5), float(3.0), float(-44.0), float(1.0)]

cluster_dict["16.1760005951_arrows"] += cgo_arrow([33.5,3.0,-44.0], [30.965,4.679,-44.712], color="red blue", name="Arrows_16.1760005951_9")

cmd.load_cgo(cluster_dict["16.1760005951"], "Features_16.1760005951", 1)
cmd.load_cgo(cluster_dict["16.1760005951_arrows"], "Arrows_16.1760005951")
cmd.set("transparency", 0.2,"Features_16.1760005951")
cmd.group("Pharmacophore_16.1760005951", members="Features_16.1760005951")
cmd.group("Pharmacophore_16.1760005951", members="Arrows_16.1760005951")

if dirpath:
    f = join(dirpath, "label_threshold_16.1760005951.mol2")
else:
    f = "label_threshold_16.1760005951.mol2"

cmd.load(f, 'label_threshold_16.1760005951')
cmd.hide('everything', 'label_threshold_16.1760005951')
cmd.label("label_threshold_16.1760005951", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.1760005951', members= 'label_threshold_16.1760005951')
