
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.2910003662":[], "17.2910003662_arrows":[]}

cluster_dict["17.2910003662"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.5), float(1.5), float(-34.0), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([24.5,1.5,-34.0], [26.171,2.494,-31.486], color="blue red", name="Arrows_17.2910003662_1")

cluster_dict["17.2910003662"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(10.0), float(-34.0), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([27.5,10.0,-34.0], [26.257,12.933,-32.801], color="blue red", name="Arrows_17.2910003662_2")

cluster_dict["17.2910003662"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(10.5), float(-32.5), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([28.0,10.5,-32.5], [26.257,12.933,-32.801], color="blue red", name="Arrows_17.2910003662_3")

cluster_dict["17.2910003662"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(31.0), float(10.0), float(-30.5), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([31.0,10.0,-30.5], [27.36,9.822,-28.982], color="blue red", name="Arrows_17.2910003662_4")

cluster_dict["17.2910003662"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(32.0), float(3.5), float(-37.0), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([32.0,3.5,-37.0], [32.104,1.695,-34.881], color="blue red", name="Arrows_17.2910003662_5")

cluster_dict["17.2910003662"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.5), float(3.5), float(-42.0), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([33.5,3.5,-42.0], [30.388,4.44,-42.566], color="blue red", name="Arrows_17.2910003662_6")

cluster_dict["17.2910003662"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(32.9143862897), float(10.0372706189), float(-36.1100660116), float(1.0)]


cluster_dict["17.2910003662"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(35.0), float(14.5), float(-25.75), float(1.0)]


cluster_dict["17.2910003662"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(16.0), float(-31.0), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([20.5,16.0,-31.0], [20.697,19.878,-30.934], color="red blue", name="Arrows_17.2910003662_7")

cluster_dict["17.2910003662"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.5), float(7.5), float(-34.5), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([30.5,7.5,-34.5], [28.503,5.78,-35.679], color="red blue", name="Arrows_17.2910003662_8")

cluster_dict["17.2910003662"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(33.0), float(13.0), float(-28.5), float(1.0)]

cluster_dict["17.2910003662_arrows"] += cgo_arrow([33.0,13.0,-28.5], [32.581,16.518,-27.932], color="red blue", name="Arrows_17.2910003662_9")

cmd.load_cgo(cluster_dict["17.2910003662"], "Features_17.2910003662", 1)
cmd.load_cgo(cluster_dict["17.2910003662_arrows"], "Arrows_17.2910003662")
cmd.set("transparency", 0.2,"Features_17.2910003662")
cmd.group("Pharmacophore_17.2910003662", members="Features_17.2910003662")
cmd.group("Pharmacophore_17.2910003662", members="Arrows_17.2910003662")

if dirpath:
    f = join(dirpath, "label_threshold_17.2910003662.mol2")
else:
    f = "label_threshold_17.2910003662.mol2"

cmd.load(f, 'label_threshold_17.2910003662')
cmd.hide('everything', 'label_threshold_17.2910003662')
cmd.label("label_threshold_17.2910003662", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.2910003662', members= 'label_threshold_17.2910003662')
