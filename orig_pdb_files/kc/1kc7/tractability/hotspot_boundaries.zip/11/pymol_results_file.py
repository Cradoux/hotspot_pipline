
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_11.0.mol2")
else:
    f = "label_threshold_11.0.mol2"

cmd.load(f, 'label_threshold_11.0')
cmd.hide('everything', 'label_threshold_11.0')
cmd.label("label_threshold_11.0", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [11.0]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"13.513999939":[], "13.513999939_arrows":[]}

cluster_dict["13.513999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(25.0), float(10.0), float(-14.5), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([25.0,10.0,-14.5], [22.615,11.131,-15.816], color="blue red", name="Arrows_13.513999939_1")

cluster_dict["13.513999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.5), float(18.0), float(-16.5), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([24.5,18.0,-16.5], [21.965,15.819,-16.753], color="blue red", name="Arrows_13.513999939_2")

cluster_dict["13.513999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(25.0), float(15.0), float(-14.0), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([25.0,15.0,-14.0], [21.438,14.463,-13.601], color="blue red", name="Arrows_13.513999939_3")

cluster_dict["13.513999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(25.0), float(10.0), float(-14.5), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([25.0,10.0,-14.5], [22.615,11.131,-15.816], color="blue red", name="Arrows_13.513999939_4")

cluster_dict["13.513999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(10.0), float(-13.0), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([29.5,10.0,-13.0], [30.129,7.657,-14.523], color="blue red", name="Arrows_13.513999939_5")

cluster_dict["13.513999939"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(29.5), float(19.0), float(-15.5), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([29.5,19.0,-15.5], [28.582,16.633,-14.757], color="blue red", name="Arrows_13.513999939_6")

cluster_dict["13.513999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(16.2574086929), float(21.4994176877), float(-10.5639713025), float(1.0)]


cluster_dict["13.513999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(17.778336332), float(11.8346477231), float(-11.1327536583), float(1.0)]


cluster_dict["13.513999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(20.125), float(9.625), float(-9.875), float(1.0)]


cluster_dict["13.513999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.7883294568), float(11.6693070681), float(-15.1034155519), float(1.0)]


cluster_dict["13.513999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(24.0879946273), float(11.3333892833), float(-14.4210342246), float(1.0)]


cluster_dict["13.513999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(29.1261266924), float(13.4731272176), float(-19.4139966071), float(1.0)]


cluster_dict["13.513999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(28.7951499191), float(10.7951499191), float(-19.0167783731), float(1.0)]


cluster_dict["13.513999939"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(32.8040053333), float(20.061087064), float(-15.3229776404), float(1.0)]


cluster_dict["13.513999939"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(10.5), float(-19.5), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([26.0,10.5,-19.5], [23.813,11.613,-19.373], color="red blue", name="Arrows_13.513999939_7")

cluster_dict["13.513999939"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(12.5), float(-21.5), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([28.0,12.5,-21.5], [26.191,13.098,-22.189], color="red blue", name="Arrows_13.513999939_8")

cluster_dict["13.513999939"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(29.0), float(10.5), float(-12.0), float(1.0)]

cluster_dict["13.513999939_arrows"] += cgo_arrow([29.0,10.5,-12.0], [29.581,9.727,-9.209], color="red blue", name="Arrows_13.513999939_9")

cmd.load_cgo(cluster_dict["13.513999939"], "Features_13.513999939", 1)
cmd.load_cgo(cluster_dict["13.513999939_arrows"], "Arrows_13.513999939")
cmd.set("transparency", 0.2,"Features_13.513999939")
cmd.group("Pharmacophore_13.513999939", members="Features_13.513999939")
cmd.group("Pharmacophore_13.513999939", members="Arrows_13.513999939")

if dirpath:
    f = join(dirpath, "label_threshold_13.513999939.mol2")
else:
    f = "label_threshold_13.513999939.mol2"

cmd.load(f, 'label_threshold_13.513999939')
cmd.hide('everything', 'label_threshold_13.513999939')
cmd.label("label_threshold_13.513999939", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.513999939', members= 'label_threshold_13.513999939')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
