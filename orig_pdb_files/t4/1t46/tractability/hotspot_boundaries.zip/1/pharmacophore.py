
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.8024997711":[], "16.8024997711_arrows":[]}

cluster_dict["16.8024997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.5), float(25.5), float(46.0), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([24.5,25.5,46.0], [24.992,22.671,45.425], color="blue red", name="Arrows_16.8024997711_1")

cluster_dict["16.8024997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(23.5), float(45.0), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([27.5,23.5,45.0], [24.992,22.671,45.425], color="blue red", name="Arrows_16.8024997711_2")

cluster_dict["16.8024997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.0), float(23.5), float(49.0), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([33.0,23.5,49.0], [33.792,20.626,47.987], color="blue red", name="Arrows_16.8024997711_3")

cluster_dict["16.8024997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.5971243077), float(26.0312835076), float(40.6655188582), float(1.0)]


cluster_dict["16.8024997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(33.7), float(24.2), float(49.5), float(1.0)]


cluster_dict["16.8024997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(26.0), float(31.5), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([24.0,26.0,31.5], [26.885,27.06,28.588], color="red blue", name="Arrows_16.8024997711_4")

cluster_dict["16.8024997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(24.5), float(44.0), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([26.0,24.5,44.0], [24.992,22.671,45.425], color="red blue", name="Arrows_16.8024997711_5")

cluster_dict["16.8024997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(26.5), float(41.0), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([27.0,26.5,41.0], [28.183,26.981,38.218], color="red blue", name="Arrows_16.8024997711_6")

cluster_dict["16.8024997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(24.5), float(44.0), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([26.0,24.5,44.0], [24.992,22.671,45.425], color="red blue", name="Arrows_16.8024997711_7")

cluster_dict["16.8024997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(28.0), float(43.0), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([28.0,28.0,43.0], [24.637,29.939,41.447], color="red blue", name="Arrows_16.8024997711_8")

cluster_dict["16.8024997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(31.0), float(23.0), float(47.5), float(1.0)]

cluster_dict["16.8024997711_arrows"] += cgo_arrow([31.0,23.0,47.5], [30.864,20.045,47.642], color="red blue", name="Arrows_16.8024997711_9")

cmd.load_cgo(cluster_dict["16.8024997711"], "Features_16.8024997711", 1)
cmd.load_cgo(cluster_dict["16.8024997711_arrows"], "Arrows_16.8024997711")
cmd.set("transparency", 0.2,"Features_16.8024997711")
cmd.group("Pharmacophore_16.8024997711", members="Features_16.8024997711")
cmd.group("Pharmacophore_16.8024997711", members="Arrows_16.8024997711")

if dirpath:
    f = join(dirpath, "label_threshold_16.8024997711.mol2")
else:
    f = "label_threshold_16.8024997711.mol2"

cmd.load(f, 'label_threshold_16.8024997711')
cmd.hide('everything', 'label_threshold_16.8024997711')
cmd.label("label_threshold_16.8024997711", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.8024997711', members= 'label_threshold_16.8024997711')
