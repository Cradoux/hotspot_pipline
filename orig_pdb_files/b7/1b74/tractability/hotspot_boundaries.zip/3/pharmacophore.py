
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.7580003738":[], "13.7580003738_arrows":[]}

cluster_dict["13.7580003738"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(20.0), float(34.5), float(29.5), float(1.0)]

cluster_dict["13.7580003738_arrows"] += cgo_arrow([20.0,34.5,29.5], [18.088,33.463,29.934], color="blue red", name="Arrows_13.7580003738_1")

cluster_dict["13.7580003738"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(27.5), float(24.0), float(1.0)]

cluster_dict["13.7580003738_arrows"] += cgo_arrow([20.5,27.5,24.0], [20.72,28.331,26.689], color="blue red", name="Arrows_13.7580003738_2")

cluster_dict["13.7580003738"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(34.0), float(27.0), float(1.0)]

cluster_dict["13.7580003738_arrows"] += cgo_arrow([24.0,34.0,27.0], [26.805,36.028,27.954], color="blue red", name="Arrows_13.7580003738_3")

cluster_dict["13.7580003738"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(16.5625), float(37.125), float(27.1875), float(1.0)]


cluster_dict["13.7580003738"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.3945437116), float(28.4503163434), float(21.5234964288), float(1.0)]


cluster_dict["13.7580003738"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(34.5), float(23.5), float(1.0)]

cluster_dict["13.7580003738_arrows"] += cgo_arrow([26.5,34.5,23.5], [28.493,36.168,24.374], color="red blue", name="Arrows_13.7580003738_4")

cluster_dict["13.7580003738"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.5), float(34.5), float(23.5), float(1.0)]

cluster_dict["13.7580003738_arrows"] += cgo_arrow([26.5,34.5,23.5], [28.493,36.168,24.374], color="red blue", name="Arrows_13.7580003738_5")

cmd.load_cgo(cluster_dict["13.7580003738"], "Features_13.7580003738", 1)
cmd.load_cgo(cluster_dict["13.7580003738_arrows"], "Arrows_13.7580003738")
cmd.set("transparency", 0.2,"Features_13.7580003738")
cmd.group("Pharmacophore_13.7580003738", members="Features_13.7580003738")
cmd.group("Pharmacophore_13.7580003738", members="Arrows_13.7580003738")

if dirpath:
    f = join(dirpath, "label_threshold_13.7580003738.mol2")
else:
    f = "label_threshold_13.7580003738.mol2"

cmd.load(f, 'label_threshold_13.7580003738')
cmd.hide('everything', 'label_threshold_13.7580003738')
cmd.label("label_threshold_13.7580003738", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.7580003738', members= 'label_threshold_13.7580003738')
