
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.9029998779":[], "14.9029998779_arrows":[]}

cluster_dict["14.9029998779"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(67.0), float(4.0), float(6.0), float(1.0)]

cluster_dict["14.9029998779_arrows"] += cgo_arrow([67.0,4.0,6.0], [66.325,1.506,4.625], color="blue red", name="Arrows_14.9029998779_1")

cluster_dict["14.9029998779"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(72.747090928), float(3.45417296345), float(6.02288293499), float(1.0)]


cluster_dict["14.9029998779"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(67.7603550296), float(6.54733727811), float(-0.289940828402), float(1.0)]


cluster_dict["14.9029998779"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(66.0), float(7.0), float(1.5), float(1.0)]

cluster_dict["14.9029998779_arrows"] += cgo_arrow([66.0,7.0,1.5], [65.169,5.124,3.011], color="red blue", name="Arrows_14.9029998779_2")

cluster_dict["14.9029998779"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(69.5), float(6.0), float(5.0), float(1.0)]

cluster_dict["14.9029998779_arrows"] += cgo_arrow([69.5,6.0,5.0], [69.484,8.203,2.825], color="red blue", name="Arrows_14.9029998779_3")

cluster_dict["14.9029998779"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(71.5), float(7.0), float(7.0), float(1.0)]

cluster_dict["14.9029998779_arrows"] += cgo_arrow([71.5,7.0,7.0], [68.285,8.284,7.197], color="red blue", name="Arrows_14.9029998779_4")

cluster_dict["14.9029998779"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(72.0), float(0.5), float(6.5), float(1.0)]

cluster_dict["14.9029998779_arrows"] += cgo_arrow([72.0,0.5,6.5], [70.104,-0.114,3.575], color="red blue", name="Arrows_14.9029998779_5")

cluster_dict["14.9029998779"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(72.0), float(6.5), float(4.0), float(1.0)]

cluster_dict["14.9029998779_arrows"] += cgo_arrow([72.0,6.5,4.0], [70.289,6.272,1.864], color="red blue", name="Arrows_14.9029998779_6")

cmd.load_cgo(cluster_dict["14.9029998779"], "Features_14.9029998779", 1)
cmd.load_cgo(cluster_dict["14.9029998779_arrows"], "Arrows_14.9029998779")
cmd.set("transparency", 0.2,"Features_14.9029998779")
cmd.group("Pharmacophore_14.9029998779", members="Features_14.9029998779")
cmd.group("Pharmacophore_14.9029998779", members="Arrows_14.9029998779")

if dirpath:
    f = join(dirpath, "label_threshold_14.9029998779.mol2")
else:
    f = "label_threshold_14.9029998779.mol2"

cmd.load(f, 'label_threshold_14.9029998779')
cmd.hide('everything', 'label_threshold_14.9029998779')
cmd.label("label_threshold_14.9029998779", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.9029998779', members= 'label_threshold_14.9029998779')
