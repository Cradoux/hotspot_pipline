
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"12.0150003433":[], "12.0150003433_arrows":[]}

cluster_dict["12.0150003433"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(58.5), float(31.0), float(1.0)]

cluster_dict["12.0150003433_arrows"] += cgo_arrow([36.0,58.5,31.0], [35.99,56.42,29.615], color="blue red", name="Arrows_12.0150003433_1")

cluster_dict["12.0150003433"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(37.0), float(59.0), float(28.5), float(1.0)]

cluster_dict["12.0150003433_arrows"] += cgo_arrow([37.0,59.0,28.5], [35.99,56.42,29.615], color="blue red", name="Arrows_12.0150003433_2")

cluster_dict["12.0150003433"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(39.5), float(59.5), float(22.0), float(1.0)]

cluster_dict["12.0150003433_arrows"] += cgo_arrow([39.5,59.5,22.0], [38.072,61.49,21.108], color="blue red", name="Arrows_12.0150003433_3")

cluster_dict["12.0150003433"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(38.4254313924), float(59.4446001373), float(25.0120266979), float(1.0)]


cluster_dict["12.0150003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(34.0), float(60.0), float(27.5), float(1.0)]

cluster_dict["12.0150003433_arrows"] += cgo_arrow([34.0,60.0,27.5], [35.99,56.42,29.615], color="red blue", name="Arrows_12.0150003433_4")

cluster_dict["12.0150003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(39.0), float(59.0), float(29.0), float(1.0)]

cluster_dict["12.0150003433_arrows"] += cgo_arrow([39.0,59.0,29.0], [42.048,60.184,28.406], color="red blue", name="Arrows_12.0150003433_5")

cluster_dict["12.0150003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(39.0), float(59.0), float(29.0), float(1.0)]

cluster_dict["12.0150003433_arrows"] += cgo_arrow([39.0,59.0,29.0], [42.048,60.184,28.406], color="red blue", name="Arrows_12.0150003433_6")

cmd.load_cgo(cluster_dict["12.0150003433"], "Features_12.0150003433", 1)
cmd.load_cgo(cluster_dict["12.0150003433_arrows"], "Arrows_12.0150003433")
cmd.set("transparency", 0.2,"Features_12.0150003433")
cmd.group("Pharmacophore_12.0150003433", members="Features_12.0150003433")
cmd.group("Pharmacophore_12.0150003433", members="Arrows_12.0150003433")

if dirpath:
    f = join(dirpath, "label_threshold_12.0150003433.mol2")
else:
    f = "label_threshold_12.0150003433.mol2"

cmd.load(f, 'label_threshold_12.0150003433')
cmd.hide('everything', 'label_threshold_12.0150003433')
cmd.label("label_threshold_12.0150003433", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_12.0150003433', members= 'label_threshold_12.0150003433')
