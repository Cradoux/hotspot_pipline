
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.0909996033":[], "17.0909996033_arrows":[]}

cluster_dict["17.0909996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(24.5), float(28.5), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([15.5,24.5,28.5], [15.481,23.448,26.221], color="blue red", name="Arrows_17.0909996033_1")

cluster_dict["17.0909996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(24.5), float(28.0), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([17.0,24.5,28.0], [15.481,23.448,26.221], color="blue red", name="Arrows_17.0909996033_2")

cluster_dict["17.0909996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(22.0), float(19.5), float(26.5), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([22.0,19.5,26.5], [20.586,17.072,25.369], color="blue red", name="Arrows_17.0909996033_3")

cluster_dict["17.0909996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(23.5), float(27.5), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([24.0,23.5,27.5], [23.825,23.679,30.554], color="blue red", name="Arrows_17.0909996033_4")

cluster_dict["17.0909996033"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(29.5), float(25.0), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([25.5,29.5,25.0], [24.804,32.148,26.296], color="blue red", name="Arrows_17.0909996033_5")

cluster_dict["17.0909996033"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(21.7150717189), float(26.4788001982), float(26.7294506445), float(1.0)]


cluster_dict["17.0909996033"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.0), float(26.5), float(29.0), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([15.0,26.5,29.0], [14.267,27.323,25.392], color="red blue", name="Arrows_17.0909996033_6")

cluster_dict["17.0909996033"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.0), float(21.0), float(27.0), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([20.0,21.0,27.0], [19.863,20.032,28.99], color="red blue", name="Arrows_17.0909996033_7")

cluster_dict["17.0909996033"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(31.0), float(28.5), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([20.5,31.0,28.5], [22.1,33.173,28.772], color="red blue", name="Arrows_17.0909996033_8")

cluster_dict["17.0909996033"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(26.5), float(23.0), float(1.0)]

cluster_dict["17.0909996033_arrows"] += cgo_arrow([22.5,26.5,23.0], [21.419,24.54,21.082], color="red blue", name="Arrows_17.0909996033_9")

cmd.load_cgo(cluster_dict["17.0909996033"], "Features_17.0909996033", 1)
cmd.load_cgo(cluster_dict["17.0909996033_arrows"], "Arrows_17.0909996033")
cmd.set("transparency", 0.2,"Features_17.0909996033")
cmd.group("Pharmacophore_17.0909996033", members="Features_17.0909996033")
cmd.group("Pharmacophore_17.0909996033", members="Arrows_17.0909996033")

if dirpath:
    f = join(dirpath, "label_threshold_17.0909996033.mol2")
else:
    f = "label_threshold_17.0909996033.mol2"

cmd.load(f, 'label_threshold_17.0909996033')
cmd.hide('everything', 'label_threshold_17.0909996033')
cmd.label("label_threshold_17.0909996033", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.0909996033', members= 'label_threshold_17.0909996033')
