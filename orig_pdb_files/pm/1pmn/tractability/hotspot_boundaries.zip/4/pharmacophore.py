
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.7220001221":[], "15.7220001221_arrows":[]}

cluster_dict["15.7220001221"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(24.5), float(28.0), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([17.0,24.5,28.0], [15.481,23.448,26.221], color="blue red", name="Arrows_15.7220001221_1")

cluster_dict["15.7220001221"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.0), float(23.0), float(25.0), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([19.0,23.0,25.0], [20.129,22.061,22.222], color="blue red", name="Arrows_15.7220001221_2")

cluster_dict["15.7220001221"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(7.65729572299), float(26.5177653269), float(30.740019596), float(1.0)]


cluster_dict["15.7220001221"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(18.6485577843), float(27.3641257771), float(27.6354274012), float(1.0)]


cluster_dict["15.7220001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(10.0), float(28.0), float(28.5), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([10.0,28.0,28.5], [11.2,25.378,28.335], color="red blue", name="Arrows_15.7220001221_3")

cluster_dict["15.7220001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(10.5), float(29.0), float(30.0), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([10.5,29.0,30.0], [13.101,30.805,29.788], color="red blue", name="Arrows_15.7220001221_4")

cluster_dict["15.7220001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.0), float(26.5), float(29.0), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([15.0,26.5,29.0], [14.267,27.323,25.392], color="red blue", name="Arrows_15.7220001221_5")

cluster_dict["15.7220001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(28.0), float(25.5), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([17.5,28.0,25.5], [14.267,27.323,25.392], color="red blue", name="Arrows_15.7220001221_6")

cluster_dict["15.7220001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(21.0), float(27.0), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([19.5,21.0,27.0], [19.863,20.032,28.99], color="red blue", name="Arrows_15.7220001221_7")

cluster_dict["15.7220001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.0), float(31.5), float(29.0), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([20.0,31.5,29.0], [22.1,33.173,28.772], color="red blue", name="Arrows_15.7220001221_8")

cluster_dict["15.7220001221"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.0), float(31.5), float(29.0), float(1.0)]

cluster_dict["15.7220001221_arrows"] += cgo_arrow([20.0,31.5,29.0], [22.1,33.173,28.772], color="red blue", name="Arrows_15.7220001221_9")

cmd.load_cgo(cluster_dict["15.7220001221"], "Features_15.7220001221", 1)
cmd.load_cgo(cluster_dict["15.7220001221_arrows"], "Arrows_15.7220001221")
cmd.set("transparency", 0.2,"Features_15.7220001221")
cmd.group("Pharmacophore_15.7220001221", members="Features_15.7220001221")
cmd.group("Pharmacophore_15.7220001221", members="Arrows_15.7220001221")

if dirpath:
    f = join(dirpath, "label_threshold_15.7220001221.mol2")
else:
    f = "label_threshold_15.7220001221.mol2"

cmd.load(f, 'label_threshold_15.7220001221')
cmd.hide('everything', 'label_threshold_15.7220001221')
cmd.label("label_threshold_15.7220001221", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.7220001221', members= 'label_threshold_15.7220001221')
