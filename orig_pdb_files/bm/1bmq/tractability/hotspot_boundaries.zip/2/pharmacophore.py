
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"9.60999965668":[], "9.60999965668_arrows":[]}

cluster_dict["9.60999965668"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(34.5), float(63.0), float(7.0), float(1.0)]

cluster_dict["9.60999965668_arrows"] += cgo_arrow([34.5,63.0,7.0], [37.541,62.959,7.026], color="blue red", name="Arrows_9.60999965668_1")

cluster_dict["9.60999965668"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(62.5), float(2.0), float(1.0)]

cluster_dict["9.60999965668_arrows"] += cgo_arrow([36.0,62.5,2.0], [36.053,60.45,-0.501], color="blue red", name="Arrows_9.60999965668_2")

cluster_dict["9.60999965668"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(32.6925991402), float(62.4146726398), float(4.7620542119), float(1.0)]


cluster_dict["9.60999965668"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(38.8520681456), float(58.0), float(0.0901466618677), float(1.0)]


cluster_dict["9.60999965668"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(65.0), float(3.5), float(1.0)]

cluster_dict["9.60999965668_arrows"] += cgo_arrow([36.5,65.0,3.5], [38.006,67.0,1.792], color="red blue", name="Arrows_9.60999965668_3")

cluster_dict["9.60999965668"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(35.0), float(61.5), float(2.0), float(1.0)]

cluster_dict["9.60999965668_arrows"] += cgo_arrow([35.0,61.5,2.0], [33.884,59.974,-0.824], color="red blue", name="Arrows_9.60999965668_4")

cmd.load_cgo(cluster_dict["9.60999965668"], "Features_9.60999965668", 1)
cmd.load_cgo(cluster_dict["9.60999965668_arrows"], "Arrows_9.60999965668")
cmd.set("transparency", 0.2,"Features_9.60999965668")
cmd.group("Pharmacophore_9.60999965668", members="Features_9.60999965668")
cmd.group("Pharmacophore_9.60999965668", members="Arrows_9.60999965668")

if dirpath:
    f = join(dirpath, "label_threshold_9.60999965668.mol2")
else:
    f = "label_threshold_9.60999965668.mol2"

cmd.load(f, 'label_threshold_9.60999965668')
cmd.hide('everything', 'label_threshold_9.60999965668')
cmd.label("label_threshold_9.60999965668", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_9.60999965668', members= 'label_threshold_9.60999965668')
