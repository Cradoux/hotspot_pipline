
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"10.9989995956":[], "10.9989995956_arrows":[]}

cluster_dict["10.9989995956"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-63.5), float(-25.0), float(8.5), float(1.0)]

cluster_dict["10.9989995956_arrows"] += cgo_arrow([-63.5,-25.0,8.5], [-60.695,-25.422,9.101], color="blue red", name="Arrows_10.9989995956_1")

cluster_dict["10.9989995956"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-64.6215491661), float(-23.1440237005), float(6.21166859727), float(1.0)]


cluster_dict["10.9989995956"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-65.5), float(-22.0), float(3.0), float(1.0)]

cluster_dict["10.9989995956_arrows"] += cgo_arrow([-65.5,-22.0,3.0], [-67.529,-19.586,2.278], color="red blue", name="Arrows_10.9989995956_2")

cluster_dict["10.9989995956"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-62.5), float(-26.5), float(7.5), float(1.0)]

cluster_dict["10.9989995956_arrows"] += cgo_arrow([-62.5,-26.5,7.5], [-63.622,-28.096,5.158], color="red blue", name="Arrows_10.9989995956_3")

cmd.load_cgo(cluster_dict["10.9989995956"], "Features_10.9989995956", 1)
cmd.load_cgo(cluster_dict["10.9989995956_arrows"], "Arrows_10.9989995956")
cmd.set("transparency", 0.2,"Features_10.9989995956")
cmd.group("Pharmacophore_10.9989995956", members="Features_10.9989995956")
cmd.group("Pharmacophore_10.9989995956", members="Arrows_10.9989995956")

if dirpath:
    f = join(dirpath, "label_threshold_10.9989995956.mol2")
else:
    f = "label_threshold_10.9989995956.mol2"

cmd.load(f, 'label_threshold_10.9989995956')
cmd.hide('everything', 'label_threshold_10.9989995956')
cmd.label("label_threshold_10.9989995956", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_10.9989995956', members= 'label_threshold_10.9989995956')
