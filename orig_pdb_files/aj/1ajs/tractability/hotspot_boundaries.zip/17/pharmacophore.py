
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"11.6500000954":[], "11.6500000954_arrows":[]}

cluster_dict["11.6500000954"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-46.0), float(-12.5), float(-12.5), float(1.0)]

cluster_dict["11.6500000954_arrows"] += cgo_arrow([-46.0,-12.5,-12.5], [-47.399,-9.957,-13.153], color="blue red", name="Arrows_11.6500000954_1")

cluster_dict["11.6500000954"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-42.5), float(-15.0), float(-9.0), float(1.0)]

cluster_dict["11.6500000954_arrows"] += cgo_arrow([-42.5,-15.0,-9.0], [-43.537,-16.731,-9.097], color="blue red", name="Arrows_11.6500000954_2")

cluster_dict["11.6500000954"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-43.4646941459), float(-11.5691868735), float(-13.9507856138), float(1.0)]


cluster_dict["11.6500000954"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-42.9598580415), float(-16.1190263759), float(-19.7553026186), float(1.0)]


cluster_dict["11.6500000954"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-46.0), float(-16.0), float(-9.0), float(1.0)]

cluster_dict["11.6500000954_arrows"] += cgo_arrow([-46.0,-16.0,-9.0], [-43.537,-16.731,-9.097], color="red blue", name="Arrows_11.6500000954_3")

cluster_dict["11.6500000954"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-40.5), float(-11.0), float(-12.5), float(1.0)]

cluster_dict["11.6500000954_arrows"] += cgo_arrow([-40.5,-11.0,-12.5], [-39.821,-14.092,-14.343], color="red blue", name="Arrows_11.6500000954_4")

cmd.load_cgo(cluster_dict["11.6500000954"], "Features_11.6500000954", 1)
cmd.load_cgo(cluster_dict["11.6500000954_arrows"], "Arrows_11.6500000954")
cmd.set("transparency", 0.2,"Features_11.6500000954")
cmd.group("Pharmacophore_11.6500000954", members="Features_11.6500000954")
cmd.group("Pharmacophore_11.6500000954", members="Arrows_11.6500000954")

if dirpath:
    f = join(dirpath, "label_threshold_11.6500000954.mol2")
else:
    f = "label_threshold_11.6500000954.mol2"

cmd.load(f, 'label_threshold_11.6500000954')
cmd.hide('everything', 'label_threshold_11.6500000954')
cmd.label("label_threshold_11.6500000954", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_11.6500000954', members= 'label_threshold_11.6500000954')
