
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.5810003281":[], "14.5810003281_arrows":[]}

cluster_dict["14.5810003281"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(57.5), float(17.0), float(1.0)]

cluster_dict["14.5810003281_arrows"] += cgo_arrow([30.0,57.5,17.0], [29.056,56.897,15.143], color="blue red", name="Arrows_14.5810003281_1")

cluster_dict["14.5810003281"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(28.2224337841), float(58.4410854254), float(20.3392720342), float(1.0)]


cluster_dict["14.5810003281"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(63.0), float(20.5), float(1.0)]

cluster_dict["14.5810003281_arrows"] += cgo_arrow([28.5,63.0,20.5], [25.488,64.457,19.169], color="red blue", name="Arrows_14.5810003281_2")

cluster_dict["14.5810003281"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(29.0), float(59.5), float(17.5), float(1.0)]

cluster_dict["14.5810003281_arrows"] += cgo_arrow([29.0,59.5,17.5], [29.461,59.893,15.268], color="red blue", name="Arrows_14.5810003281_3")

cmd.load_cgo(cluster_dict["14.5810003281"], "Features_14.5810003281", 1)
cmd.load_cgo(cluster_dict["14.5810003281_arrows"], "Arrows_14.5810003281")
cmd.set("transparency", 0.2,"Features_14.5810003281")
cmd.group("Pharmacophore_14.5810003281", members="Features_14.5810003281")
cmd.group("Pharmacophore_14.5810003281", members="Arrows_14.5810003281")

if dirpath:
    f = join(dirpath, "label_threshold_14.5810003281.mol2")
else:
    f = "label_threshold_14.5810003281.mol2"

cmd.load(f, 'label_threshold_14.5810003281')
cmd.hide('everything', 'label_threshold_14.5810003281')
cmd.label("label_threshold_14.5810003281", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.5810003281', members= 'label_threshold_14.5810003281')
