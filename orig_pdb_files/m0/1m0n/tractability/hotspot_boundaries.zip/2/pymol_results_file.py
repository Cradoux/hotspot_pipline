
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_13.5.mol2")
else:
    f = "label_threshold_13.5.mol2"

cmd.load(f, 'label_threshold_13.5')
cmd.hide('everything', 'label_threshold_13.5')
cmd.label("label_threshold_13.5", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [13.5]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"14.1999998093":[], "14.1999998093_arrows":[]}

cluster_dict["14.1999998093"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(8.5), float(48.0), float(30.5), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([8.5,48.0,30.5], [6.903,49.386,28.3], color="blue red", name="Arrows_14.1999998093_1")

cluster_dict["14.1999998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(10.5466226769), float(50.9778157924), float(32.266763999), float(1.0)]


cluster_dict["14.1999998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(9.63553268743), float(42.3351705729), float(28.5430374556), float(1.0)]


cluster_dict["14.1999998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(11.8130540041), float(38.0209836191), float(18.2251644182), float(1.0)]


cluster_dict["14.1999998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(16.7834392587), float(49.5355418893), float(23.4477146961), float(1.0)]


cluster_dict["14.1999998093"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(25.1469282171), float(56.1167230082), float(21.7364278934), float(1.0)]


cluster_dict["14.1999998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(9.0), float(47.0), float(25.5), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([9.0,47.0,25.5], [7.61,46.423,23.631], color="red blue", name="Arrows_14.1999998093_2")

cluster_dict["14.1999998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(9.5), float(52.5), float(29.5), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([9.5,52.5,29.5], [7.675,53.976,27.475], color="red blue", name="Arrows_14.1999998093_3")

cluster_dict["14.1999998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(14.5), float(49.5), float(19.5), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([14.5,49.5,19.5], [13.87,48.102,17.509], color="red blue", name="Arrows_14.1999998093_4")

cluster_dict["14.1999998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.0), float(43.5), float(15.5), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([15.0,43.5,15.5], [12.884,44.157,16.767], color="red blue", name="Arrows_14.1999998093_5")

cluster_dict["14.1999998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(14.5), float(52.5), float(19.0), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([14.5,52.5,19.0], [14.391,54.985,20.064], color="red blue", name="Arrows_14.1999998093_6")

cluster_dict["14.1999998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(46.5), float(16.5), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([16.5,46.5,16.5], [13.87,48.102,17.509], color="red blue", name="Arrows_14.1999998093_7")

cluster_dict["14.1999998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(53.0), float(13.0), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([17.5,53.0,13.0], [17.796,54.621,11.551], color="red blue", name="Arrows_14.1999998093_8")

cluster_dict["14.1999998093"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(47.0), float(16.0), float(1.0)]

cluster_dict["14.1999998093_arrows"] += cgo_arrow([24.0,47.0,16.0], [23.609,46.125,13.689], color="red blue", name="Arrows_14.1999998093_9")

cmd.load_cgo(cluster_dict["14.1999998093"], "Features_14.1999998093", 1)
cmd.load_cgo(cluster_dict["14.1999998093_arrows"], "Arrows_14.1999998093")
cmd.set("transparency", 0.2,"Features_14.1999998093")
cmd.group("Pharmacophore_14.1999998093", members="Features_14.1999998093")
cmd.group("Pharmacophore_14.1999998093", members="Arrows_14.1999998093")

if dirpath:
    f = join(dirpath, "label_threshold_14.1999998093.mol2")
else:
    f = "label_threshold_14.1999998093.mol2"

cmd.load(f, 'label_threshold_14.1999998093')
cmd.hide('everything', 'label_threshold_14.1999998093')
cmd.label("label_threshold_14.1999998093", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.1999998093', members= 'label_threshold_14.1999998093')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
