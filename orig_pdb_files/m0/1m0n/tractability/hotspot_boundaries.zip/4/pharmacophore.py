
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.029999733":[], "14.029999733_arrows":[]}

cluster_dict["14.029999733"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(8.5), float(48.0), float(31.0), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([8.5,48.0,31.0], [10.691,46.223,32.917], color="blue red", name="Arrows_14.029999733_1")

cluster_dict["14.029999733"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(8.5), float(48.0), float(31.0), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([8.5,48.0,31.0], [10.691,46.223,32.917], color="blue red", name="Arrows_14.029999733_2")

cluster_dict["14.029999733"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(47.0), float(31.0), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([17.5,47.0,31.0], [19.253,49.535,30.637], color="blue red", name="Arrows_14.029999733_3")

cluster_dict["14.029999733"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(10.1082597901), float(51.0528100488), float(33.2701550528), float(1.0)]


cluster_dict["14.029999733"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(9.56101175825), float(42.5128776975), float(28.4222807974), float(1.0)]


cluster_dict["14.029999733"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(16.2538166464), float(48.0801179617), float(26.0585528729), float(1.0)]


cluster_dict["14.029999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(6.0), float(47.5), float(31.5), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([6.0,47.5,31.5], [4.478,47.927,28.43], color="red blue", name="Arrows_14.029999733_4")

cluster_dict["14.029999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(9.0), float(47.0), float(25.5), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([9.0,47.0,25.5], [7.61,46.423,23.631], color="red blue", name="Arrows_14.029999733_5")

cluster_dict["14.029999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(9.5), float(52.5), float(29.5), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([9.5,52.5,29.5], [7.675,53.976,27.475], color="red blue", name="Arrows_14.029999733_6")

cluster_dict["14.029999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(48.0), float(26.5), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([13.0,48.0,26.5], [13.665,46.492,23.997], color="red blue", name="Arrows_14.029999733_7")

cluster_dict["14.029999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.0), float(44.5), float(31.0), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([15.0,44.5,31.0], [13.536,44.497,33.984], color="red blue", name="Arrows_14.029999733_8")

cluster_dict["14.029999733"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.0), float(45.5), float(27.0), float(1.0)]

cluster_dict["14.029999733_arrows"] += cgo_arrow([17.0,45.5,27.0], [19.435,44.038,28.278], color="red blue", name="Arrows_14.029999733_9")

cmd.load_cgo(cluster_dict["14.029999733"], "Features_14.029999733", 1)
cmd.load_cgo(cluster_dict["14.029999733_arrows"], "Arrows_14.029999733")
cmd.set("transparency", 0.2,"Features_14.029999733")
cmd.group("Pharmacophore_14.029999733", members="Features_14.029999733")
cmd.group("Pharmacophore_14.029999733", members="Arrows_14.029999733")

if dirpath:
    f = join(dirpath, "label_threshold_14.029999733.mol2")
else:
    f = "label_threshold_14.029999733.mol2"

cmd.load(f, 'label_threshold_14.029999733')
cmd.hide('everything', 'label_threshold_14.029999733')
cmd.label("label_threshold_14.029999733", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.029999733', members= 'label_threshold_14.029999733')
