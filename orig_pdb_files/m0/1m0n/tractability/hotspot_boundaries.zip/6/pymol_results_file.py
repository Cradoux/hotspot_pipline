
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_12.0.mol2")
else:
    f = "label_threshold_12.0.mol2"

cmd.load(f, 'label_threshold_12.0')
cmd.hide('everything', 'label_threshold_12.0')
cmd.label("label_threshold_12.0", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [12.0]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"13.8030004501":[], "13.8030004501_arrows":[]}

cluster_dict["13.8030004501"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(12.5), float(53.5), float(25.0), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([12.5,53.5,25.0], [9.808,52.921,25.117], color="blue red", name="Arrows_13.8030004501_1")

cluster_dict["13.8030004501"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(51.5), float(25.0), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([22.5,51.5,25.0], [22.456,50.136,27.967], color="blue red", name="Arrows_13.8030004501_2")

cluster_dict["13.8030004501"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(11.7081391514), float(52.4065538629), float(31.6261024367), float(1.0)]


cluster_dict["13.8030004501"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(16.868873535), float(49.8463037256), float(24.0535246589), float(1.0)]


cluster_dict["13.8030004501"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(25.4334689226), float(58.1746042479), float(20.8304589141), float(1.0)]


cluster_dict["13.8030004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(9.5), float(52.5), float(29.5), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([9.5,52.5,29.5], [7.675,53.976,27.475], color="red blue", name="Arrows_13.8030004501_3")

cluster_dict["13.8030004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(48.0), float(26.5), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([13.0,48.0,26.5], [13.665,46.492,23.997], color="red blue", name="Arrows_13.8030004501_4")

cluster_dict["13.8030004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(52.0), float(25.5), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([13.0,52.0,25.5], [10.627,51.048,26.078], color="red blue", name="Arrows_13.8030004501_5")

cluster_dict["13.8030004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(14.5), float(49.5), float(19.5), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([14.5,49.5,19.5], [13.87,48.102,17.509], color="red blue", name="Arrows_13.8030004501_6")

cluster_dict["13.8030004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(14.0), float(53.5), float(22.0), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([14.0,53.5,22.0], [14.391,54.985,20.064], color="red blue", name="Arrows_13.8030004501_7")

cluster_dict["13.8030004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(53.5), float(21.5), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([15.5,53.5,21.5], [14.391,54.985,20.064], color="red blue", name="Arrows_13.8030004501_8")

cluster_dict["13.8030004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(53.0), float(13.0), float(1.0)]

cluster_dict["13.8030004501_arrows"] += cgo_arrow([17.5,53.0,13.0], [17.796,54.621,11.551], color="red blue", name="Arrows_13.8030004501_9")

cmd.load_cgo(cluster_dict["13.8030004501"], "Features_13.8030004501", 1)
cmd.load_cgo(cluster_dict["13.8030004501_arrows"], "Arrows_13.8030004501")
cmd.set("transparency", 0.2,"Features_13.8030004501")
cmd.group("Pharmacophore_13.8030004501", members="Features_13.8030004501")
cmd.group("Pharmacophore_13.8030004501", members="Arrows_13.8030004501")

if dirpath:
    f = join(dirpath, "label_threshold_13.8030004501.mol2")
else:
    f = "label_threshold_13.8030004501.mol2"

cmd.load(f, 'label_threshold_13.8030004501')
cmd.hide('everything', 'label_threshold_13.8030004501')
cmd.label("label_threshold_13.8030004501", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.8030004501', members= 'label_threshold_13.8030004501')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
