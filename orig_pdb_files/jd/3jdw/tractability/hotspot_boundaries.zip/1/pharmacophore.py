
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.6309995651":[], "13.6309995651_arrows":[]}

cluster_dict["13.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(46.0), float(73.5), float(14.5), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([46.0,73.5,14.5], [44.9,70.913,13.25], color="blue red", name="Arrows_13.6309995651_1")

cluster_dict["13.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(44.0), float(73.0), float(19.0), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([44.0,73.0,19.0], [42.775,75.507,19.924], color="blue red", name="Arrows_13.6309995651_2")

cluster_dict["13.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(46.0), float(73.5), float(14.5), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([46.0,73.5,14.5], [44.9,70.913,13.25], color="blue red", name="Arrows_13.6309995651_3")

cluster_dict["13.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(47.5), float(70.0), float(17.0), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([47.5,70.0,17.0], [49.527,70.997,19.052], color="blue red", name="Arrows_13.6309995651_4")

cluster_dict["13.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(47.0), float(80.0), float(21.0), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([47.0,80.0,21.0], [47.337,77.828,19.543], color="blue red", name="Arrows_13.6309995651_5")

cluster_dict["13.6309995651"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(47.5), float(81.0), float(24.5), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([47.5,81.0,24.5], [50.222,81.088,26.088], color="blue red", name="Arrows_13.6309995651_6")

cluster_dict["13.6309995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(38.1679747), float(72.893707006), float(8.81416075632), float(1.0)]


cluster_dict["13.6309995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(43.5494153858), float(81.9082845005), float(13.3695984721), float(1.0)]


cluster_dict["13.6309995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(45.4836703814), float(72.0240099425), float(16.2928234305), float(1.0)]


cluster_dict["13.6309995651"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(45.6736520546), float(81.6290606566), float(21.0710972221), float(1.0)]


cluster_dict["13.6309995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(45.0), float(73.5), float(17.5), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([45.0,73.5,17.5], [45.656,76.341,19.264], color="red blue", name="Arrows_13.6309995651_7")

cluster_dict["13.6309995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(44.0), float(77.5), float(16.0), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([44.0,77.5,16.0], [43.632,79.741,17.764], color="red blue", name="Arrows_13.6309995651_8")

cluster_dict["13.6309995651"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(81.0), float(21.5), float(1.0)]

cluster_dict["13.6309995651_arrows"] += cgo_arrow([48.0,81.0,21.5], [50.487,82.373,22.334], color="red blue", name="Arrows_13.6309995651_9")

cmd.load_cgo(cluster_dict["13.6309995651"], "Features_13.6309995651", 1)
cmd.load_cgo(cluster_dict["13.6309995651_arrows"], "Arrows_13.6309995651")
cmd.set("transparency", 0.2,"Features_13.6309995651")
cmd.group("Pharmacophore_13.6309995651", members="Features_13.6309995651")
cmd.group("Pharmacophore_13.6309995651", members="Arrows_13.6309995651")

if dirpath:
    f = join(dirpath, "label_threshold_13.6309995651.mol2")
else:
    f = "label_threshold_13.6309995651.mol2"

cmd.load(f, 'label_threshold_13.6309995651')
cmd.hide('everything', 'label_threshold_13.6309995651')
cmd.label("label_threshold_13.6309995651", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.6309995651', members= 'label_threshold_13.6309995651')
