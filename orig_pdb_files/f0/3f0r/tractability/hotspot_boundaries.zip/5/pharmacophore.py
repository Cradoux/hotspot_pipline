
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"10.0380001068":[], "10.0380001068_arrows":[]}

cluster_dict["10.0380001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.0), float(-6.5), float(6.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([33.0,-6.5,6.0], [31.839,-6.19,4.213], color="blue red", name="Arrows_10.0380001068_1")

cluster_dict["10.0380001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(34.0), float(-7.0), float(2.5), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([34.0,-7.0,2.5], [31.839,-6.19,4.213], color="blue red", name="Arrows_10.0380001068_2")

cluster_dict["10.0380001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(33.5), float(-3.5), float(2.5), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([33.5,-3.5,2.5], [31.597,-4.137,0.858], color="blue red", name="Arrows_10.0380001068_3")

cluster_dict["10.0380001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(-4.0), float(2.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([36.5,-4.0,2.0], [37.036,-1.381,0.495], color="blue red", name="Arrows_10.0380001068_4")

cluster_dict["10.0380001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(39.5), float(-4.5), float(3.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([39.5,-4.5,3.0], [38.748,-6.913,1.552], color="blue red", name="Arrows_10.0380001068_5")

cluster_dict["10.0380001068"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(34.4830329577), float(-11.5681629118), float(-4.93749746018), float(1.0)]


cluster_dict["10.0380001068"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(35.5998584569), float(-5.2805775259), float(2.75216303626), float(1.0)]


cluster_dict["10.0380001068"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(35.3222405683), float(-8.46711037727), float(-1.5), float(1.0)]


cluster_dict["10.0380001068"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(-10.7111234635), float(-1.5), float(1.0)]


cluster_dict["10.0380001068"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(38.0), float(-12.4566357403), float(-4.41327148064), float(1.0)]


cluster_dict["10.0380001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(33.0), float(-12.5), float(-3.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([33.0,-12.5,-3.0], [33.491,-9.923,-1.371], color="red blue", name="Arrows_10.0380001068_6")

cluster_dict["10.0380001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(32.5), float(-11.0), float(-3.5), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([32.5,-11.0,-3.5], [33.491,-9.923,-1.371], color="red blue", name="Arrows_10.0380001068_7")

cluster_dict["10.0380001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(35.0), float(-4.5), float(0.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([35.0,-4.5,0.0], [36.469,-5.476,-2.507], color="red blue", name="Arrows_10.0380001068_8")

cluster_dict["10.0380001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(34.0), float(-6.5), float(2.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([34.0,-6.5,2.0], [31.839,-6.19,4.213], color="red blue", name="Arrows_10.0380001068_9")

cluster_dict["10.0380001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(34.0), float(-6.5), float(2.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([34.0,-6.5,2.0], [31.839,-6.19,4.213], color="red blue", name="Arrows_10.0380001068_10")

cluster_dict["10.0380001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(-14.0), float(-4.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([35.5,-14.0,-4.0], [35.409,-14.894,-1.405], color="red blue", name="Arrows_10.0380001068_11")

cluster_dict["10.0380001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(-12.0), float(-2.5), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([35.5,-12.0,-2.5], [34.64,-12.416,-0.25], color="red blue", name="Arrows_10.0380001068_12")

cluster_dict["10.0380001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(-10.5), float(-3.0), float(1.0)]

cluster_dict["10.0380001068_arrows"] += cgo_arrow([36.0,-10.5,-3.0], [33.491,-9.923,-1.371], color="red blue", name="Arrows_10.0380001068_13")

cmd.load_cgo(cluster_dict["10.0380001068"], "Features_10.0380001068", 1)
cmd.load_cgo(cluster_dict["10.0380001068_arrows"], "Arrows_10.0380001068")
cmd.set("transparency", 0.2,"Features_10.0380001068")
cmd.group("Pharmacophore_10.0380001068", members="Features_10.0380001068")
cmd.group("Pharmacophore_10.0380001068", members="Arrows_10.0380001068")

if dirpath:
    f = join(dirpath, "label_threshold_10.0380001068.mol2")
else:
    f = "label_threshold_10.0380001068.mol2"

cmd.load(f, 'label_threshold_10.0380001068')
cmd.hide('everything', 'label_threshold_10.0380001068')
cmd.label("label_threshold_10.0380001068", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_10.0380001068', members= 'label_threshold_10.0380001068')
