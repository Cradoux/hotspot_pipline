
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.2899999619":[], "14.2899999619_arrows":[]}

cluster_dict["14.2899999619"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(6.5), float(19.0), float(22.0), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([6.5,19.0,22.0], [4.913,21.477,22.95], color="blue red", name="Arrows_14.2899999619_1")

cluster_dict["14.2899999619"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(10.0), float(23.5), float(28.0), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([10.0,23.5,28.0], [12.935,22.723,28.632], color="blue red", name="Arrows_14.2899999619_2")

cluster_dict["14.2899999619"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(13.5), float(18.0), float(25.5), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([13.5,18.0,25.5], [12.721,19.487,23.066], color="blue red", name="Arrows_14.2899999619_3")

cluster_dict["14.2899999619"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(18.5), float(29.5), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([13.0,18.5,29.5], [11.952,19.883,31.578], color="blue red", name="Arrows_14.2899999619_4")

cluster_dict["14.2899999619"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(12.5), float(11.0), float(24.5), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([12.5,11.0,24.5], [10.052,12.521,24.252], color="blue red", name="Arrows_14.2899999619_5")

cluster_dict["14.2899999619"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.0), float(15.5), float(22.5), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([19.0,15.5,22.5], [19.446,13.652,20.202], color="blue red", name="Arrows_14.2899999619_6")

cluster_dict["14.2899999619"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(12.6048368842), float(16.7118422957), float(26.5549193824), float(1.0)]


cluster_dict["14.2899999619"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(7.71217600197), float(19.3558558035), float(21.5), float(1.0)]


cluster_dict["14.2899999619"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(7.5), float(19.5), float(26.5), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([7.5,19.5,26.5], [4.514,19.97,26.919], color="red blue", name="Arrows_14.2899999619_7")

cluster_dict["14.2899999619"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(17.0), float(25.0), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([13.0,17.0,25.0], [12.721,19.487,23.066], color="red blue", name="Arrows_14.2899999619_8")

cluster_dict["14.2899999619"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(11.5), float(23.0), float(1.0)]

cluster_dict["14.2899999619_arrows"] += cgo_arrow([16.5,11.5,23.0], [16.579,8.495,22.858], color="red blue", name="Arrows_14.2899999619_9")

cmd.load_cgo(cluster_dict["14.2899999619"], "Features_14.2899999619", 1)
cmd.load_cgo(cluster_dict["14.2899999619_arrows"], "Arrows_14.2899999619")
cmd.set("transparency", 0.2,"Features_14.2899999619")
cmd.group("Pharmacophore_14.2899999619", members="Features_14.2899999619")
cmd.group("Pharmacophore_14.2899999619", members="Arrows_14.2899999619")

if dirpath:
    f = join(dirpath, "label_threshold_14.2899999619.mol2")
else:
    f = "label_threshold_14.2899999619.mol2"

cmd.load(f, 'label_threshold_14.2899999619')
cmd.hide('everything', 'label_threshold_14.2899999619')
cmd.label("label_threshold_14.2899999619", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.2899999619', members= 'label_threshold_14.2899999619')
