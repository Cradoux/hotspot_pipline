
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"11.3420000076":[], "11.3420000076_arrows":[]}

cluster_dict["11.3420000076"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(13.0), float(32.0), float(1.0)]

cluster_dict["11.3420000076_arrows"] += cgo_arrow([23.0,13.0,32.0], [20.399,12.771,31.489], color="blue red", name="Arrows_11.3420000076_1")

cluster_dict["11.3420000076"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(23.2032195216), float(17.0013320881), float(34.0907243126), float(1.0)]


cluster_dict["11.3420000076"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(22.0), float(12.5), float(33.5), float(1.0)]

cluster_dict["11.3420000076_arrows"] += cgo_arrow([22.0,12.5,33.5], [20.399,12.771,31.489], color="red blue", name="Arrows_11.3420000076_2")

cluster_dict["11.3420000076"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(12.5), float(33.0), float(1.0)]

cluster_dict["11.3420000076_arrows"] += cgo_arrow([26.0,12.5,33.0], [26.359,13.471,36.132], color="red blue", name="Arrows_11.3420000076_3")

cmd.load_cgo(cluster_dict["11.3420000076"], "Features_11.3420000076", 1)
cmd.load_cgo(cluster_dict["11.3420000076_arrows"], "Arrows_11.3420000076")
cmd.set("transparency", 0.2,"Features_11.3420000076")
cmd.group("Pharmacophore_11.3420000076", members="Features_11.3420000076")
cmd.group("Pharmacophore_11.3420000076", members="Arrows_11.3420000076")

if dirpath:
    f = join(dirpath, "label_threshold_11.3420000076.mol2")
else:
    f = "label_threshold_11.3420000076.mol2"

cmd.load(f, 'label_threshold_11.3420000076')
cmd.hide('everything', 'label_threshold_11.3420000076')
cmd.label("label_threshold_11.3420000076", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_11.3420000076', members= 'label_threshold_11.3420000076')
