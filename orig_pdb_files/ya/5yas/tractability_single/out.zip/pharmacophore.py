
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.9420003891":[], "13.9420003891_arrows":[]}

cluster_dict["13.9420003891"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(52.0), float(15.5), float(1.0)]

cluster_dict["13.9420003891_arrows"] += cgo_arrow([13.0,52.0,15.5], [11.07,51.616,12.927], color="blue red", name="Arrows_13.9420003891_1")

cluster_dict["13.9420003891"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(52.0), float(15.5), float(1.0)]

cluster_dict["13.9420003891_arrows"] += cgo_arrow([13.0,52.0,15.5], [11.07,51.616,12.927], color="blue red", name="Arrows_13.9420003891_2")

cluster_dict["13.9420003891"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(13.4476230596), float(52.603584807), float(17.4407558163), float(1.0)]


cluster_dict["13.9420003891"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(50.5), float(16.5), float(1.0)]

cluster_dict["13.9420003891_arrows"] += cgo_arrow([13.0,50.5,16.5], [12.875,48.441,14.982], color="red blue", name="Arrows_13.9420003891_3")

cluster_dict["13.9420003891"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(50.5), float(16.5), float(1.0)]

cluster_dict["13.9420003891_arrows"] += cgo_arrow([13.0,50.5,16.5], [12.875,48.441,14.982], color="red blue", name="Arrows_13.9420003891_4")

cmd.load_cgo(cluster_dict["13.9420003891"], "Features_13.9420003891", 1)
cmd.load_cgo(cluster_dict["13.9420003891_arrows"], "Arrows_13.9420003891")
cmd.set("transparency", 0.2,"Features_13.9420003891")
cmd.group("Pharmacophore_13.9420003891", members="Features_13.9420003891")
cmd.group("Pharmacophore_13.9420003891", members="Arrows_13.9420003891")

if dirpath:
    f = join(dirpath, "label_threshold_13.9420003891.mol2")
else:
    f = "label_threshold_13.9420003891.mol2"

cmd.load(f, 'label_threshold_13.9420003891')
cmd.hide('everything', 'label_threshold_13.9420003891')
cmd.label("label_threshold_13.9420003891", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.9420003891', members= 'label_threshold_13.9420003891')
