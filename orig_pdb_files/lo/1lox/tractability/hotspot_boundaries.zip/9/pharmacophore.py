
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.1739997864":[], "15.1739997864_arrows":[]}

cluster_dict["15.1739997864"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-7.0), float(139.5), float(48.0), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-7.0,139.5,48.0], [-7.298,137.092,49.558], color="blue red", name="Arrows_15.1739997864_1")

cluster_dict["15.1739997864"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-11.5), float(142.5), float(45.5), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-11.5,142.5,45.5], [-9.665,144.622,45.987], color="blue red", name="Arrows_15.1739997864_2")

cluster_dict["15.1739997864"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-11.5), float(136.5), float(43.0), float(1.0)]


cluster_dict["15.1739997864"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-10.0), float(138.5), float(49.5), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-10.0,138.5,49.5], [-7.298,137.092,49.558], color="blue red", name="Arrows_15.1739997864_3")

cluster_dict["15.1739997864"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-8.0), float(143.5), float(51.0), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-8.0,143.5,51.0], [-8.269,146.312,49.744], color="blue red", name="Arrows_15.1739997864_4")

cluster_dict["15.1739997864"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-26.9405511871), float(140.39145096), float(46.0658136482), float(1.0)]


cluster_dict["15.1739997864"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-28.5029664984), float(146.0), float(46.2588821555), float(1.0)]


cluster_dict["15.1739997864"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-12.9455994644), float(145.605752198), float(40.7263110561), float(1.0)]


cluster_dict["15.1739997864"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-10.1879739038), float(139.689088791), float(47.3621475679), float(1.0)]


cluster_dict["15.1739997864"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-11.5), float(136.5), float(42.0), float(1.0)]


cluster_dict["15.1739997864"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-26.0), float(142.5), float(47.0), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-26.0,142.5,47.0], [-23.081,143.083,47.078], color="red blue", name="Arrows_15.1739997864_5")

cluster_dict["15.1739997864"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-11.5), float(143.5), float(49.5), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-11.5,143.5,49.5], [-14.448,143.769,50.64], color="red blue", name="Arrows_15.1739997864_6")

cluster_dict["15.1739997864"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.5), float(137.0), float(51.0), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-9.5,137.0,51.0], [-7.298,137.092,49.558], color="red blue", name="Arrows_15.1739997864_7")

cluster_dict["15.1739997864"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.0), float(137.5), float(45.5), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-9.0,137.5,45.5], [-7.298,137.092,49.558], color="red blue", name="Arrows_15.1739997864_8")

cluster_dict["15.1739997864"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-6.5), float(138.5), float(48.0), float(1.0)]

cluster_dict["15.1739997864_arrows"] += cgo_arrow([-6.5,138.5,48.0], [-7.298,137.092,49.558], color="red blue", name="Arrows_15.1739997864_9")

cmd.load_cgo(cluster_dict["15.1739997864"], "Features_15.1739997864", 1)
cmd.load_cgo(cluster_dict["15.1739997864_arrows"], "Arrows_15.1739997864")
cmd.set("transparency", 0.2,"Features_15.1739997864")
cmd.group("Pharmacophore_15.1739997864", members="Features_15.1739997864")
cmd.group("Pharmacophore_15.1739997864", members="Arrows_15.1739997864")

if dirpath:
    f = join(dirpath, "label_threshold_15.1739997864.mol2")
else:
    f = "label_threshold_15.1739997864.mol2"

cmd.load(f, 'label_threshold_15.1739997864')
cmd.hide('everything', 'label_threshold_15.1739997864')
cmd.label("label_threshold_15.1739997864", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.1739997864', members= 'label_threshold_15.1739997864')
