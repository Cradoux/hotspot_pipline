
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"12.5530004501":[], "12.5530004501_arrows":[]}

cluster_dict["12.5530004501"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-37.5), float(136.5), float(76.5), float(1.0)]

cluster_dict["12.5530004501_arrows"] += cgo_arrow([-37.5,136.5,76.5], [-37.706,136.19,79.478], color="blue red", name="Arrows_12.5530004501_1")

cluster_dict["12.5530004501"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-40.5558641236), float(135.672426359), float(74.8464323826), float(1.0)]


cluster_dict["12.5530004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-38.0), float(132.5), float(73.5), float(1.0)]

cluster_dict["12.5530004501_arrows"] += cgo_arrow([-38.0,132.5,73.5], [-40.176,130.752,70.647], color="red blue", name="Arrows_12.5530004501_2")

cluster_dict["12.5530004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-39.0), float(139.0), float(77.0), float(1.0)]

cluster_dict["12.5530004501_arrows"] += cgo_arrow([-39.0,139.0,77.0], [-38.713,140.071,79.854], color="red blue", name="Arrows_12.5530004501_3")

cmd.load_cgo(cluster_dict["12.5530004501"], "Features_12.5530004501", 1)
cmd.load_cgo(cluster_dict["12.5530004501_arrows"], "Arrows_12.5530004501")
cmd.set("transparency", 0.2,"Features_12.5530004501")
cmd.group("Pharmacophore_12.5530004501", members="Features_12.5530004501")
cmd.group("Pharmacophore_12.5530004501", members="Arrows_12.5530004501")

if dirpath:
    f = join(dirpath, "label_threshold_12.5530004501.mol2")
else:
    f = "label_threshold_12.5530004501.mol2"

cmd.load(f, 'label_threshold_12.5530004501')
cmd.hide('everything', 'label_threshold_12.5530004501')
cmd.label("label_threshold_12.5530004501", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_12.5530004501', members= 'label_threshold_12.5530004501')
