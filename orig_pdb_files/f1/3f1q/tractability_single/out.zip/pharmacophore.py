
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"20.3339996338":[], "20.3339996338_arrows":[]}

cluster_dict["20.3339996338"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(10.1137004876), float(-44.5667574296), float(3.11379246808), float(1.0)]


cluster_dict["20.3339996338"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(4.80409933888), float(-39.2850012741), float(-0.142745572068), float(1.0)]


cluster_dict["20.3339996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(5.0), float(-44.5), float(4.5), float(1.0)]

cluster_dict["20.3339996338_arrows"] += cgo_arrow([5.0,-44.5,4.5], [5.589,-47.905,4.4], color="red blue", name="Arrows_20.3339996338_1")

cluster_dict["20.3339996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(10.5), float(-46.5), float(4.5), float(1.0)]

cluster_dict["20.3339996338_arrows"] += cgo_arrow([10.5,-46.5,4.5], [9.393,-45.27,7.582], color="red blue", name="Arrows_20.3339996338_2")

cmd.load_cgo(cluster_dict["20.3339996338"], "Features_20.3339996338", 1)
cmd.load_cgo(cluster_dict["20.3339996338_arrows"], "Arrows_20.3339996338")
cmd.set("transparency", 0.2,"Features_20.3339996338")
cmd.group("Pharmacophore_20.3339996338", members="Features_20.3339996338")
cmd.group("Pharmacophore_20.3339996338", members="Arrows_20.3339996338")

if dirpath:
    f = join(dirpath, "label_threshold_20.3339996338.mol2")
else:
    f = "label_threshold_20.3339996338.mol2"

cmd.load(f, 'label_threshold_20.3339996338')
cmd.hide('everything', 'label_threshold_20.3339996338')
cmd.label("label_threshold_20.3339996338", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_20.3339996338', members= 'label_threshold_20.3339996338')
