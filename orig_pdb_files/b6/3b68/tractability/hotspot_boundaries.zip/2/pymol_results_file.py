
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cmd.load(join(dirpath,"protein.pdb"), "protein")
cmd.show("cartoon", "protein")

if dirpath:
    f = join(dirpath, "label_threshold_7.1.mol2")
else:
    f = "label_threshold_7.1.mol2"

cmd.load(f, 'label_threshold_7.1')
cmd.hide('everything', 'label_threshold_7.1')
cmd.label("label_threshold_7.1", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


colour_dict = {'acceptor':'red', 'donor':'blue', 'apolar':'yellow', 'negative':'purple', 'positive':'cyan'}

threshold_list = [7.1]
gfiles = ['donor.grd', 'apolar.grd', 'acceptor.grd']
grids = ['donor', 'apolar', 'acceptor']
num = 0
surf_transparency = 0.2

if dirpath:
    gfiles = [join(dirpath, g) for g in gfiles]

for t in threshold_list:
    for i in range(len(grids)):
        try:
            cmd.load(r'%s'%(gfiles[i]), '%s_%s'%(grids[i], str(num)))
            cmd.isosurface('surface_%s_%s_%s'%(grids[i], t, num), '%s_%s'%(grids[i], num), t)
            cmd.set('transparency', surf_transparency, 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.color(colour_dict['%s'%(grids[i])], 'surface_%s_%s_%s'%(grids[i], t, num))
            cmd.group('threshold_%s'%(t), members = 'surface_%s_%s_%s'%(grids[i],t, num))
            cmd.group('threshold_%s' % (t), members='label_threshold_%s' % (t))
        except:
            continue



    try:
        cmd.group('hotspot_%s' % (num), members='threshold_%s' % (t))
    except:
        continue
    
    for g in grids:
        
        cmd.group('hotspot_%s' % (num), members='%s_%s' % (g,num))


cluster_dict = {"13.7324995995":[], "13.7324995995_arrows":[]}

cluster_dict["13.7324995995"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(16.5), float(6.5), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([20.5,16.5,6.5], [20.086,16.052,8.963], color="blue red", name="Arrows_13.7324995995_1")

cluster_dict["13.7324995995"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(22.0), float(14.5), float(8.0), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([22.0,14.5,8.0], [20.086,16.052,8.963], color="blue red", name="Arrows_13.7324995995_2")

cluster_dict["13.7324995995"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(14.5), float(5.5), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([25.5,14.5,5.5], [25.609,17.502,4.964], color="blue red", name="Arrows_13.7324995995_3")

cluster_dict["13.7324995995"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(8.5), float(2.5), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([25.5,8.5,2.5], [26.569,10.052,3.904], color="blue red", name="Arrows_13.7324995995_4")

cluster_dict["13.7324995995"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(23.8466757961), float(13.2285446627), float(7.17272046796), float(1.0)]


cluster_dict["13.7324995995"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(25.6909076901), float(8.70889710719), float(3.549359656), float(1.0)]


cluster_dict["13.7324995995"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.5), float(10.5), float(6.5), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([23.5,10.5,6.5], [26.091,9.42,6.004], color="red blue", name="Arrows_13.7324995995_5")

cluster_dict["13.7324995995"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(8.5), float(4.5), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([24.0,8.5,4.5], [26.091,9.42,6.004], color="red blue", name="Arrows_13.7324995995_6")

cluster_dict["13.7324995995"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.0), float(12.0), float(11.0), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([25.0,12.0,11.0], [28.53,12.868,12.24], color="red blue", name="Arrows_13.7324995995_7")

cluster_dict["13.7324995995"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(24.5), float(15.0), float(2.0), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([24.5,15.0,2.0], [27.494,16.157,2.344], color="red blue", name="Arrows_13.7324995995_8")

cluster_dict["13.7324995995"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(10.0), float(9.0), float(1.0)]

cluster_dict["13.7324995995_arrows"] += cgo_arrow([25.5,10.0,9.0], [26.091,9.42,6.004], color="red blue", name="Arrows_13.7324995995_9")

cmd.load_cgo(cluster_dict["13.7324995995"], "Features_13.7324995995", 1)
cmd.load_cgo(cluster_dict["13.7324995995_arrows"], "Arrows_13.7324995995")
cmd.set("transparency", 0.2,"Features_13.7324995995")
cmd.group("Pharmacophore_13.7324995995", members="Features_13.7324995995")
cmd.group("Pharmacophore_13.7324995995", members="Arrows_13.7324995995")

if dirpath:
    f = join(dirpath, "label_threshold_13.7324995995.mol2")
else:
    f = "label_threshold_13.7324995995.mol2"

cmd.load(f, 'label_threshold_13.7324995995')
cmd.hide('everything', 'label_threshold_13.7324995995')
cmd.label("label_threshold_13.7324995995", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.7324995995', members= 'label_threshold_13.7324995995')

cmd.bg_color("white")
cmd.show("cartoon", "protein")
cmd.color("slate", "protein")
cmd.show("sticks", "organic")
cmd.hide("lines", "protein")
