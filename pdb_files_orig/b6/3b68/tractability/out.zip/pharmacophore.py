
from os.path import join
import tempfile
import zipfile
from pymol import cmd
from pymol.cgo import *

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"27.1049995422":[], "27.1049995422_arrows":[]}

cluster_dict["27.1049995422"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(31.5), float(-2.0), float(3.5), float(1.0)]

cluster_dict["27.1049995422_arrows"] += cgo_arrow([31.5,-2.0,3.5], [33.071,0.429,3.28], color="blue red", name="Arrows_27.1049995422_1")

cluster_dict["27.1049995422"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(29.2984445443), float(0.562440132989), float(7.36423214269), float(1.0)]


cluster_dict["27.1049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(0.0), float(3.5), float(1.0)]

cluster_dict["27.1049995422_arrows"] += cgo_arrow([26.0,0.0,3.5], [28.704,-2.798,6.142], color="red blue", name="Arrows_27.1049995422_2")

cluster_dict["27.1049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(1.0), float(2.0), float(1.0)]


cluster_dict["27.1049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(-1.0), float(10.0), float(1.0)]

cluster_dict["27.1049995422_arrows"] += cgo_arrow([28.5,-1.0,10.0], [28.704,-2.798,6.142], color="red blue", name="Arrows_27.1049995422_3")

cluster_dict["27.1049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(3.0), float(9.5), float(1.0)]

cluster_dict["27.1049995422_arrows"] += cgo_arrow([27.5,3.0,9.5], [25.301,3.153,11.536], color="red blue", name="Arrows_27.1049995422_4")

cluster_dict["27.1049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(-2.5), float(3.5), float(1.0)]

cluster_dict["27.1049995422_arrows"] += cgo_arrow([30.0,-2.5,3.5], [28.704,-2.798,6.142], color="red blue", name="Arrows_27.1049995422_5")

cluster_dict["27.1049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(-1.0), float(10.0), float(1.0)]

cluster_dict["27.1049995422_arrows"] += cgo_arrow([28.5,-1.0,10.0], [28.704,-2.798,6.142], color="red blue", name="Arrows_27.1049995422_6")

cluster_dict["27.1049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(29.0), float(-0.5), float(6.0), float(1.0)]

cluster_dict["27.1049995422_arrows"] += cgo_arrow([29.0,-0.5,6.0], [28.704,-2.798,6.142], color="red blue", name="Arrows_27.1049995422_7")

cluster_dict["27.1049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(31.5), float(1.5), float(5.0), float(1.0)]

cluster_dict["27.1049995422_arrows"] += cgo_arrow([31.5,1.5,5.0], [32.669,3.239,1.592], color="red blue", name="Arrows_27.1049995422_8")

cmd.load_cgo(cluster_dict["27.1049995422"], "Features_27.1049995422", 1)
cmd.load_cgo(cluster_dict["27.1049995422_arrows"], "Arrows_27.1049995422")
cmd.set("transparency", 0.2,"Features_27.1049995422")
cmd.group("Pharmacophore_27.1049995422", members="Features_27.1049995422")
cmd.group("Pharmacophore_27.1049995422", members="Arrows_27.1049995422")

if dirpath:
    f = join(dirpath, "label_threshold_27.1049995422.mol2")
else:
    f = "label_threshold_27.1049995422.mol2"

cmd.load(f, 'label_threshold_27.1049995422')
cmd.hide('everything', 'label_threshold_27.1049995422')
cmd.label("label_threshold_27.1049995422", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_27.1049995422', members= 'label_threshold_27.1049995422')
