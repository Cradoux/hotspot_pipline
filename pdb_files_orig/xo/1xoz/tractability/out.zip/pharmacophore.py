
from os.path import join
import tempfile
import zipfile
from pymol import cmd
from pymol.cgo import *

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.4640007019":[], "17.4640007019_arrows":[]}

cluster_dict["17.4640007019"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(51.5), float(37.5), float(11.0), float(1.0)]

cluster_dict["17.4640007019_arrows"] += cgo_arrow([51.5,37.5,11.0], [54.453,36.097,11.926], color="blue red", name="Arrows_17.4640007019_1")

cluster_dict["17.4640007019"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(49.5), float(40.0), float(20.0), float(1.0)]

cluster_dict["17.4640007019_arrows"] += cgo_arrow([49.5,40.0,20.0], [49.218,42.787,18.211], color="blue red", name="Arrows_17.4640007019_2")

cluster_dict["17.4640007019"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(51.5), float(37.5), float(11.0), float(1.0)]

cluster_dict["17.4640007019_arrows"] += cgo_arrow([51.5,37.5,11.0], [54.453,36.097,11.926], color="blue red", name="Arrows_17.4640007019_3")

cluster_dict["17.4640007019"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(48.5838527951), float(33.7206419681), float(14.6270717955), float(1.0)]


cluster_dict["17.4640007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(45.5), float(34.5), float(22.0), float(1.0)]

cluster_dict["17.4640007019_arrows"] += cgo_arrow([45.5,34.5,22.0], [44.211,32.161,23.217], color="red blue", name="Arrows_17.4640007019_4")

cluster_dict["17.4640007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(32.5), float(9.5), float(1.0)]

cluster_dict["17.4640007019_arrows"] += cgo_arrow([48.0,32.5,9.5], [45.729,33.684,7.995], color="red blue", name="Arrows_17.4640007019_5")

cluster_dict["17.4640007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(49.5), float(34.0), float(14.0), float(1.0)]


cluster_dict["17.4640007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(32.5), float(9.5), float(1.0)]

cluster_dict["17.4640007019_arrows"] += cgo_arrow([48.0,32.5,9.5], [45.729,33.684,7.995], color="red blue", name="Arrows_17.4640007019_6")

cluster_dict["17.4640007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.5), float(35.5), float(8.0), float(1.0)]

cluster_dict["17.4640007019_arrows"] += cgo_arrow([48.5,35.5,8.0], [45.729,33.684,7.995], color="red blue", name="Arrows_17.4640007019_7")

cluster_dict["17.4640007019"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(49.5), float(34.0), float(14.0), float(1.0)]


cmd.load_cgo(cluster_dict["17.4640007019"], "Features_17.4640007019", 1)
cmd.load_cgo(cluster_dict["17.4640007019_arrows"], "Arrows_17.4640007019")
cmd.set("transparency", 0.2,"Features_17.4640007019")
cmd.group("Pharmacophore_17.4640007019", members="Features_17.4640007019")
cmd.group("Pharmacophore_17.4640007019", members="Arrows_17.4640007019")

if dirpath:
    f = join(dirpath, "label_threshold_17.4640007019.mol2")
else:
    f = "label_threshold_17.4640007019.mol2"

cmd.load(f, 'label_threshold_17.4640007019')
cmd.hide('everything', 'label_threshold_17.4640007019')
cmd.label("label_threshold_17.4640007019", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.4640007019', members= 'label_threshold_17.4640007019')
