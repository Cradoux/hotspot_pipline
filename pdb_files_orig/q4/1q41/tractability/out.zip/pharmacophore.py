
from os.path import join
import tempfile
import zipfile
from pymol import cmd
from pymol.cgo import *

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"22.3899993896":[], "22.3899993896_arrows":[]}

cluster_dict["22.3899993896"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(6.0), float(31.5), float(1.0)]

cluster_dict["22.3899993896_arrows"] += cgo_arrow([35.5,6.0,31.5], [32.37,6.187,33.175], color="blue red", name="Arrows_22.3899993896_1")

cluster_dict["22.3899993896"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(35.5), float(6.0), float(31.5), float(1.0)]

cluster_dict["22.3899993896_arrows"] += cgo_arrow([35.5,6.0,31.5], [32.37,6.187,33.175], color="blue red", name="Arrows_22.3899993896_2")

cluster_dict["22.3899993896"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(31.5986971154), float(-1.16430601658), float(27.5384482411), float(1.0)]


cluster_dict["22.3899993896"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(34.8784366312), float(5.78950543632), float(30.7928401163), float(1.0)]


cluster_dict["22.3899993896"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(33.5), float(4.5), float(28.5), float(1.0)]

cluster_dict["22.3899993896_arrows"] += cgo_arrow([33.5,4.5,28.5], [30.404,4.15,28.679], color="red blue", name="Arrows_22.3899993896_3")

cluster_dict["22.3899993896"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(4.5), float(31.0), float(1.0)]


cluster_dict["22.3899993896"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(36.0), float(4.5), float(31.0), float(1.0)]


cluster_dict["22.3899993896"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(39.0), float(3.5), float(29.0), float(1.0)]

cluster_dict["22.3899993896_arrows"] += cgo_arrow([39.0,3.5,29.0], [40.345,6.081,27.852], color="red blue", name="Arrows_22.3899993896_4")

cluster_dict["22.3899993896"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(38.5), float(5.0), float(32.5), float(1.0)]

cluster_dict["22.3899993896_arrows"] += cgo_arrow([38.5,5.0,32.5], [42.59,5.735,30.575], color="red blue", name="Arrows_22.3899993896_5")

cmd.load_cgo(cluster_dict["22.3899993896"], "Features_22.3899993896", 1)
cmd.load_cgo(cluster_dict["22.3899993896_arrows"], "Arrows_22.3899993896")
cmd.set("transparency", 0.2,"Features_22.3899993896")
cmd.group("Pharmacophore_22.3899993896", members="Features_22.3899993896")
cmd.group("Pharmacophore_22.3899993896", members="Arrows_22.3899993896")

if dirpath:
    f = join(dirpath, "label_threshold_22.3899993896.mol2")
else:
    f = "label_threshold_22.3899993896.mol2"

cmd.load(f, 'label_threshold_22.3899993896')
cmd.hide('everything', 'label_threshold_22.3899993896')
cmd.label("label_threshold_22.3899993896", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_22.3899993896', members= 'label_threshold_22.3899993896')
