
from os.path import join
import tempfile
import zipfile
from pymol import cmd
from pymol.cgo import *

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"32.1819992065":[], "32.1819992065_arrows":[]}

cluster_dict["32.1819992065"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(-6.0), float(-20.0), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([23.0,-6.0,-20.0], [23.113,-6.744,-17.941], color="blue red", name="Arrows_32.1819992065_1")

cluster_dict["32.1819992065"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.0), float(-6.0), float(-20.0), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([23.0,-6.0,-20.0], [23.113,-6.744,-17.941], color="blue red", name="Arrows_32.1819992065_2")

cluster_dict["32.1819992065"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(-4.5), float(-25.5), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([26.0,-4.5,-25.5], [26.415,-6.378,-27.584], color="blue red", name="Arrows_32.1819992065_3")

cluster_dict["32.1819992065"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.0), float(-13.0), float(-18.5), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([27.0,-13.0,-18.5], [24.742,-14.097,-17.361], color="blue red", name="Arrows_32.1819992065_4")

cluster_dict["32.1819992065"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(26.8864094837), float(-7.77191180833), float(-19.9111981511), float(1.0)]


cluster_dict["32.1819992065"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.7756786997), float(-6.72432130029), float(-21.0), float(1.0)]


cluster_dict["32.1819992065"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(-12.3553259889), float(-15.9009398804), float(1.0)]


cluster_dict["32.1819992065"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.5), float(-5.0), float(-21.0), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([23.5,-5.0,-21.0], [20.669,-2.825,-22.19], color="red blue", name="Arrows_32.1819992065_5")

cluster_dict["32.1819992065"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(23.5), float(-3.5), float(-21.5), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([23.5,-3.5,-21.5], [20.669,-2.825,-22.19], color="red blue", name="Arrows_32.1819992065_6")

cluster_dict["32.1819992065"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(30.0), float(-12.5), float(-20.0), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([30.0,-12.5,-20.0], [29.487,-15.274,-21.589], color="red blue", name="Arrows_32.1819992065_7")

cluster_dict["32.1819992065"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(-6.5), float(-21.5), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([27.5,-6.5,-21.5], [30.396,-5.815,-21.901], color="red blue", name="Arrows_32.1819992065_8")

cluster_dict["32.1819992065"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(28.0), float(-9.5), float(-15.0), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([28.0,-9.5,-15.0], [30.468,-13.436,-15.178], color="red blue", name="Arrows_32.1819992065_9")

cluster_dict["32.1819992065"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(31.0), float(-10.5), float(-15.5), float(1.0)]

cluster_dict["32.1819992065_arrows"] += cgo_arrow([31.0,-10.5,-15.5], [30.468,-13.436,-15.178], color="red blue", name="Arrows_32.1819992065_10")

cmd.load_cgo(cluster_dict["32.1819992065"], "Features_32.1819992065", 1)
cmd.load_cgo(cluster_dict["32.1819992065_arrows"], "Arrows_32.1819992065")
cmd.set("transparency", 0.2,"Features_32.1819992065")
cmd.group("Pharmacophore_32.1819992065", members="Features_32.1819992065")
cmd.group("Pharmacophore_32.1819992065", members="Arrows_32.1819992065")

if dirpath:
    f = join(dirpath, "label_threshold_32.1819992065.mol2")
else:
    f = "label_threshold_32.1819992065.mol2"

cmd.load(f, 'label_threshold_32.1819992065')
cmd.hide('everything', 'label_threshold_32.1819992065')
cmd.label("label_threshold_32.1819992065", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_32.1819992065', members= 'label_threshold_32.1819992065')
