
from os.path import join
import tempfile
import zipfile
from pymol import cmd
from pymol.cgo import *

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.0839996338":[], "16.0839996338_arrows":[]}

cluster_dict["16.0839996338"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-49.0), float(-12.5), float(-6.5), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-49.0,-12.5,-6.5], [-47.072,-14.06,-4.739], color="blue red", name="Arrows_16.0839996338_1")

cluster_dict["16.0839996338"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-45.0), float(-15.0), float(-11.0), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-45.0,-15.0,-11.0], [-43.537,-16.731,-9.097], color="blue red", name="Arrows_16.0839996338_2")

cluster_dict["16.0839996338"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-45.71959472), float(-11.996174404), float(-8.99735668933), float(1.0)]


cluster_dict["16.0839996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-52.5), float(-17.5), float(-8.0), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-52.5,-17.5,-8.0], [-54.917,-17.538,-10.051], color="red blue", name="Arrows_16.0839996338_3")

cluster_dict["16.0839996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-52.0), float(-12.5), float(-8.0), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-52.0,-12.5,-8.0], [-52.889,-10.6,-6.798], color="red blue", name="Arrows_16.0839996338_4")

cluster_dict["16.0839996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-47.5), float(-17.0), float(-5.0), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-47.5,-17.0,-5.0], [-45.547,-18.463,-3.903], color="red blue", name="Arrows_16.0839996338_5")

cluster_dict["16.0839996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-46.0), float(-15.0), float(-8.5), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-46.0,-15.0,-8.5], [-43.537,-16.731,-9.097], color="red blue", name="Arrows_16.0839996338_6")

cluster_dict["16.0839996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-43.5), float(-16.0), float(-11.5), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-43.5,-16.0,-11.5], [-43.537,-16.731,-9.097], color="red blue", name="Arrows_16.0839996338_7")

cluster_dict["16.0839996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-43.5), float(-6.0), float(-4.0), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-43.5,-6.0,-4.0], [-46.033,-5.35,-4.985], color="red blue", name="Arrows_16.0839996338_8")

cluster_dict["16.0839996338"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-43.5), float(-9.0), float(-3.5), float(1.0)]

cluster_dict["16.0839996338_arrows"] += cgo_arrow([-43.5,-9.0,-3.5], [-44.259,-8.867,0.934], color="red blue", name="Arrows_16.0839996338_9")

cmd.load_cgo(cluster_dict["16.0839996338"], "Features_16.0839996338", 1)
cmd.load_cgo(cluster_dict["16.0839996338_arrows"], "Arrows_16.0839996338")
cmd.set("transparency", 0.2,"Features_16.0839996338")
cmd.group("Pharmacophore_16.0839996338", members="Features_16.0839996338")
cmd.group("Pharmacophore_16.0839996338", members="Arrows_16.0839996338")

if dirpath:
    f = join(dirpath, "label_threshold_16.0839996338.mol2")
else:
    f = "label_threshold_16.0839996338.mol2"

cmd.load(f, 'label_threshold_16.0839996338')
cmd.hide('everything', 'label_threshold_16.0839996338')
cmd.label("label_threshold_16.0839996338", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.0839996338', members= 'label_threshold_16.0839996338')
