
from os.path import join
import tempfile
import zipfile
from pymol import cmd
from pymol.cgo import *

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.7600002289":[], "15.7600002289_arrows":[]}

cluster_dict["15.7600002289"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(48.5), float(47.5), float(-6.5), float(1.0)]

cluster_dict["15.7600002289_arrows"] += cgo_arrow([48.5,47.5,-6.5], [50.304,48.873,-9.129], color="blue red", name="Arrows_15.7600002289_1")

cluster_dict["15.7600002289"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(50.0), float(46.0), float(-9.5), float(1.0)]

cluster_dict["15.7600002289_arrows"] += cgo_arrow([50.0,46.0,-9.5], [51.031,46.692,-11.391], color="blue red", name="Arrows_15.7600002289_2")

cluster_dict["15.7600002289"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(46.6544050108), float(42.5152681775), float(-6.5624157452), float(1.0)]


cluster_dict["15.7600002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(44.5), float(40.5), float(-4.0), float(1.0)]

cluster_dict["15.7600002289_arrows"] += cgo_arrow([44.5,40.5,-4.0], [45.523,37.967,-0.257], color="red blue", name="Arrows_15.7600002289_3")

cluster_dict["15.7600002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(45.0), float(40.5), float(-2.5), float(1.0)]

cluster_dict["15.7600002289_arrows"] += cgo_arrow([45.0,40.5,-2.5], [45.523,37.967,-0.257], color="red blue", name="Arrows_15.7600002289_4")

cluster_dict["15.7600002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(45.5), float(43.0), float(-3.0), float(1.0)]

cluster_dict["15.7600002289_arrows"] += cgo_arrow([45.5,43.0,-3.0], [43.682,43.907,0.322], color="red blue", name="Arrows_15.7600002289_5")

cluster_dict["15.7600002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(46.5), float(43.0), float(-8.5), float(1.0)]


cluster_dict["15.7600002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(47.5), float(47.0), float(-4.5), float(1.0)]

cluster_dict["15.7600002289_arrows"] += cgo_arrow([47.5,47.0,-4.5], [50.217,45.377,-0.741], color="red blue", name="Arrows_15.7600002289_6")

cluster_dict["15.7600002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(47.5), float(41.5), float(-6.0), float(1.0)]


cluster_dict["15.7600002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(47.5), float(47.0), float(-4.5), float(1.0)]

cluster_dict["15.7600002289_arrows"] += cgo_arrow([47.5,47.0,-4.5], [50.217,45.377,-0.741], color="red blue", name="Arrows_15.7600002289_7")

cmd.load_cgo(cluster_dict["15.7600002289"], "Features_15.7600002289", 1)
cmd.load_cgo(cluster_dict["15.7600002289_arrows"], "Arrows_15.7600002289")
cmd.set("transparency", 0.2,"Features_15.7600002289")
cmd.group("Pharmacophore_15.7600002289", members="Features_15.7600002289")
cmd.group("Pharmacophore_15.7600002289", members="Arrows_15.7600002289")

if dirpath:
    f = join(dirpath, "label_threshold_15.7600002289.mol2")
else:
    f = "label_threshold_15.7600002289.mol2"

cmd.load(f, 'label_threshold_15.7600002289')
cmd.hide('everything', 'label_threshold_15.7600002289')
cmd.label("label_threshold_15.7600002289", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.7600002289', members= 'label_threshold_15.7600002289')
