
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.1199998856":[], "15.1199998856_arrows":[]}

cluster_dict["15.1199998856"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-8.5), float(18.0), float(29.0), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-8.5,18.0,29.0], [-9.296,20.715,29.569], color="blue red", name="Arrows_15.1199998856_1")

cluster_dict["15.1199998856"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-8.5), float(18.0), float(34.0), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-8.5,18.0,34.0], [-9.569,19.744,36.273], color="blue red", name="Arrows_15.1199998856_2")

cluster_dict["15.1199998856"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-9.67692286035), float(15.3507213641), float(28.5032940555), float(1.0)]


cluster_dict["15.1199998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-14.0), float(12.0), float(29.5), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-14.0,12.0,29.5], [-16.374,9.898,26.209], color="red blue", name="Arrows_15.1199998856_3")

cluster_dict["15.1199998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-12.0), float(15.5), float(34.0), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-12.0,15.5,34.0], [-13.393,18.264,34.841], color="red blue", name="Arrows_15.1199998856_4")

cluster_dict["15.1199998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-11.0), float(12.0), float(35.5), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-11.0,12.0,35.5], [-9.078,9.709,34.737], color="red blue", name="Arrows_15.1199998856_5")

cluster_dict["15.1199998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-10.5), float(16.5), float(23.0), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-10.5,16.5,23.0], [-13.176,18.246,26.384], color="red blue", name="Arrows_15.1199998856_6")

cluster_dict["15.1199998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-10.5), float(16.5), float(23.0), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-10.5,16.5,23.0], [-13.176,18.246,26.384], color="red blue", name="Arrows_15.1199998856_7")

cluster_dict["15.1199998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-10.5), float(17.0), float(35.0), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-10.5,17.0,35.0], [-11.92,18.74,37.125], color="red blue", name="Arrows_15.1199998856_8")

cluster_dict["15.1199998856"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-8.0), float(14.0), float(27.5), float(1.0)]

cluster_dict["15.1199998856_arrows"] += cgo_arrow([-8.0,14.0,27.5], [-8.616,10.95,27.786], color="red blue", name="Arrows_15.1199998856_9")

cmd.load_cgo(cluster_dict["15.1199998856"], "Features_15.1199998856", 1)
cmd.load_cgo(cluster_dict["15.1199998856_arrows"], "Arrows_15.1199998856")
cmd.set("transparency", 0.2,"Features_15.1199998856")
cmd.group("Pharmacophore_15.1199998856", members="Features_15.1199998856")
cmd.group("Pharmacophore_15.1199998856", members="Arrows_15.1199998856")

if dirpath:
    f = join(dirpath, "label_threshold_15.1199998856.mol2")
else:
    f = "label_threshold_15.1199998856.mol2"

cmd.load(f, 'label_threshold_15.1199998856')
cmd.hide('everything', 'label_threshold_15.1199998856')
cmd.label("label_threshold_15.1199998856", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.1199998856', members= 'label_threshold_15.1199998856')
