
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.091999054":[], "17.091999054_arrows":[]}

cluster_dict["17.091999054"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-45.5), float(29.0), float(-6.0), float(1.0)]

cluster_dict["17.091999054_arrows"] += cgo_arrow([-45.5,29.0,-6.0], [-43.246,28.029,-7.265], color="blue red", name="Arrows_17.091999054_1")

cluster_dict["17.091999054"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-37.0), float(24.0), float(-0.5), float(1.0)]

cluster_dict["17.091999054_arrows"] += cgo_arrow([-37.0,24.0,-0.5], [-35.435,21.826,0.786], color="blue red", name="Arrows_17.091999054_2")

cluster_dict["17.091999054"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-35.0), float(29.0), float(-1.5), float(1.0)]

cluster_dict["17.091999054_arrows"] += cgo_arrow([-35.0,29.0,-1.5], [-32.426,27.812,-0.09], color="blue red", name="Arrows_17.091999054_3")

cluster_dict["17.091999054"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-39.6044686178), float(27.3041512578), float(-0.750196208217), float(1.0)]


cluster_dict["17.091999054"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-44.5), float(23.0), float(-2.5), float(1.0)]

cluster_dict["17.091999054_arrows"] += cgo_arrow([-44.5,23.0,-2.5], [-47.478,23.36,-2.426], color="red blue", name="Arrows_17.091999054_4")

cluster_dict["17.091999054"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-40.5), float(22.5), float(0.0), float(1.0)]

cluster_dict["17.091999054_arrows"] += cgo_arrow([-40.5,22.5,0.0], [-38.239,21.157,0.384], color="red blue", name="Arrows_17.091999054_5")

cluster_dict["17.091999054"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-36.0), float(26.0), float(1.0), float(1.0)]

cluster_dict["17.091999054_arrows"] += cgo_arrow([-36.0,26.0,1.0], [-32.936,24.781,0.433], color="red blue", name="Arrows_17.091999054_6")

cmd.load_cgo(cluster_dict["17.091999054"], "Features_17.091999054", 1)
cmd.load_cgo(cluster_dict["17.091999054_arrows"], "Arrows_17.091999054")
cmd.set("transparency", 0.2,"Features_17.091999054")
cmd.group("Pharmacophore_17.091999054", members="Features_17.091999054")
cmd.group("Pharmacophore_17.091999054", members="Arrows_17.091999054")

if dirpath:
    f = join(dirpath, "label_threshold_17.091999054.mol2")
else:
    f = "label_threshold_17.091999054.mol2"

cmd.load(f, 'label_threshold_17.091999054')
cmd.hide('everything', 'label_threshold_17.091999054')
cmd.label("label_threshold_17.091999054", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.091999054', members= 'label_threshold_17.091999054')
