
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.2450008392":[], "17.2450008392_arrows":[]}

cluster_dict["17.2450008392"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(69.2664097985), float(15.5595069333), float(9.37067644987), float(1.0)]


cluster_dict["17.2450008392"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(65.5), float(15.5), float(8.5), float(1.0)]

cluster_dict["17.2450008392_arrows"] += cgo_arrow([65.5,15.5,8.5], [65.199,17.927,6.197], color="red blue", name="Arrows_17.2450008392_1")

cluster_dict["17.2450008392"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(67.0), float(15.0), float(9.0), float(1.0)]

cluster_dict["17.2450008392_arrows"] += cgo_arrow([67.0,15.0,9.0], [65.199,17.927,6.197], color="red blue", name="Arrows_17.2450008392_2")

cluster_dict["17.2450008392"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(68.0), float(17.0), float(6.0), float(1.0)]

cluster_dict["17.2450008392_arrows"] += cgo_arrow([68.0,17.0,6.0], [65.199,17.927,6.197], color="red blue", name="Arrows_17.2450008392_3")

cluster_dict["17.2450008392"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(69.0), float(14.0), float(12.0), float(1.0)]

cluster_dict["17.2450008392_arrows"] += cgo_arrow([69.0,14.0,12.0], [66.984,14.616,14.269], color="red blue", name="Arrows_17.2450008392_4")

cluster_dict["17.2450008392"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(72.0), float(15.5), float(8.5), float(1.0)]

cluster_dict["17.2450008392_arrows"] += cgo_arrow([72.0,15.5,8.5], [73.123,11.343,7.892], color="red blue", name="Arrows_17.2450008392_5")

cmd.load_cgo(cluster_dict["17.2450008392"], "Features_17.2450008392", 1)
cmd.load_cgo(cluster_dict["17.2450008392_arrows"], "Arrows_17.2450008392")
cmd.set("transparency", 0.2,"Features_17.2450008392")
cmd.group("Pharmacophore_17.2450008392", members="Features_17.2450008392")
cmd.group("Pharmacophore_17.2450008392", members="Arrows_17.2450008392")

if dirpath:
    f = join(dirpath, "label_threshold_17.2450008392.mol2")
else:
    f = "label_threshold_17.2450008392.mol2"

cmd.load(f, 'label_threshold_17.2450008392')
cmd.hide('everything', 'label_threshold_17.2450008392')
cmd.label("label_threshold_17.2450008392", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.2450008392', members= 'label_threshold_17.2450008392')
