
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.7539997101":[], "16.7539997101_arrows":[]}

cluster_dict["16.7539997101"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-32.5), float(2.0), float(-8.5), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-32.5,2.0,-8.5], [-31.376,2.418,-11.436], color="blue red", name="Arrows_16.7539997101_1")

cluster_dict["16.7539997101"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-30.0), float(5.0), float(-10.0), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-30.0,5.0,-10.0], [-28.778,2.732,-10.704], color="blue red", name="Arrows_16.7539997101_2")

cluster_dict["16.7539997101"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-24.0), float(12.0), float(-13.0), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-24.0,12.0,-13.0], [-22.593,12.291,-15.301], color="blue red", name="Arrows_16.7539997101_3")

cluster_dict["16.7539997101"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-22.0), float(1.0), float(-11.0), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-22.0,1.0,-11.0], [-23.801,-0.574,-9.037], color="blue red", name="Arrows_16.7539997101_4")

cluster_dict["16.7539997101"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-26.5945396582), float(7.44694340866), float(-9.87570518987), float(1.0)]


cluster_dict["16.7539997101"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-33.5), float(2.0), float(-10.0), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-33.5,2.0,-10.0], [-35.381,2.85,-11.001], color="red blue", name="Arrows_16.7539997101_5")

cluster_dict["16.7539997101"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-26.5), float(4.0), float(-11.0), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-26.5,4.0,-11.0], [-27.06,2.204,-9.435], color="red blue", name="Arrows_16.7539997101_6")

cluster_dict["16.7539997101"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-25.5), float(6.5), float(-11.5), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-25.5,6.5,-11.5], [-25.126,3.115,-12.834], color="red blue", name="Arrows_16.7539997101_7")

cluster_dict["16.7539997101"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-21.5), float(9.5), float(-12.0), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-21.5,9.5,-12.0], [-20.258,10.438,-14.847], color="red blue", name="Arrows_16.7539997101_8")

cluster_dict["16.7539997101"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-22.0), float(2.5), float(-11.5), float(1.0)]

cluster_dict["16.7539997101_arrows"] += cgo_arrow([-22.0,2.5,-11.5], [-25.126,3.115,-12.834], color="red blue", name="Arrows_16.7539997101_9")

cmd.load_cgo(cluster_dict["16.7539997101"], "Features_16.7539997101", 1)
cmd.load_cgo(cluster_dict["16.7539997101_arrows"], "Arrows_16.7539997101")
cmd.set("transparency", 0.2,"Features_16.7539997101")
cmd.group("Pharmacophore_16.7539997101", members="Features_16.7539997101")
cmd.group("Pharmacophore_16.7539997101", members="Arrows_16.7539997101")

if dirpath:
    f = join(dirpath, "label_threshold_16.7539997101.mol2")
else:
    f = "label_threshold_16.7539997101.mol2"

cmd.load(f, 'label_threshold_16.7539997101')
cmd.hide('everything', 'label_threshold_16.7539997101')
cmd.label("label_threshold_16.7539997101", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.7539997101', members= 'label_threshold_16.7539997101')
