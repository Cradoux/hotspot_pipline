
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.9689998627":[], "15.9689998627_arrows":[]}

cluster_dict["15.9689998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(97.0), float(58.5), float(51.5), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([97.0,58.5,51.5], [96.892,59.428,54.314], color="blue red", name="Arrows_15.9689998627_1")

cluster_dict["15.9689998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(98.5), float(53.5), float(52.0), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([98.5,53.5,52.0], [100.549,51.341,51.975], color="blue red", name="Arrows_15.9689998627_2")

cluster_dict["15.9689998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(99.0), float(62.0), float(47.5), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([99.0,62.0,47.5], [98.844,59.018,46.999], color="blue red", name="Arrows_15.9689998627_3")

cluster_dict["15.9689998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(102.5), float(53.0), float(53.0), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([102.5,53.0,53.0], [100.549,51.341,51.975], color="blue red", name="Arrows_15.9689998627_4")

cluster_dict["15.9689998627"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(103.0), float(57.0), float(53.0), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([103.0,57.0,53.0], [104.159,54.788,54.922], color="blue red", name="Arrows_15.9689998627_5")

cluster_dict["15.9689998627"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(100.774835844), float(58.9971515963), float(49.8199427928), float(1.0)]


cluster_dict["15.9689998627"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(97.0), float(66.0), float(51.5), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([97.0,66.0,51.5], [95.231,68.351,52.627], color="red blue", name="Arrows_15.9689998627_6")

cluster_dict["15.9689998627"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(98.5), float(65.5), float(49.0), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([98.5,65.5,49.0], [98.672,66.443,45.392], color="red blue", name="Arrows_15.9689998627_7")

cluster_dict["15.9689998627"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(102.0), float(66.5), float(49.0), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([102.0,66.5,49.0], [101.484,68.93,48.907], color="red blue", name="Arrows_15.9689998627_8")

cluster_dict["15.9689998627"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(102.5), float(60.0), float(48.5), float(1.0)]

cluster_dict["15.9689998627_arrows"] += cgo_arrow([102.5,60.0,48.5], [100.246,57.359,46.359], color="red blue", name="Arrows_15.9689998627_9")

cmd.load_cgo(cluster_dict["15.9689998627"], "Features_15.9689998627", 1)
cmd.load_cgo(cluster_dict["15.9689998627_arrows"], "Arrows_15.9689998627")
cmd.set("transparency", 0.2,"Features_15.9689998627")
cmd.group("Pharmacophore_15.9689998627", members="Features_15.9689998627")
cmd.group("Pharmacophore_15.9689998627", members="Arrows_15.9689998627")

if dirpath:
    f = join(dirpath, "label_threshold_15.9689998627.mol2")
else:
    f = "label_threshold_15.9689998627.mol2"

cmd.load(f, 'label_threshold_15.9689998627')
cmd.hide('everything', 'label_threshold_15.9689998627')
cmd.label("label_threshold_15.9689998627", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.9689998627', members= 'label_threshold_15.9689998627')
