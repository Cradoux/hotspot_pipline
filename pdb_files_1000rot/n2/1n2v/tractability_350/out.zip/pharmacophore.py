
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"15.6400003433":[], "15.6400003433_arrows":[]}

cluster_dict["15.6400003433"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(11.5), float(15.5), float(15.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([11.5,15.5,15.0], [8.067,15.561,15.784], color="blue red", name="Arrows_15.6400003433_1")

cluster_dict["15.6400003433"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(17.5), float(17.0), float(24.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([17.5,17.0,24.0], [17.317,17.483,27.041], color="blue red", name="Arrows_15.6400003433_2")

cluster_dict["15.6400003433"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(15.0), float(15.5), float(17.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([15.0,15.5,17.0], [14.752,12.543,15.771], color="blue red", name="Arrows_15.6400003433_3")

cluster_dict["15.6400003433"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(14.8662057224), float(17.317290247), float(17.3137434982), float(1.0)]


cluster_dict["15.6400003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(7.5), float(18.0), float(12.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([7.5,18.0,12.0], [6.561,15.659,11.946], color="red blue", name="Arrows_15.6400003433_4")

cluster_dict["15.6400003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(11.5), float(15.0), float(16.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([11.5,15.0,16.0], [9.08,14.837,17.65], color="red blue", name="Arrows_15.6400003433_5")

cluster_dict["15.6400003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(12.0), float(19.0), float(16.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([12.0,19.0,16.0], [11.27,18.574,18.766], color="red blue", name="Arrows_15.6400003433_6")

cluster_dict["15.6400003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.5), float(17.0), float(20.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([13.5,17.0,20.0], [11.27,18.574,18.766], color="red blue", name="Arrows_15.6400003433_7")

cluster_dict["15.6400003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(15.5), float(16.0), float(13.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([15.5,16.0,13.0], [17.299,14.409,10.725], color="red blue", name="Arrows_15.6400003433_8")

cluster_dict["15.6400003433"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(17.5), float(22.0), float(1.0)]

cluster_dict["15.6400003433_arrows"] += cgo_arrow([18.5,17.5,22.0], [21.559,17.976,22.727], color="red blue", name="Arrows_15.6400003433_9")

cmd.load_cgo(cluster_dict["15.6400003433"], "Features_15.6400003433", 1)
cmd.load_cgo(cluster_dict["15.6400003433_arrows"], "Arrows_15.6400003433")
cmd.set("transparency", 0.2,"Features_15.6400003433")
cmd.group("Pharmacophore_15.6400003433", members="Features_15.6400003433")
cmd.group("Pharmacophore_15.6400003433", members="Arrows_15.6400003433")

if dirpath:
    f = join(dirpath, "label_threshold_15.6400003433.mol2")
else:
    f = "label_threshold_15.6400003433.mol2"

cmd.load(f, 'label_threshold_15.6400003433')
cmd.hide('everything', 'label_threshold_15.6400003433')
cmd.label("label_threshold_15.6400003433", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_15.6400003433', members= 'label_threshold_15.6400003433')
