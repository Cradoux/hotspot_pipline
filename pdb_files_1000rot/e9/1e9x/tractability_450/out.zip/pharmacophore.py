
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.8819999695":[], "17.8819999695_arrows":[]}

cluster_dict["17.8819999695"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-18.0), float(-8.5), float(68.0), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-18.0,-8.5,68.0], [-19.535,-11.01,67.361], color="blue red", name="Arrows_17.8819999695_1")

cluster_dict["17.8819999695"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-16.0), float(-2.5), float(66.0), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-16.0,-2.5,66.0], [-13.331,-1.002,64.789], color="blue red", name="Arrows_17.8819999695_2")

cluster_dict["17.8819999695"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-17.8224727012), float(-5.3352340336), float(63.6367689512), float(1.0)]


cluster_dict["17.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-21.0), float(-8.0), float(64.5), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-21.0,-8.0,64.5], [-20.628,-9.88,62.13], color="red blue", name="Arrows_17.8819999695_3")

cluster_dict["17.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-20.5), float(-7.5), float(67.5), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-20.5,-7.5,67.5], [-20.316,-7.283,70.662], color="red blue", name="Arrows_17.8819999695_4")

cluster_dict["17.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-21.0), float(-4.5), float(58.5), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-21.0,-4.5,58.5], [-20.026,-8.617,59.859], color="red blue", name="Arrows_17.8819999695_5")

cluster_dict["17.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-16.5), float(-5.0), float(58.0), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-16.5,-5.0,58.0], [-16.139,-7.535,54.847], color="red blue", name="Arrows_17.8819999695_6")

cluster_dict["17.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-16.5), float(-5.0), float(58.0), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-16.5,-5.0,58.0], [-16.139,-7.535,54.847], color="red blue", name="Arrows_17.8819999695_7")

cluster_dict["17.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-14.5), float(-7.5), float(59.0), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-14.5,-7.5,59.0], [-17.239,-8.55,61.601], color="red blue", name="Arrows_17.8819999695_8")

cluster_dict["17.8819999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.0), float(-8.5), float(64.5), float(1.0)]

cluster_dict["17.8819999695_arrows"] += cgo_arrow([-13.0,-8.5,64.5], [-12.251,-12.296,64.021], color="red blue", name="Arrows_17.8819999695_9")

cmd.load_cgo(cluster_dict["17.8819999695"], "Features_17.8819999695", 1)
cmd.load_cgo(cluster_dict["17.8819999695_arrows"], "Arrows_17.8819999695")
cmd.set("transparency", 0.2,"Features_17.8819999695")
cmd.group("Pharmacophore_17.8819999695", members="Features_17.8819999695")
cmd.group("Pharmacophore_17.8819999695", members="Arrows_17.8819999695")

if dirpath:
    f = join(dirpath, "label_threshold_17.8819999695.mol2")
else:
    f = "label_threshold_17.8819999695.mol2"

cmd.load(f, 'label_threshold_17.8819999695')
cmd.hide('everything', 'label_threshold_17.8819999695')
cmd.label("label_threshold_17.8819999695", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.8819999695', members= 'label_threshold_17.8819999695')
