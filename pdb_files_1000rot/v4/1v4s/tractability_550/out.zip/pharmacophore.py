
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.9219999313":[], "13.9219999313_arrows":[]}

cluster_dict["13.9219999313"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(36.5), float(19.0), float(57.0), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([36.5,19.0,57.0], [34.748,16.322,56.81], color="blue red", name="Arrows_13.9219999313_1")

cluster_dict["13.9219999313"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(38.5), float(16.5), float(61.0), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([38.5,16.5,61.0], [40.059,15.519,58.856], color="blue red", name="Arrows_13.9219999313_2")

cluster_dict["13.9219999313"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(40.0), float(25.0), float(60.0), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([40.0,25.0,60.0], [41.15,24.881,62.774], color="blue red", name="Arrows_13.9219999313_3")

cluster_dict["13.9219999313"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(42.0), float(10.0), float(63.0), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([42.0,10.0,63.0], [43.007,7.661,65.091], color="blue red", name="Arrows_13.9219999313_4")

cluster_dict["13.9219999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(39.4301003474), float(17.6985436279), float(60.5355996855), float(1.0)]


cluster_dict["13.9219999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(40.5014450982), float(23.2015397666), float(60.5519483754), float(1.0)]


cluster_dict["13.9219999313"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(40.6176470588), float(23.8529411765), float(61.0), float(1.0)]


cluster_dict["13.9219999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(37.5), float(17.5), float(63.0), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([37.5,17.5,63.0], [35.617,18.465,66.87], color="red blue", name="Arrows_13.9219999313_5")

cluster_dict["13.9219999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(40.0), float(17.0), float(65.5), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([40.0,17.0,65.5], [42.04,17.748,66.666], color="red blue", name="Arrows_13.9219999313_6")

cluster_dict["13.9219999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(40.0), float(18.0), float(61.5), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([40.0,18.0,61.5], [43.012,15.508,59.647], color="red blue", name="Arrows_13.9219999313_7")

cluster_dict["13.9219999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(41.0), float(11.0), float(64.0), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([41.0,11.0,64.0], [37.79,10.544,67.284], color="red blue", name="Arrows_13.9219999313_8")

cluster_dict["13.9219999313"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(41.5), float(18.0), float(62.5), float(1.0)]

cluster_dict["13.9219999313_arrows"] += cgo_arrow([41.5,18.0,62.5], [45.018,17.321,62.219], color="red blue", name="Arrows_13.9219999313_9")

cmd.load_cgo(cluster_dict["13.9219999313"], "Features_13.9219999313", 1)
cmd.load_cgo(cluster_dict["13.9219999313_arrows"], "Arrows_13.9219999313")
cmd.set("transparency", 0.2,"Features_13.9219999313")
cmd.group("Pharmacophore_13.9219999313", members="Features_13.9219999313")
cmd.group("Pharmacophore_13.9219999313", members="Arrows_13.9219999313")

if dirpath:
    f = join(dirpath, "label_threshold_13.9219999313.mol2")
else:
    f = "label_threshold_13.9219999313.mol2"

cmd.load(f, 'label_threshold_13.9219999313')
cmd.hide('everything', 'label_threshold_13.9219999313')
cmd.label("label_threshold_13.9219999313", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.9219999313', members= 'label_threshold_13.9219999313')
