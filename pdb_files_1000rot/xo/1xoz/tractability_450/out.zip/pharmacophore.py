
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"18.8850002289":[], "18.8850002289_arrows":[]}

cluster_dict["18.8850002289"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(43.0), float(39.0), float(19.5), float(1.0)]

cluster_dict["18.8850002289_arrows"] += cgo_arrow([43.0,39.0,19.5], [45.249,40.474,18.915], color="blue red", name="Arrows_18.8850002289_1")

cluster_dict["18.8850002289"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(45.0), float(36.5), float(10.0), float(1.0)]

cluster_dict["18.8850002289_arrows"] += cgo_arrow([45.0,36.5,10.0], [46.98,35.513,7.652], color="blue red", name="Arrows_18.8850002289_2")

cluster_dict["18.8850002289"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(52.0), float(37.0), float(10.5), float(1.0)]

cluster_dict["18.8850002289_arrows"] += cgo_arrow([52.0,37.0,10.5], [54.453,36.097,11.926], color="blue red", name="Arrows_18.8850002289_3")

cluster_dict["18.8850002289"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(47.0072273691), float(34.8600506013), float(13.3352835539), float(1.0)]


cluster_dict["18.8850002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(44.0), float(35.0), float(10.0), float(1.0)]

cluster_dict["18.8850002289_arrows"] += cgo_arrow([44.0,35.0,10.0], [45.729,33.684,7.995], color="red blue", name="Arrows_18.8850002289_4")

cluster_dict["18.8850002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(43.0), float(38.0), float(16.5), float(1.0)]

cluster_dict["18.8850002289_arrows"] += cgo_arrow([43.0,38.0,16.5], [41.879,39.772,14.796], color="red blue", name="Arrows_18.8850002289_5")

cluster_dict["18.8850002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(46.0), float(36.5), float(12.5), float(1.0)]


cluster_dict["18.8850002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(46.0), float(37.5), float(10.0), float(1.0)]

cluster_dict["18.8850002289_arrows"] += cgo_arrow([46.0,37.5,10.0], [45.729,33.684,7.995], color="red blue", name="Arrows_18.8850002289_6")

cluster_dict["18.8850002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(37.5), float(19.5), float(1.0)]

cluster_dict["18.8850002289_arrows"] += cgo_arrow([48.0,37.5,19.5], [46.853,41.904,18.83], color="red blue", name="Arrows_18.8850002289_7")

cluster_dict["18.8850002289"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(51.0), float(35.0), float(8.0), float(1.0)]

cluster_dict["18.8850002289_arrows"] += cgo_arrow([51.0,35.0,8.0], [53.535,33.389,4.555], color="red blue", name="Arrows_18.8850002289_8")

cmd.load_cgo(cluster_dict["18.8850002289"], "Features_18.8850002289", 1)
cmd.load_cgo(cluster_dict["18.8850002289_arrows"], "Arrows_18.8850002289")
cmd.set("transparency", 0.2,"Features_18.8850002289")
cmd.group("Pharmacophore_18.8850002289", members="Features_18.8850002289")
cmd.group("Pharmacophore_18.8850002289", members="Arrows_18.8850002289")

if dirpath:
    f = join(dirpath, "label_threshold_18.8850002289.mol2")
else:
    f = "label_threshold_18.8850002289.mol2"

cmd.load(f, 'label_threshold_18.8850002289')
cmd.hide('everything', 'label_threshold_18.8850002289')
cmd.label("label_threshold_18.8850002289", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_18.8850002289', members= 'label_threshold_18.8850002289')
