
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.7399997711":[], "13.7399997711_arrows":[]}

cluster_dict["13.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(7.0), float(12.0), float(27.0), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([7.0,12.0,27.0], [5.78,10.478,24.794], color="blue red", name="Arrows_13.7399997711_1")

cluster_dict["13.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(13.5), float(18.0), float(25.5), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([13.5,18.0,25.5], [12.721,19.487,23.066], color="blue red", name="Arrows_13.7399997711_2")

cluster_dict["13.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(18.5), float(29.5), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([13.0,18.5,29.5], [11.952,19.883,31.578], color="blue red", name="Arrows_13.7399997711_3")

cluster_dict["13.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(12.5), float(11.0), float(24.5), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([12.5,11.0,24.5], [10.052,12.521,24.252], color="blue red", name="Arrows_13.7399997711_4")

cluster_dict["13.7399997711"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.0), float(15.5), float(22.5), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([19.0,15.5,22.5], [19.446,13.652,20.202], color="blue red", name="Arrows_13.7399997711_5")

cluster_dict["13.7399997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(6.55530878794), float(12.2314678658), float(28.0755469846), float(1.0)]


cluster_dict["13.7399997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(7.33413119944), float(18.6651806413), float(21.5), float(1.0)]


cluster_dict["13.7399997711"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(12.0815182225), float(16.2433398891), float(26.6827539756), float(1.0)]


cluster_dict["13.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(5.5), float(12.5), float(29.0), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([5.5,12.5,29.0], [8.885,11.712,30.818], color="red blue", name="Arrows_13.7399997711_6")

cluster_dict["13.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(7.5), float(19.5), float(26.5), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([7.5,19.5,26.5], [4.514,19.97,26.919], color="red blue", name="Arrows_13.7399997711_7")

cluster_dict["13.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.5), float(17.0), float(25.5), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([13.5,17.0,25.5], [12.721,19.487,23.066], color="red blue", name="Arrows_13.7399997711_8")

cluster_dict["13.7399997711"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(16.5), float(11.5), float(23.0), float(1.0)]

cluster_dict["13.7399997711_arrows"] += cgo_arrow([16.5,11.5,23.0], [16.579,8.495,22.858], color="red blue", name="Arrows_13.7399997711_9")

cmd.load_cgo(cluster_dict["13.7399997711"], "Features_13.7399997711", 1)
cmd.load_cgo(cluster_dict["13.7399997711_arrows"], "Arrows_13.7399997711")
cmd.set("transparency", 0.2,"Features_13.7399997711")
cmd.group("Pharmacophore_13.7399997711", members="Features_13.7399997711")
cmd.group("Pharmacophore_13.7399997711", members="Arrows_13.7399997711")

if dirpath:
    f = join(dirpath, "label_threshold_13.7399997711.mol2")
else:
    f = "label_threshold_13.7399997711.mol2"

cmd.load(f, 'label_threshold_13.7399997711')
cmd.hide('everything', 'label_threshold_13.7399997711')
cmd.label("label_threshold_13.7399997711", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.7399997711', members= 'label_threshold_13.7399997711')
