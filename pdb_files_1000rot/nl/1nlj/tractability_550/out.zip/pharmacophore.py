
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"10.0089998245":[], "10.0089998245_arrows":[]}

cluster_dict["10.0089998245"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(35.0), float(-38.0), float(-4.5), float(1.0)]

cluster_dict["10.0089998245_arrows"] += cgo_arrow([35.0,-38.0,-4.5], [36.946,-40.25,-3.615], color="blue red", name="Arrows_10.0089998245_1")

cluster_dict["10.0089998245"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(37.6085607517), float(-36.5251779219), float(-5.36439984375), float(1.0)]


cluster_dict["10.0089998245"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(41.5), float(-35.5), float(-5.5), float(1.0)]

cluster_dict["10.0089998245_arrows"] += cgo_arrow([41.5,-35.5,-5.5], [43.198,-38.005,-4.432], color="red blue", name="Arrows_10.0089998245_2")

cmd.load_cgo(cluster_dict["10.0089998245"], "Features_10.0089998245", 1)
cmd.load_cgo(cluster_dict["10.0089998245_arrows"], "Arrows_10.0089998245")
cmd.set("transparency", 0.2,"Features_10.0089998245")
cmd.group("Pharmacophore_10.0089998245", members="Features_10.0089998245")
cmd.group("Pharmacophore_10.0089998245", members="Arrows_10.0089998245")

if dirpath:
    f = join(dirpath, "label_threshold_10.0089998245.mol2")
else:
    f = "label_threshold_10.0089998245.mol2"

cmd.load(f, 'label_threshold_10.0089998245')
cmd.hide('everything', 'label_threshold_10.0089998245')
cmd.label("label_threshold_10.0089998245", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_10.0089998245', members= 'label_threshold_10.0089998245')
