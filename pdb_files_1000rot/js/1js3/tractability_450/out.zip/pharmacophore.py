
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.876999855":[], "13.876999855_arrows":[]}

cluster_dict["13.876999855"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(54.0), float(14.5), float(86.5), float(1.0)]

cluster_dict["13.876999855_arrows"] += cgo_arrow([54.0,14.5,86.5], [56.522,13.369,87.687], color="blue red", name="Arrows_13.876999855_1")

cluster_dict["13.876999855"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(54.0), float(17.0), float(81.5), float(1.0)]

cluster_dict["13.876999855_arrows"] += cgo_arrow([54.0,17.0,81.5], [56.376,16.304,83.272], color="blue red", name="Arrows_13.876999855_2")

cluster_dict["13.876999855"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(55.0), float(18.5), float(86.5), float(1.0)]

cluster_dict["13.876999855_arrows"] += cgo_arrow([55.0,18.5,86.5], [56.042,20.207,88.973], color="blue red", name="Arrows_13.876999855_3")

cluster_dict["13.876999855"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(55.0), float(17.0), float(88.0), float(1.0)]

cluster_dict["13.876999855_arrows"] += cgo_arrow([55.0,17.0,88.0], [56.042,20.207,88.973], color="blue red", name="Arrows_13.876999855_4")

cluster_dict["13.876999855"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(53.1532800441), float(13.6807624886), float(82.9746483437), float(1.0)]


cluster_dict["13.876999855"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(50.5), float(11.0), float(83.5), float(1.0)]

cluster_dict["13.876999855_arrows"] += cgo_arrow([50.5,11.0,83.5], [50.505,8.932,85.935], color="red blue", name="Arrows_13.876999855_5")

cluster_dict["13.876999855"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(53.5), float(20.0), float(85.0), float(1.0)]

cluster_dict["13.876999855_arrows"] += cgo_arrow([53.5,20.0,85.0], [53.076,22.34,83.177], color="red blue", name="Arrows_13.876999855_6")

cluster_dict["13.876999855"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(55.5), float(9.0), float(84.5), float(1.0)]

cluster_dict["13.876999855_arrows"] += cgo_arrow([55.5,9.0,84.5], [54.183,6.069,87.338], color="red blue", name="Arrows_13.876999855_7")

cmd.load_cgo(cluster_dict["13.876999855"], "Features_13.876999855", 1)
cmd.load_cgo(cluster_dict["13.876999855_arrows"], "Arrows_13.876999855")
cmd.set("transparency", 0.2,"Features_13.876999855")
cmd.group("Pharmacophore_13.876999855", members="Features_13.876999855")
cmd.group("Pharmacophore_13.876999855", members="Arrows_13.876999855")

if dirpath:
    f = join(dirpath, "label_threshold_13.876999855.mol2")
else:
    f = "label_threshold_13.876999855.mol2"

cmd.load(f, 'label_threshold_13.876999855')
cmd.hide('everything', 'label_threshold_13.876999855')
cmd.label("label_threshold_13.876999855", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.876999855', members= 'label_threshold_13.876999855')
