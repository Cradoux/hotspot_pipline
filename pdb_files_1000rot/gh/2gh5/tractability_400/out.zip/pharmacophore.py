
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.5830001831":[], "13.5830001831_arrows":[]}

cluster_dict["13.5830001831"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(96.0), float(16.5), float(100.0), float(1.0)]

cluster_dict["13.5830001831_arrows"] += cgo_arrow([96.0,16.5,100.0], [95.246,15.863,102.643], color="blue red", name="Arrows_13.5830001831_1")

cluster_dict["13.5830001831"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(97.5696017131), float(20.48319425), float(95.695929333), float(1.0)]


cluster_dict["13.5830001831"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(102.957615586), float(10.9383812572), float(90.9728951678), float(1.0)]


cluster_dict["13.5830001831"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(101.928571429), float(9.85714285714), float(88.5), float(1.0)]


cluster_dict["13.5830001831"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(95.5), float(18.0), float(98.5), float(1.0)]

cluster_dict["13.5830001831_arrows"] += cgo_arrow([95.5,18.0,98.5], [93.358,18.6,99.599], color="red blue", name="Arrows_13.5830001831_2")

cluster_dict["13.5830001831"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(99.5), float(24.5), float(92.5), float(1.0)]

cluster_dict["13.5830001831_arrows"] += cgo_arrow([99.5,24.5,92.5], [99.478,26.029,94.674], color="red blue", name="Arrows_13.5830001831_3")

cluster_dict["13.5830001831"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(101.5), float(10.0), float(89.5), float(1.0)]

cluster_dict["13.5830001831_arrows"] += cgo_arrow([101.5,10.0,89.5], [99.053,9.698,91.013], color="red blue", name="Arrows_13.5830001831_4")

cmd.load_cgo(cluster_dict["13.5830001831"], "Features_13.5830001831", 1)
cmd.load_cgo(cluster_dict["13.5830001831_arrows"], "Arrows_13.5830001831")
cmd.set("transparency", 0.2,"Features_13.5830001831")
cmd.group("Pharmacophore_13.5830001831", members="Features_13.5830001831")
cmd.group("Pharmacophore_13.5830001831", members="Arrows_13.5830001831")

if dirpath:
    f = join(dirpath, "label_threshold_13.5830001831.mol2")
else:
    f = "label_threshold_13.5830001831.mol2"

cmd.load(f, 'label_threshold_13.5830001831')
cmd.hide('everything', 'label_threshold_13.5830001831')
cmd.label("label_threshold_13.5830001831", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.5830001831', members= 'label_threshold_13.5830001831')
