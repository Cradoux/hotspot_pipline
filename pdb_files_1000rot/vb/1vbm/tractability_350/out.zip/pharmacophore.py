
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.6049995422":[], "13.6049995422_arrows":[]}

cluster_dict["13.6049995422"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-6.5), float(170.0), float(250.0), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([-6.5,170.0,250.0], [-7.174,168.495,252.421], color="blue red", name="Arrows_13.6049995422_1")

cluster_dict["13.6049995422"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(8.0), float(172.5), float(243.0), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([8.0,172.5,243.0], [8.171,169.572,243.039], color="blue red", name="Arrows_13.6049995422_2")

cluster_dict["13.6049995422"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(0.942260668013), float(170.890636282), float(247.181586536), float(1.0)]


cluster_dict["13.6049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-4.5), float(171.5), float(243.0), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([-4.5,171.5,243.0], [-3.698,170.471,239.959], color="red blue", name="Arrows_13.6049995422_3")

cluster_dict["13.6049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(0.0), float(172.5), float(249.0), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([0.0,172.5,249.0], [-1.924,175.146,250.952], color="red blue", name="Arrows_13.6049995422_4")

cluster_dict["13.6049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(1.5), float(174.0), float(248.5), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([1.5,174.0,248.5], [-1.924,175.146,250.952], color="red blue", name="Arrows_13.6049995422_5")

cluster_dict["13.6049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(1.5), float(175.0), float(246.5), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([1.5,175.0,246.5], [-0.871,177.659,247.845], color="red blue", name="Arrows_13.6049995422_6")

cluster_dict["13.6049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(6.0), float(171.5), float(242.5), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([6.0,171.5,242.5], [6.519,172.682,240.438], color="red blue", name="Arrows_13.6049995422_7")

cluster_dict["13.6049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(8.0), float(171.0), float(247.5), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([8.0,171.0,247.5], [8.705,173.68,248.6], color="red blue", name="Arrows_13.6049995422_8")

cluster_dict["13.6049995422"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(9.0), float(173.5), float(242.5), float(1.0)]

cluster_dict["13.6049995422_arrows"] += cgo_arrow([9.0,173.5,242.5], [8.818,175.477,240.354], color="red blue", name="Arrows_13.6049995422_9")

cmd.load_cgo(cluster_dict["13.6049995422"], "Features_13.6049995422", 1)
cmd.load_cgo(cluster_dict["13.6049995422_arrows"], "Arrows_13.6049995422")
cmd.set("transparency", 0.2,"Features_13.6049995422")
cmd.group("Pharmacophore_13.6049995422", members="Features_13.6049995422")
cmd.group("Pharmacophore_13.6049995422", members="Arrows_13.6049995422")

if dirpath:
    f = join(dirpath, "label_threshold_13.6049995422.mol2")
else:
    f = "label_threshold_13.6049995422.mol2"

cmd.load(f, 'label_threshold_13.6049995422')
cmd.hide('everything', 'label_threshold_13.6049995422')
cmd.label("label_threshold_13.6049995422", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.6049995422', members= 'label_threshold_13.6049995422')
