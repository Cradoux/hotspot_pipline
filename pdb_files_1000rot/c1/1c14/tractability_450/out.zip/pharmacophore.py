
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.0520000458":[], "16.0520000458_arrows":[]}

cluster_dict["16.0520000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-17.5), float(39.0), float(159.5), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-17.5,39.0,159.5], [-17.541,35.942,159.367], color="blue red", name="Arrows_16.0520000458_1")

cluster_dict["16.0520000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(44.0), float(153.5), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-13.5,44.0,153.5], [-15.183,43.615,151.35], color="blue red", name="Arrows_16.0520000458_2")

cluster_dict["16.0520000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(44.0), float(153.5), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-13.5,44.0,153.5], [-15.183,43.615,151.35], color="blue red", name="Arrows_16.0520000458_3")

cluster_dict["16.0520000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-11.5), float(44.5), float(156.0), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-11.5,44.5,156.0], [-10.598,46.675,158.06], color="blue red", name="Arrows_16.0520000458_4")

cluster_dict["16.0520000458"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-9.0), float(47.0), float(156.0), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-9.0,47.0,156.0], [-10.598,46.675,158.06], color="blue red", name="Arrows_16.0520000458_5")

cluster_dict["16.0520000458"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-9.87121537339), float(42.2707257446), float(156.102842606), float(1.0)]


cluster_dict["16.0520000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.0), float(44.0), float(154.5), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-13.0,44.0,154.5], [-15.183,43.615,151.35], color="red blue", name="Arrows_16.0520000458_6")

cluster_dict["16.0520000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.0), float(44.0), float(154.5), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-13.0,44.0,154.5], [-15.183,43.615,151.35], color="red blue", name="Arrows_16.0520000458_7")

cluster_dict["16.0520000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.0), float(43.0), float(151.0), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-9.0,43.0,151.0], [-8.173,39.85,150.66], color="red blue", name="Arrows_16.0520000458_8")

cluster_dict["16.0520000458"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-6.0), float(42.0), float(154.5), float(1.0)]

cluster_dict["16.0520000458_arrows"] += cgo_arrow([-6.0,42.0,154.5], [-4.263,41.005,152.854], color="red blue", name="Arrows_16.0520000458_9")

cmd.load_cgo(cluster_dict["16.0520000458"], "Features_16.0520000458", 1)
cmd.load_cgo(cluster_dict["16.0520000458_arrows"], "Arrows_16.0520000458")
cmd.set("transparency", 0.2,"Features_16.0520000458")
cmd.group("Pharmacophore_16.0520000458", members="Features_16.0520000458")
cmd.group("Pharmacophore_16.0520000458", members="Arrows_16.0520000458")

if dirpath:
    f = join(dirpath, "label_threshold_16.0520000458.mol2")
else:
    f = "label_threshold_16.0520000458.mol2"

cmd.load(f, 'label_threshold_16.0520000458')
cmd.hide('everything', 'label_threshold_16.0520000458')
cmd.label("label_threshold_16.0520000458", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.0520000458', members= 'label_threshold_16.0520000458')
