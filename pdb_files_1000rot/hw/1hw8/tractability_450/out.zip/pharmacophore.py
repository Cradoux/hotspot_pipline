
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"14.9870004654":[], "14.9870004654_arrows":[]}

cluster_dict["14.9870004654"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(44.0), float(12.5), float(28.5), float(1.0)]

cluster_dict["14.9870004654_arrows"] += cgo_arrow([44.0,12.5,28.5], [41.786,14.469,27.818], color="blue red", name="Arrows_14.9870004654_1")

cluster_dict["14.9870004654"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(44.0), float(15.0), float(28.0), float(1.0)]

cluster_dict["14.9870004654_arrows"] += cgo_arrow([44.0,15.0,28.0], [41.786,14.469,27.818], color="blue red", name="Arrows_14.9870004654_2")

cluster_dict["14.9870004654"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(48.0), float(15.5), float(32.0), float(1.0)]


cluster_dict["14.9870004654"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(48.5), float(16.0), float(25.5), float(1.0)]

cluster_dict["14.9870004654_arrows"] += cgo_arrow([48.5,16.0,25.5], [45.688,15.521,25.708], color="blue red", name="Arrows_14.9870004654_3")

cluster_dict["14.9870004654"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(45.7178098942), float(13.8219685097), float(30.3742787608), float(1.0)]


cluster_dict["14.9870004654"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(49.6761470618), float(15.2297223373), float(25.2979402632), float(1.0)]


cluster_dict["14.9870004654"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(42.5), float(16.0), float(32.5), float(1.0)]

cluster_dict["14.9870004654_arrows"] += cgo_arrow([42.5,16.0,32.5], [43.425,17.932,34.998], color="red blue", name="Arrows_14.9870004654_4")

cluster_dict["14.9870004654"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(44.0), float(13.0), float(26.5), float(1.0)]

cluster_dict["14.9870004654_arrows"] += cgo_arrow([44.0,13.0,26.5], [42.278,13.871,25.15], color="red blue", name="Arrows_14.9870004654_5")

cluster_dict["14.9870004654"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(47.5), float(13.0), float(33.0), float(1.0)]

cluster_dict["14.9870004654_arrows"] += cgo_arrow([47.5,13.0,33.0], [49.733,12.912,30.921], color="red blue", name="Arrows_14.9870004654_6")

cluster_dict["14.9870004654"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(49.0), float(15.5), float(30.0), float(1.0)]

cluster_dict["14.9870004654_arrows"] += cgo_arrow([49.0,15.5,30.0], [49.733,12.912,30.921], color="red blue", name="Arrows_14.9870004654_7")

cluster_dict["14.9870004654"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(49.0), float(10.5), float(25.0), float(1.0)]

cluster_dict["14.9870004654_arrows"] += cgo_arrow([49.0,10.5,25.0], [47.635,8.235,24.161], color="red blue", name="Arrows_14.9870004654_8")

cmd.load_cgo(cluster_dict["14.9870004654"], "Features_14.9870004654", 1)
cmd.load_cgo(cluster_dict["14.9870004654_arrows"], "Arrows_14.9870004654")
cmd.set("transparency", 0.2,"Features_14.9870004654")
cmd.group("Pharmacophore_14.9870004654", members="Features_14.9870004654")
cmd.group("Pharmacophore_14.9870004654", members="Arrows_14.9870004654")

if dirpath:
    f = join(dirpath, "label_threshold_14.9870004654.mol2")
else:
    f = "label_threshold_14.9870004654.mol2"

cmd.load(f, 'label_threshold_14.9870004654')
cmd.hide('everything', 'label_threshold_14.9870004654')
cmd.label("label_threshold_14.9870004654", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_14.9870004654', members= 'label_threshold_14.9870004654')
