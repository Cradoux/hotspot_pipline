
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.5750007629":[], "17.5750007629_arrows":[]}

cluster_dict["17.5750007629"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(16.0), float(16.5), float(33.0), float(1.0)]

cluster_dict["17.5750007629_arrows"] += cgo_arrow([16.0,16.5,33.0], [15.577,15.193,30.195], color="blue red", name="Arrows_17.5750007629_1")

cluster_dict["17.5750007629"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(22.5), float(11.0), float(28.5), float(1.0)]

cluster_dict["17.5750007629_arrows"] += cgo_arrow([22.5,11.0,28.5], [22.706,12.303,26.002], color="blue red", name="Arrows_17.5750007629_2")

cluster_dict["17.5750007629"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(4.5), float(29.0), float(1.0)]

cluster_dict["17.5750007629_arrows"] += cgo_arrow([26.0,4.5,29.0], [26.451,4.735,26.144], color="blue red", name="Arrows_17.5750007629_3")

cluster_dict["17.5750007629"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(22.0428522381), float(10.5661846958), float(32.3413396935), float(1.0)]


cluster_dict["17.5750007629"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(16.0), float(33.5), float(1.0)]

cluster_dict["17.5750007629_arrows"] += cgo_arrow([18.5,16.0,33.5], [20.616,17.371,33.653], color="red blue", name="Arrows_17.5750007629_4")

cluster_dict["17.5750007629"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(13.5), float(32.0), float(1.0)]

cluster_dict["17.5750007629_arrows"] += cgo_arrow([18.5,13.5,32.0], [20.616,17.371,33.653], color="red blue", name="Arrows_17.5750007629_5")

cluster_dict["17.5750007629"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(20.5), float(6.5), float(33.0), float(1.0)]

cluster_dict["17.5750007629_arrows"] += cgo_arrow([20.5,6.5,33.0], [19.211,3.764,32.937], color="red blue", name="Arrows_17.5750007629_6")

cluster_dict["17.5750007629"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(6.0), float(32.0), float(1.0)]


cluster_dict["17.5750007629"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.5), float(10.0), float(27.5), float(1.0)]

cluster_dict["17.5750007629_arrows"] += cgo_arrow([25.5,10.0,27.5], [25.881,9.008,25.363], color="red blue", name="Arrows_17.5750007629_7")

cluster_dict["17.5750007629"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(10.5), float(32.5), float(1.0)]

cluster_dict["17.5750007629_arrows"] += cgo_arrow([26.0,10.5,32.5], [28.772,9.721,33.856], color="red blue", name="Arrows_17.5750007629_8")

cmd.load_cgo(cluster_dict["17.5750007629"], "Features_17.5750007629", 1)
cmd.load_cgo(cluster_dict["17.5750007629_arrows"], "Arrows_17.5750007629")
cmd.set("transparency", 0.2,"Features_17.5750007629")
cmd.group("Pharmacophore_17.5750007629", members="Features_17.5750007629")
cmd.group("Pharmacophore_17.5750007629", members="Arrows_17.5750007629")

if dirpath:
    f = join(dirpath, "label_threshold_17.5750007629.mol2")
else:
    f = "label_threshold_17.5750007629.mol2"

cmd.load(f, 'label_threshold_17.5750007629')
cmd.hide('everything', 'label_threshold_17.5750007629')
cmd.label("label_threshold_17.5750007629", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.5750007629', members= 'label_threshold_17.5750007629')
