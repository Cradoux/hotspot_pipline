
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.232000351":[], "13.232000351_arrows":[]}

cluster_dict["13.232000351"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(59.5), float(32.0), float(117.0), float(1.0)]

cluster_dict["13.232000351_arrows"] += cgo_arrow([59.5,32.0,117.0], [60.583,33.744,115.515], color="blue red", name="Arrows_13.232000351_1")

cluster_dict["13.232000351"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(64.0), float(30.0), float(113.0), float(1.0)]

cluster_dict["13.232000351_arrows"] += cgo_arrow([64.0,30.0,113.0], [63.664,31.992,111.598], color="blue red", name="Arrows_13.232000351_2")

cluster_dict["13.232000351"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(67.0), float(31.5), float(115.5), float(1.0)]

cluster_dict["13.232000351_arrows"] += cgo_arrow([67.0,31.5,115.5], [64.649,33.659,116.258], color="blue red", name="Arrows_13.232000351_3")

cluster_dict["13.232000351"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(63.4929947765), float(30.0670127728), float(116.261403416), float(1.0)]


cluster_dict["13.232000351"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(61.5), float(29.0), float(119.0), float(1.0)]

cluster_dict["13.232000351_arrows"] += cgo_arrow([61.5,29.0,119.0], [62.626,33.117,120.114], color="red blue", name="Arrows_13.232000351_4")

cluster_dict["13.232000351"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(67.0), float(29.5), float(118.0), float(1.0)]

cluster_dict["13.232000351_arrows"] += cgo_arrow([67.0,29.5,118.0], [68.071,26.881,119.097], color="red blue", name="Arrows_13.232000351_5")

cluster_dict["13.232000351"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(65.0), float(32.0), float(119.5), float(1.0)]

cluster_dict["13.232000351_arrows"] += cgo_arrow([65.0,32.0,119.5], [62.626,33.117,120.114], color="red blue", name="Arrows_13.232000351_6")

cmd.load_cgo(cluster_dict["13.232000351"], "Features_13.232000351", 1)
cmd.load_cgo(cluster_dict["13.232000351_arrows"], "Arrows_13.232000351")
cmd.set("transparency", 0.2,"Features_13.232000351")
cmd.group("Pharmacophore_13.232000351", members="Features_13.232000351")
cmd.group("Pharmacophore_13.232000351", members="Arrows_13.232000351")

if dirpath:
    f = join(dirpath, "label_threshold_13.232000351.mol2")
else:
    f = "label_threshold_13.232000351.mol2"

cmd.load(f, 'label_threshold_13.232000351')
cmd.hide('everything', 'label_threshold_13.232000351')
cmd.label("label_threshold_13.232000351", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.232000351', members= 'label_threshold_13.232000351')
