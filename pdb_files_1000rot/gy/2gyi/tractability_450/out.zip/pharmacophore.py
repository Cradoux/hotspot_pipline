
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"11.8599996567":[], "11.8599996567_arrows":[]}

cluster_dict["11.8599996567"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(23.5), float(-4.0), float(-28.5), float(1.0)]

cluster_dict["11.8599996567_arrows"] += cgo_arrow([23.5,-4.0,-28.5], [21.75,-1.848,-27.796], color="blue red", name="Arrows_11.8599996567_1")

cluster_dict["11.8599996567"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(24.0), float(-6.5), float(-34.0), float(1.0)]

cluster_dict["11.8599996567_arrows"] += cgo_arrow([24.0,-6.5,-34.0], [26.385,-7.743,-34.855], color="blue red", name="Arrows_11.8599996567_2")

cluster_dict["11.8599996567"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(26.0), float(-3.5), float(-32.0), float(1.0)]

cluster_dict["11.8599996567_arrows"] += cgo_arrow([26.0,-3.5,-32.0], [24.896,-0.81,-33.27], color="blue red", name="Arrows_11.8599996567_3")

cluster_dict["11.8599996567"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(24.3775294972), float(-4.28103583272), float(-31.13804134), float(1.0)]


cluster_dict["11.8599996567"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.0), float(-7.5), float(-29.5), float(1.0)]

cluster_dict["11.8599996567_arrows"] += cgo_arrow([25.0,-7.5,-29.5], [24.778,-11.645,-28.107], color="red blue", name="Arrows_11.8599996567_4")

cmd.load_cgo(cluster_dict["11.8599996567"], "Features_11.8599996567", 1)
cmd.load_cgo(cluster_dict["11.8599996567_arrows"], "Arrows_11.8599996567")
cmd.set("transparency", 0.2,"Features_11.8599996567")
cmd.group("Pharmacophore_11.8599996567", members="Features_11.8599996567")
cmd.group("Pharmacophore_11.8599996567", members="Arrows_11.8599996567")

if dirpath:
    f = join(dirpath, "label_threshold_11.8599996567.mol2")
else:
    f = "label_threshold_11.8599996567.mol2"

cmd.load(f, 'label_threshold_11.8599996567')
cmd.hide('everything', 'label_threshold_11.8599996567')
cmd.label("label_threshold_11.8599996567", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_11.8599996567', members= 'label_threshold_11.8599996567')
