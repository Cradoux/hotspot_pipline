
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.6780004501":[], "13.6780004501_arrows":[]}

cluster_dict["13.6780004501"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-2.5), float(1.5), float(27.0), float(1.0)]

cluster_dict["13.6780004501_arrows"] += cgo_arrow([-2.5,1.5,27.0], [-1.429,3.89,26.009], color="blue red", name="Arrows_13.6780004501_1")

cluster_dict["13.6780004501"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-2.5), float(1.5), float(27.0), float(1.0)]

cluster_dict["13.6780004501_arrows"] += cgo_arrow([-2.5,1.5,27.0], [-1.429,3.89,26.009], color="blue red", name="Arrows_13.6780004501_2")

cluster_dict["13.6780004501"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(1.0), float(-0.5), float(24.5), float(1.0)]

cluster_dict["13.6780004501_arrows"] += cgo_arrow([1.0,-0.5,24.5], [0.001,-3.215,25.543], color="blue red", name="Arrows_13.6780004501_3")

cluster_dict["13.6780004501"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-4.1009560358), float(2.11675104486), float(27.5936892568), float(1.0)]


cluster_dict["13.6780004501"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(2.0), float(-1.2), float(22.8), float(1.0)]


cluster_dict["13.6780004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-5.0), float(2.0), float(25.5), float(1.0)]

cluster_dict["13.6780004501_arrows"] += cgo_arrow([-5.0,2.0,25.5], [-8.314,2.092,26.001], color="red blue", name="Arrows_13.6780004501_4")

cluster_dict["13.6780004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-5.0), float(2.0), float(23.0), float(1.0)]

cluster_dict["13.6780004501_arrows"] += cgo_arrow([-5.0,2.0,23.0], [-6.691,4.697,22.392], color="red blue", name="Arrows_13.6780004501_5")

cluster_dict["13.6780004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-5.0), float(2.0), float(25.5), float(1.0)]

cluster_dict["13.6780004501_arrows"] += cgo_arrow([-5.0,2.0,25.5], [-8.314,2.092,26.001], color="red blue", name="Arrows_13.6780004501_6")

cluster_dict["13.6780004501"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-3.5), float(4.5), float(29.5), float(1.0)]

cluster_dict["13.6780004501_arrows"] += cgo_arrow([-3.5,4.5,29.5], [-1.861,6.026,25.478], color="red blue", name="Arrows_13.6780004501_7")

cmd.load_cgo(cluster_dict["13.6780004501"], "Features_13.6780004501", 1)
cmd.load_cgo(cluster_dict["13.6780004501_arrows"], "Arrows_13.6780004501")
cmd.set("transparency", 0.2,"Features_13.6780004501")
cmd.group("Pharmacophore_13.6780004501", members="Features_13.6780004501")
cmd.group("Pharmacophore_13.6780004501", members="Arrows_13.6780004501")

if dirpath:
    f = join(dirpath, "label_threshold_13.6780004501.mol2")
else:
    f = "label_threshold_13.6780004501.mol2"

cmd.load(f, 'label_threshold_13.6780004501')
cmd.hide('everything', 'label_threshold_13.6780004501')
cmd.label("label_threshold_13.6780004501", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.6780004501', members= 'label_threshold_13.6780004501')
