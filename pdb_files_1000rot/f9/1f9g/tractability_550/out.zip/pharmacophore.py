
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.9610004425":[], "13.9610004425_arrows":[]}

cluster_dict["13.9610004425"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(-12.0), float(35.0), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([2.5,-12.0,35.0], [4.182,-11.8,37.801], color="blue red", name="Arrows_13.9610004425_1")

cluster_dict["13.9610004425"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(2.5), float(-12.0), float(35.0), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([2.5,-12.0,35.0], [4.182,-11.8,37.801], color="blue red", name="Arrows_13.9610004425_2")

cluster_dict["13.9610004425"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(5.0), float(-13.0), float(28.0), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([5.0,-13.0,28.0], [7.055,-14.065,26.312], color="blue red", name="Arrows_13.9610004425_3")

cluster_dict["13.9610004425"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(11.0), float(-11.5), float(32.5), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([11.0,-11.5,32.5], [10.675,-10.839,35.78], color="blue red", name="Arrows_13.9610004425_4")

cluster_dict["13.9610004425"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(11.0), float(-11.5), float(32.5), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([11.0,-11.5,32.5], [10.675,-10.839,35.78], color="blue red", name="Arrows_13.9610004425_5")

cluster_dict["13.9610004425"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(7.91474209506), float(-11.2417660247), float(32.5353108291), float(1.0)]


cluster_dict["13.9610004425"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(4.0), float(-6.5), float(34.0), float(1.0)]


cluster_dict["13.9610004425"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(6.16798718619), float(-6.5), float(33.9991054578), float(1.0)]


cluster_dict["13.9610004425"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(8.5), float(-6.5), float(35.5), float(1.0)]


cluster_dict["13.9610004425"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(13.9366645171), float(-13.6208623951), float(33.5230599779), float(1.0)]


cluster_dict["13.9610004425"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(14.75), float(-10.0), float(34.5), float(1.0)]


cluster_dict["13.9610004425"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(2.0), float(-11.5), float(27.0), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([2.0,-11.5,27.0], [3.279,-10.274,24.325], color="red blue", name="Arrows_13.9610004425_6")

cluster_dict["13.9610004425"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(3.0), float(-13.0), float(35.5), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([3.0,-13.0,35.5], [4.182,-11.8,37.801], color="red blue", name="Arrows_13.9610004425_7")

cluster_dict["13.9610004425"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(2.0), float(-11.5), float(27.0), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([2.0,-11.5,27.0], [3.279,-10.274,24.325], color="red blue", name="Arrows_13.9610004425_8")

cluster_dict["13.9610004425"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(13.0), float(-15.5), float(31.5), float(1.0)]

cluster_dict["13.9610004425_arrows"] += cgo_arrow([13.0,-15.5,31.5], [12.103,-17.645,30.042], color="red blue", name="Arrows_13.9610004425_9")

cmd.load_cgo(cluster_dict["13.9610004425"], "Features_13.9610004425", 1)
cmd.load_cgo(cluster_dict["13.9610004425_arrows"], "Arrows_13.9610004425")
cmd.set("transparency", 0.2,"Features_13.9610004425")
cmd.group("Pharmacophore_13.9610004425", members="Features_13.9610004425")
cmd.group("Pharmacophore_13.9610004425", members="Arrows_13.9610004425")

if dirpath:
    f = join(dirpath, "label_threshold_13.9610004425.mol2")
else:
    f = "label_threshold_13.9610004425.mol2"

cmd.load(f, 'label_threshold_13.9610004425')
cmd.hide('everything', 'label_threshold_13.9610004425')
cmd.label("label_threshold_13.9610004425", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.9610004425', members= 'label_threshold_13.9610004425')
