
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"18.2880001068":[], "18.2880001068_arrows":[]}

cluster_dict["18.2880001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-12.5), float(92.0), float(25.5), float(1.0)]

cluster_dict["18.2880001068_arrows"] += cgo_arrow([-12.5,92.0,25.5], [-11.32,91.433,27.948], color="blue red", name="Arrows_18.2880001068_1")

cluster_dict["18.2880001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-11.0), float(96.5), float(14.5), float(1.0)]

cluster_dict["18.2880001068_arrows"] += cgo_arrow([-11.0,96.5,14.5], [-11.776,98.791,11.921], color="blue red", name="Arrows_18.2880001068_2")

cluster_dict["18.2880001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-10.0), float(96.5), float(15.5), float(1.0)]

cluster_dict["18.2880001068_arrows"] += cgo_arrow([-10.0,96.5,15.5], [-8.732,93.236,15.72], color="blue red", name="Arrows_18.2880001068_3")

cluster_dict["18.2880001068"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-9.5), float(95.5), float(22.5), float(1.0)]

cluster_dict["18.2880001068_arrows"] += cgo_arrow([-9.5,95.5,22.5], [-8.543,93.787,23.903], color="blue red", name="Arrows_18.2880001068_4")

cluster_dict["18.2880001068"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-12.4681046087), float(94.7344069189), float(21.3228688288), float(1.0)]


cluster_dict["18.2880001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(97.5), float(15.0), float(1.0)]

cluster_dict["18.2880001068_arrows"] += cgo_arrow([-13.5,97.5,15.0], [-11.776,98.791,11.921], color="red blue", name="Arrows_18.2880001068_5")

cluster_dict["18.2880001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-9.5), float(97.0), float(20.0), float(1.0)]

cluster_dict["18.2880001068_arrows"] += cgo_arrow([-9.5,97.0,20.0], [-8.429,98.737,22.114], color="red blue", name="Arrows_18.2880001068_6")

cluster_dict["18.2880001068"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-8.0), float(98.0), float(16.5), float(1.0)]

cluster_dict["18.2880001068_arrows"] += cgo_arrow([-8.0,98.0,16.5], [-5.737,97.286,18.551], color="red blue", name="Arrows_18.2880001068_7")

cmd.load_cgo(cluster_dict["18.2880001068"], "Features_18.2880001068", 1)
cmd.load_cgo(cluster_dict["18.2880001068_arrows"], "Arrows_18.2880001068")
cmd.set("transparency", 0.2,"Features_18.2880001068")
cmd.group("Pharmacophore_18.2880001068", members="Features_18.2880001068")
cmd.group("Pharmacophore_18.2880001068", members="Arrows_18.2880001068")

if dirpath:
    f = join(dirpath, "label_threshold_18.2880001068.mol2")
else:
    f = "label_threshold_18.2880001068.mol2"

cmd.load(f, 'label_threshold_18.2880001068')
cmd.hide('everything', 'label_threshold_18.2880001068')
cmd.label("label_threshold_18.2880001068", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_18.2880001068', members= 'label_threshold_18.2880001068')
