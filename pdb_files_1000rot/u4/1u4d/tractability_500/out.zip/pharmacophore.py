
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"17.7840003967":[], "17.7840003967_arrows":[]}

cluster_dict["17.7840003967"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(15.0), float(57.0), float(1.0)]

cluster_dict["17.7840003967_arrows"] += cgo_arrow([19.5,15.0,57.0], [17.441,14.76,54.737], color="blue red", name="Arrows_17.7840003967_1")

cluster_dict["17.7840003967"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(13.5), float(53.5), float(1.0)]

cluster_dict["17.7840003967_arrows"] += cgo_arrow([19.5,13.5,53.5], [17.441,14.76,54.737], color="blue red", name="Arrows_17.7840003967_2")

cluster_dict["17.7840003967"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(12.0), float(57.5), float(1.0)]

cluster_dict["17.7840003967_arrows"] += cgo_arrow([27.5,12.0,57.5], [27.369,10.108,59.891], color="blue red", name="Arrows_17.7840003967_3")

cluster_dict["17.7840003967"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(28.5), float(18.5), float(56.5), float(1.0)]

cluster_dict["17.7840003967_arrows"] += cgo_arrow([28.5,18.5,56.5], [27.775,18.719,53.781], color="blue red", name="Arrows_17.7840003967_4")

cluster_dict["17.7840003967"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(24.5120911887), float(15.7387688107), float(56.3565334443), float(1.0)]


cluster_dict["17.7840003967"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(18.5), float(15.5), float(57.75), float(1.0)]


cluster_dict["17.7840003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(19.5), float(13.5), float(56.0), float(1.0)]

cluster_dict["17.7840003967_arrows"] += cgo_arrow([19.5,13.5,56.0], [17.441,14.76,54.737], color="red blue", name="Arrows_17.7840003967_5")

cluster_dict["17.7840003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(21.0), float(18.0), float(56.5), float(1.0)]

cluster_dict["17.7840003967_arrows"] += cgo_arrow([21.0,18.0,56.5], [19.197,20.094,58.5], color="red blue", name="Arrows_17.7840003967_6")

cluster_dict["17.7840003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(25.0), float(13.0), float(58.5), float(1.0)]

cluster_dict["17.7840003967_arrows"] += cgo_arrow([25.0,13.0,58.5], [21.913,9.676,59.261], color="red blue", name="Arrows_17.7840003967_7")

cluster_dict["17.7840003967"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(27.5), float(19.5), float(57.5), float(1.0)]

cluster_dict["17.7840003967_arrows"] += cgo_arrow([27.5,19.5,57.5], [26.946,19.397,60.322], color="red blue", name="Arrows_17.7840003967_8")

cmd.load_cgo(cluster_dict["17.7840003967"], "Features_17.7840003967", 1)
cmd.load_cgo(cluster_dict["17.7840003967_arrows"], "Arrows_17.7840003967")
cmd.set("transparency", 0.2,"Features_17.7840003967")
cmd.group("Pharmacophore_17.7840003967", members="Features_17.7840003967")
cmd.group("Pharmacophore_17.7840003967", members="Arrows_17.7840003967")

if dirpath:
    f = join(dirpath, "label_threshold_17.7840003967.mol2")
else:
    f = "label_threshold_17.7840003967.mol2"

cmd.load(f, 'label_threshold_17.7840003967')
cmd.hide('everything', 'label_threshold_17.7840003967')
cmd.label("label_threshold_17.7840003967", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_17.7840003967', members= 'label_threshold_17.7840003967')
