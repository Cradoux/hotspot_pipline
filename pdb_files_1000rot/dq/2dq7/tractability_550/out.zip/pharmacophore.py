
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"16.4850006104":[], "16.4850006104_arrows":[]}

cluster_dict["16.4850006104"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-18.5), float(16.0), float(-9.0), float(1.0)]

cluster_dict["16.4850006104_arrows"] += cgo_arrow([-18.5,16.0,-9.0], [-18.634,16.431,-5.819], color="blue red", name="Arrows_16.4850006104_1")

cluster_dict["16.4850006104"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-17.5), float(23.5), float(-13.5), float(1.0)]

cluster_dict["16.4850006104_arrows"] += cgo_arrow([-17.5,23.5,-13.5], [-20.65,24.124,-13.412], color="blue red", name="Arrows_16.4850006104_2")

cluster_dict["16.4850006104"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-17.5), float(19.0), float(-16.0), float(1.0)]

cluster_dict["16.4850006104_arrows"] += cgo_arrow([-17.5,19.0,-16.0], [-19.821,18.827,-18.047], color="blue red", name="Arrows_16.4850006104_3")

cluster_dict["16.4850006104"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-17.5), float(18.0), float(-8.0), float(1.0)]

cluster_dict["16.4850006104_arrows"] += cgo_arrow([-17.5,18.0,-8.0], [-18.634,16.431,-5.819], color="blue red", name="Arrows_16.4850006104_4")

cluster_dict["16.4850006104"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-15.0), float(13.5), float(-14.0), float(1.0)]

cluster_dict["16.4850006104_arrows"] += cgo_arrow([-15.0,13.5,-14.0], [-15.328,10.968,-12.529], color="blue red", name="Arrows_16.4850006104_5")

cluster_dict["16.4850006104"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-16.5969180345), float(18.8125098889), float(-12.2781831804), float(1.0)]


cluster_dict["16.4850006104"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-19.5), float(17.5), float(-8.0), float(1.0)]

cluster_dict["16.4850006104_arrows"] += cgo_arrow([-19.5,17.5,-8.0], [-18.634,16.431,-5.819], color="red blue", name="Arrows_16.4850006104_6")

cluster_dict["16.4850006104"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-20.0), float(20.0), float(-14.0), float(1.0)]

cluster_dict["16.4850006104_arrows"] += cgo_arrow([-20.0,20.0,-14.0], [-21.494,21.967,-16.077], color="red blue", name="Arrows_16.4850006104_7")

cluster_dict["16.4850006104"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-20.5), float(22.0), float(-9.0), float(1.0)]

cluster_dict["16.4850006104_arrows"] += cgo_arrow([-20.5,22.0,-9.0], [-22.02,23.609,-7.551], color="red blue", name="Arrows_16.4850006104_8")

cluster_dict["16.4850006104"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(15.5), float(-13.5), float(1.0)]


cmd.load_cgo(cluster_dict["16.4850006104"], "Features_16.4850006104", 1)
cmd.load_cgo(cluster_dict["16.4850006104_arrows"], "Arrows_16.4850006104")
cmd.set("transparency", 0.2,"Features_16.4850006104")
cmd.group("Pharmacophore_16.4850006104", members="Features_16.4850006104")
cmd.group("Pharmacophore_16.4850006104", members="Arrows_16.4850006104")

if dirpath:
    f = join(dirpath, "label_threshold_16.4850006104.mol2")
else:
    f = "label_threshold_16.4850006104.mol2"

cmd.load(f, 'label_threshold_16.4850006104')
cmd.hide('everything', 'label_threshold_16.4850006104')
cmd.label("label_threshold_16.4850006104", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_16.4850006104', members= 'label_threshold_16.4850006104')
