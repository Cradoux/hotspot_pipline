
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"13.8194999695":[], "13.8194999695_arrows":[]}

cluster_dict["13.8194999695"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-14.5), float(55.0), float(51.5), float(1.0)]

cluster_dict["13.8194999695_arrows"] += cgo_arrow([-14.5,55.0,51.5], [-16.296,53.603,52.731], color="blue red", name="Arrows_13.8194999695_1")

cluster_dict["13.8194999695"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-15.5), float(59.5), float(53.5), float(1.0)]

cluster_dict["13.8194999695_arrows"] += cgo_arrow([-15.5,59.5,53.5], [-13.483,59.635,55.763], color="blue red", name="Arrows_13.8194999695_2")

cluster_dict["13.8194999695"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-15.0), float(59.5), float(48.5), float(1.0)]

cluster_dict["13.8194999695_arrows"] += cgo_arrow([-15.0,59.5,48.5], [-12.485,60.798,46.613], color="blue red", name="Arrows_13.8194999695_3")

cluster_dict["13.8194999695"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-13.1654451416), float(57.0371063648), float(50.5023733074), float(1.0)]


cluster_dict["13.8194999695"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-6.17591962674), float(50.540802745), float(46.040802745), float(1.0)]


cluster_dict["13.8194999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-15.0), float(56.0), float(53.0), float(1.0)]

cluster_dict["13.8194999695_arrows"] += cgo_arrow([-15.0,56.0,53.0], [-14.031,53.869,54.187], color="red blue", name="Arrows_13.8194999695_4")

cluster_dict["13.8194999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(59.0), float(48.5), float(1.0)]

cluster_dict["13.8194999695_arrows"] += cgo_arrow([-13.5,59.0,48.5], [-12.485,60.798,46.613], color="red blue", name="Arrows_13.8194999695_5")

cluster_dict["13.8194999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-12.0), float(52.5), float(53.5), float(1.0)]

cluster_dict["13.8194999695_arrows"] += cgo_arrow([-12.0,52.5,53.5], [-14.031,53.869,54.187], color="red blue", name="Arrows_13.8194999695_6")

cluster_dict["13.8194999695"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-5.5), float(50.0), float(46.0), float(1.0)]

cluster_dict["13.8194999695_arrows"] += cgo_arrow([-5.5,50.0,46.0], [-4.658,52.086,44.13], color="red blue", name="Arrows_13.8194999695_7")

cmd.load_cgo(cluster_dict["13.8194999695"], "Features_13.8194999695", 1)
cmd.load_cgo(cluster_dict["13.8194999695_arrows"], "Arrows_13.8194999695")
cmd.set("transparency", 0.2,"Features_13.8194999695")
cmd.group("Pharmacophore_13.8194999695", members="Features_13.8194999695")
cmd.group("Pharmacophore_13.8194999695", members="Arrows_13.8194999695")

if dirpath:
    f = join(dirpath, "label_threshold_13.8194999695.mol2")
else:
    f = "label_threshold_13.8194999695.mol2"

cmd.load(f, 'label_threshold_13.8194999695')
cmd.hide('everything', 'label_threshold_13.8194999695')
cmd.label("label_threshold_13.8194999695", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_13.8194999695', members= 'label_threshold_13.8194999695')
