
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"12.861000061":[], "12.861000061_arrows":[]}

cluster_dict["12.861000061"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-14.5), float(55.0), float(51.5), float(1.0)]

cluster_dict["12.861000061_arrows"] += cgo_arrow([-14.5,55.0,51.5], [-16.296,53.603,52.731], color="blue red", name="Arrows_12.861000061_1")

cluster_dict["12.861000061"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-15.5), float(59.5), float(53.5), float(1.0)]

cluster_dict["12.861000061_arrows"] += cgo_arrow([-15.5,59.5,53.5], [-13.483,59.635,55.763], color="blue red", name="Arrows_12.861000061_2")

cluster_dict["12.861000061"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(-15.0), float(59.5), float(48.5), float(1.0)]

cluster_dict["12.861000061_arrows"] += cgo_arrow([-15.0,59.5,48.5], [-12.485,60.798,46.613], color="blue red", name="Arrows_12.861000061_3")

cluster_dict["12.861000061"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-12.7070648187), float(56.6070882834), float(50.3785878677), float(1.0)]


cluster_dict["12.861000061"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-6.33471458238), float(50.8101300214), float(46.5656137314), float(1.0)]


cluster_dict["12.861000061"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(-5.5), float(53.75), float(50.75), float(1.0)]


cluster_dict["12.861000061"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-15.0), float(56.0), float(53.0), float(1.0)]

cluster_dict["12.861000061_arrows"] += cgo_arrow([-15.0,56.0,53.0], [-14.031,53.869,54.187], color="red blue", name="Arrows_12.861000061_4")

cluster_dict["12.861000061"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-13.5), float(59.0), float(48.5), float(1.0)]

cluster_dict["12.861000061_arrows"] += cgo_arrow([-13.5,59.0,48.5], [-12.485,60.798,46.613], color="red blue", name="Arrows_12.861000061_5")

cluster_dict["12.861000061"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-12.0), float(52.5), float(53.5), float(1.0)]

cluster_dict["12.861000061_arrows"] += cgo_arrow([-12.0,52.5,53.5], [-14.031,53.869,54.187], color="red blue", name="Arrows_12.861000061_6")

cluster_dict["12.861000061"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(-5.5), float(50.0), float(46.0), float(1.0)]

cluster_dict["12.861000061_arrows"] += cgo_arrow([-5.5,50.0,46.0], [-4.658,52.086,44.13], color="red blue", name="Arrows_12.861000061_7")

cmd.load_cgo(cluster_dict["12.861000061"], "Features_12.861000061", 1)
cmd.load_cgo(cluster_dict["12.861000061_arrows"], "Arrows_12.861000061")
cmd.set("transparency", 0.2,"Features_12.861000061")
cmd.group("Pharmacophore_12.861000061", members="Features_12.861000061")
cmd.group("Pharmacophore_12.861000061", members="Arrows_12.861000061")

if dirpath:
    f = join(dirpath, "label_threshold_12.861000061.mol2")
else:
    f = "label_threshold_12.861000061.mol2"

cmd.load(f, 'label_threshold_12.861000061')
cmd.hide('everything', 'label_threshold_12.861000061')
cmd.label("label_threshold_12.861000061", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_12.861000061', members= 'label_threshold_12.861000061')
