
from os.path import join
import tempfile
import zipfile
from pymol import cmd, finish_launching
from pymol.cgo import *

finish_launching()

dirpath = None
    
def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.07, gap=0.0, hlength=-1, hradius=-1, color='blue red', name=''):
    from chempy import cpv
    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 +           [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 +           [1.0, 0.0]
    return obj

    
cluster_dict = {"12.9040002823":[], "12.9040002823_arrows":[]}

cluster_dict["12.9040002823"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(64.0), float(50.0), float(59.5), float(1.0)]

cluster_dict["12.9040002823_arrows"] += cgo_arrow([64.0,50.0,59.5], [64.802,47.625,61.39], color="blue red", name="Arrows_12.9040002823_1")

cluster_dict["12.9040002823"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(67.0), float(54.0), float(59.5), float(1.0)]

cluster_dict["12.9040002823_arrows"] += cgo_arrow([67.0,54.0,59.5], [66.6,55.724,57.264], color="blue red", name="Arrows_12.9040002823_2")

cluster_dict["12.9040002823"] += [COLOR, 0.00, 0.00, 1.00] + [ALPHA, 0.6] + [SPHERE, float(68.0), float(53.0), float(65.0), float(1.0)]

cluster_dict["12.9040002823_arrows"] += cgo_arrow([68.0,53.0,65.0], [65.785,54.765,65.83], color="blue red", name="Arrows_12.9040002823_3")

cluster_dict["12.9040002823"] += [COLOR, 1.00, 1.000, 0.000] + [ALPHA, 0.6] + [SPHERE, float(68.0885970834), float(51.0922228063), float(60.2126804208), float(1.0)]


cluster_dict["12.9040002823"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(69.0), float(54.5), float(60.5), float(1.0)]

cluster_dict["12.9040002823_arrows"] += cgo_arrow([69.0,54.5,60.5], [68.789,56.273,57.186], color="red blue", name="Arrows_12.9040002823_4")

cluster_dict["12.9040002823"] += [COLOR, 1.00, 0.00, 0.00] + [ALPHA, 0.6] + [SPHERE, float(69.0), float(54.5), float(60.5), float(1.0)]

cluster_dict["12.9040002823_arrows"] += cgo_arrow([69.0,54.5,60.5], [68.789,56.273,57.186], color="red blue", name="Arrows_12.9040002823_5")

cmd.load_cgo(cluster_dict["12.9040002823"], "Features_12.9040002823", 1)
cmd.load_cgo(cluster_dict["12.9040002823_arrows"], "Arrows_12.9040002823")
cmd.set("transparency", 0.2,"Features_12.9040002823")
cmd.group("Pharmacophore_12.9040002823", members="Features_12.9040002823")
cmd.group("Pharmacophore_12.9040002823", members="Arrows_12.9040002823")

if dirpath:
    f = join(dirpath, "label_threshold_12.9040002823.mol2")
else:
    f = "label_threshold_12.9040002823.mol2"

cmd.load(f, 'label_threshold_12.9040002823')
cmd.hide('everything', 'label_threshold_12.9040002823')
cmd.label("label_threshold_12.9040002823", "name")
cmd.set("label_font_id", 7)
cmd.set("label_size", -0.4)


cmd.group('Pharmacophore_12.9040002823', members= 'label_threshold_12.9040002823')
